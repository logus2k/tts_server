from .istftnet import Decoder
from .modules import CustomAlbert, ProsodyPredictor, TextEncoder
from dataclasses import dataclass
from huggingface_hub import hf_hub_download
from loguru import logger
from transformers import AlbertConfig
from typing import Dict, Optional, Union
import json
import torch

_VOWELS = "aɐeɛiɨoɔuæɑɒʌɪʊəɜ"   # the stressed-vowel minimum (tts_eu_pt)

class KModel(torch.nn.Module):
    '''
    KModel is a torch.nn.Module with 2 main responsibilities:
    1. Init weights, downloading config.json + model.pth from HF if needed
    2. forward(phonemes: str, ref_s: FloatTensor) -> (audio: FloatTensor)

    You likely only need one KModel instance, and it can be reused across
    multiple KPipelines to avoid redundant memory allocation.

    Unlike KPipeline, KModel is language-blind.

    KModel stores self.vocab and thus knows how to map phonemes -> input_ids,
    so there is no need to repeatedly download config.json outside of KModel.
    '''

    MODEL_NAMES = {
        'hexgrad/Kokoro-82M': 'kokoro-v1_0.pth',
        'hexgrad/Kokoro-82M-v1.1-zh': 'kokoro-v1_1-zh.pth',
    }

    def __init__(
        self,
        repo_id: Optional[str] = None,
        config: Union[Dict, str, None] = None,
        model: Optional[str] = None,
        disable_complex: bool = False
    ):
        super().__init__()
        if repo_id is None:
            repo_id = 'hexgrad/Kokoro-82M'
            print(f"WARNING: Defaulting repo_id to {repo_id}. Pass repo_id='{repo_id}' to suppress this warning.")
        self.repo_id = repo_id
        if not isinstance(config, dict):
            if not config:
                logger.debug("No config provided, downloading from HF")
                config = hf_hub_download(repo_id=repo_id, filename='config.json')
            with open(config, 'r', encoding='utf-8') as r:
                config = json.load(r)
                logger.debug(f"Loaded config: {config}")
        self.vocab = config['vocab']
        self.bert = CustomAlbert(AlbertConfig(vocab_size=config['n_token'], **config['plbert']))
        self.bert_encoder = torch.nn.Linear(self.bert.config.hidden_size, config['hidden_dim'])
        self.context_length = self.bert.config.max_position_embeddings
        self.predictor = ProsodyPredictor(
            style_dim=config['style_dim'], d_hid=config['hidden_dim'],
            nlayers=config['n_layer'], max_dur=config['max_dur'], dropout=config['dropout']
        )
        self.text_encoder = TextEncoder(
            channels=config['hidden_dim'], kernel_size=config['text_encoder_kernel_size'],
            depth=config['n_layer'], n_symbols=config['n_token']
        )
        self.decoder = Decoder(
            dim_in=config['hidden_dim'], style_dim=config['style_dim'],
            dim_out=config['n_mels'], disable_complex=disable_complex, **config['istftnet']
        )
        if not model:
            model = hf_hub_download(repo_id=repo_id, filename=KModel.MODEL_NAMES[repo_id])
        for key, state_dict in torch.load(model, map_location='cpu', weights_only=True).items():
            assert hasattr(self, key), key
            try:
                getattr(self, key).load_state_dict(state_dict)
            except:
                logger.debug(f"Did not load {key} from state_dict")
                state_dict = {k[7:]: v for k, v in state_dict.items()}
                getattr(self, key).load_state_dict(state_dict, strict=False)

    @property
    def device(self):
        return self.bert.device

    @dataclass
    class Output:
        audio: torch.FloatTensor
        pred_dur: Optional[torch.LongTensor] = None

    @torch.no_grad()
    def forward_with_tokens(
        self,
        input_ids: torch.LongTensor,
        ref_s: torch.FloatTensor,
        speed: float = 1
    ) -> tuple[torch.FloatTensor, torch.LongTensor]:
        input_lengths = torch.full(
            (input_ids.shape[0],), 
            input_ids.shape[-1], 
            device=input_ids.device,
            dtype=torch.long
        )

        text_mask = torch.arange(input_lengths.max()).unsqueeze(0).expand(input_lengths.shape[0], -1).type_as(input_lengths)
        text_mask = torch.gt(text_mask+1, input_lengths.unsqueeze(1)).to(self.device)
        bert_dur = self.bert(input_ids, attention_mask=(~text_mask).int())
        d_en = self.bert_encoder(bert_dur).transpose(-1, -2)
        s = ref_s[:, 128:]
        d = self.predictor.text_encoder(d_en, s, input_lengths, text_mask)
        x, _ = self.predictor.lstm(d)
        duration = self.predictor.duration_proj(x)
        duration = torch.sigmoid(duration).sum(axis=-1) / speed
        pred_dur = torch.round(duration).clamp(min=1).long().squeeze()
        # tts_eu_pt: a minimum pause per punctuation token (frames of 25 ms), scaled with speed. Reading several
        # sentences per call, the model alone gave commas 25-100 ms and "! Hoje" 75 ms (measured 2026-10-25).
        min_pause = getattr(self, "min_pause_frames", None)
        ids = input_ids[0].tolist()
        inv = {v: k for k, v in self.vocab.items()}
        if min_pause and pred_dur.dim() == 1:
            for k, tok in enumerate(ids):
                floor = min_pause.get(tok)
                # no forced pause right after a one-vowel word ("seguro e, sobretudo"): the lone vowel cut off by a
                # 250 ms pause gave an audible artifact; the native listener chose the model's own pause (2026-10-25)
                if floor and k >= 2 and inv.get(ids[k - 1], "") in "aɐeɛiɨoɔu" and \
                        inv.get(ids[k - 2], "") in (" ", "ˈ") and (k < 3 or inv.get(ids[k - 3], " ") in (" ", "ˈ") or
                                                               inv.get(ids[k - 2], "") == " "):
                    floor = None
                if floor:
                    pred_dur[k] = max(int(pred_dur[k]), int(round(floor / speed)))
        # phrase-break lengthening with no punctuation: the model stretched the unstressed final vowel of some words as
        # if a comma followed ("indica" ɐ 7 frames, "escreve" 6, "plataforma" 5, against 1-2 for most), heard as a
        # little pause. Optional maximum for that vowel when no punctuation follows, frames, off unless set.
        end_max = getattr(self, "unstressed_end_max", None)
        if end_max and pred_dur.dim() == 1:
            stops = " ,.;:!?…"
            for k in range(2, len(ids) - 1):
                if inv.get(ids[k]) != " " or inv.get(ids[k - 1], " ") not in _VOWELS + "ə":
                    continue
                j = k - 1
                while j > 1 and inv.get(ids[j - 1], " ") not in stops:
                    j -= 1
                word = [inv.get(t, "") for t in ids[j:k]]
                if "ˈ" not in word:
                    continue
                m = len(word) - 1 - word[::-1].index("ˈ")
                if sum(c in _VOWELS + "ə" for c in word[m + 1:]) >= 2:      # the final vowel is after the stressed one
                    pred_dur[k - 1] = min(int(pred_dur[k - 1]), int(end_max))
        # sentence-final lengthening: the last word before a .!? got 4-8 frames per phoneme ("verificável!" heard
        # dragged, "quem lê o quê." heard "quêé"). Optional cap for that word's phonemes, at EVERY sentence end of the
        # call (a call reads several sentences), frames, off unless set.
        last_cap = getattr(self, "last_word_max", None)
        if last_cap and pred_dur.dim() == 1:
            for end in range(1, len(ids)):
                if inv.get(ids[end], "") not in ".!?…" or inv.get(ids[end - 1], "") in ".!?…\"”)":
                    continue
                start = end
                while start > 1 and inv.get(ids[start - 1], "") not in (" ", ",", ";", ":", ".", "!", "?", "…"):
                    start -= 1
                for k in range(start, end):
                    pred_dur[k] = min(int(pred_dur[k]), int(last_cap))
        # pre-final compression: before the last word of a sentence the model sped up, stressed vowels down to 1-2
        # frames ("a decidir quem lê o quê" heard rushed). Optional minimum for the vowel of every stressed syllable,
        # frames, off unless set.
        stress_min = getattr(self, "stressed_vowel_min", None)
        if stress_min and pred_dur.dim() == 1:
            for k, tok in enumerate(ids):
                if inv.get(tok) != "ˈ":
                    continue
                j = k + 1
                while j < len(ids) and inv.get(ids[j], "") not in _VOWELS and inv.get(ids[j], " ") not in " ,.!?;:…":
                    j += 1
                if j < len(ids) and inv.get(ids[j], "") in _VOWELS:
                    pred_dur[j] = max(int(pred_dur[j]), int(stress_min))
        # a multi-word number is said in one go (the native listener's A/B, 2026-10-25): each gap inside it 1 frame, and
        # no sound of its words but the last longer than 4 frames. The gaps come from forward() (g2p.NUMBER_JOIN).
        keep, self.keep_vowels = getattr(self, "keep_vowels", None), None
        if keep and pred_dur.dim() == 1:
            for k in keep:
                if k < len(ids):
                    pred_dur[k] = max(int(pred_dur[k]), int(getattr(self, "keep_vowel_min", 2)))
        hold, self.hold_tokens = getattr(self, "hold_tokens", None), None
        if hold and pred_dur.dim() == 1:
            for k in hold:
                if k < len(ids):
                    pred_dur[k] = max(int(pred_dur[k]), int(getattr(self, "hold_min", 4)))
        clitic, self.clitic_vowels = getattr(self, "clitic_vowels", None), None
        if clitic and pred_dur.dim() == 1:
            for k in clitic:
                if k < len(ids):
                    pred_dur[k] = max(int(pred_dur[k]), 3)
        ends, self.end_gaps = getattr(self, "end_gaps", None), None
        if ends and pred_dur.dim() == 1:
            for k in ends:
                if k < len(ids):
                    pred_dur[k] = max(int(pred_dur[k]), 2)
                    if k + 1 < len(ids) and inv.get(ids[k + 1]) == " ":
                        pred_dur[k + 1] = max(int(pred_dur[k + 1]), 2)
        gaps, self.number_gaps = getattr(self, "number_gaps", None), None
        if gaps and pred_dur.dim() == 1:
            for g in gaps:
                if g >= len(ids) or inv.get(ids[g]) != " ":
                    continue
                pred_dur[g] = 1
                k = g - 1
                while k > 0 and inv.get(ids[k], "") not in (" ", ",", ";", ":", ".", "!", "?", "…"):
                    pred_dur[k] = min(int(pred_dur[k]), 4)
                    k -= 1
        # the stress mark is a token with its own frames; at the very start of an utterance they lengthen the first
        # vowel ("É simples" heard "Éé"). Optional cap, frames, off unless set.
        first_cap = getattr(self, "first_stress_max", None)
        if first_cap and pred_dur.dim() == 1 and len(ids) > 1 and inv.get(ids[1]) == "ˈ":
            pred_dur[1] = min(int(pred_dur[1]), int(first_cap))
        # tts_eu_pt: an optional maximum per token (frames). Off unless set; used to test the nasal tilde's own
        # duration (a nasal vowel is the vowel plus a U+0303 token, each with its own frames).
        max_frames = getattr(self, "max_frames", None)
        if max_frames and pred_dur.dim() == 1:
            for k, tok in enumerate(input_ids[0].tolist()):
                cap = max_frames.get(tok)
                if cap:
                    pred_dur[k] = min(int(pred_dur[k]), int(cap))
        indices =torch.repeat_interleave(torch.arange(input_ids.shape[1], device=self.device), pred_dur)
        pred_aln_trg = torch.zeros((input_ids.shape[1], indices.shape[0]), device=self.device)
        pred_aln_trg[indices, torch.arange(indices.shape[0])] = 1
        pred_aln_trg = pred_aln_trg.unsqueeze(0).to(self.device)
        en = d.transpose(-1, -2) @ pred_aln_trg
        F0_pred, N_pred = self.predictor.F0Ntrain(en, s)
        t_en = self.text_encoder(input_ids, input_lengths, text_mask)
        asr = t_en @ pred_aln_trg
        audio = self.decoder(asr, F0_pred, N_pred, ref_s[:, :128]).squeeze()
        return audio, pred_dur

    def forward(
        self,
        phonemes: str,
        ref_s: torch.FloatTensor,
        speed: float = 1,
        return_output: bool = False
    ) -> Union['KModel.Output', torch.FloatTensor]:
        # tts_eu_pt: "\u2040" (g2p.NUMBER_JOIN, not a vocab symbol) marks a gap inside a multi-word number; its
        # position is kept for forward_with_tokens (index of the token before it, counting the leading pad)
        input_ids, gaps, keep, hold, ends, clitic = [], [], [], [], [], []
        for p in phonemes:
            if p == "\u2040":
                if input_ids:
                    gaps.append(len(input_ids))
                continue
            if p == "\u2041":                    # g2p.KEEP_VOWEL: the token before it keeps at least 2 frames
                if input_ids:
                    keep.append(len(input_ids))
                continue
            if p == "\u2042":                    # g2p.HOLD: the token before it is held at least 4 frames
                if input_ids:
                    hold.append(len(input_ids))
                continue
            if p == "\u2044":                    # g2p.CLITIC_VOWEL: the token before it is held at least 3 frames
                if input_ids:
                    clitic.append(len(input_ids))
                continue
            if p == "\u2043":                    # g2p.END_GAP: the token before it >= 2 frames, the gap after it >= 2
                if input_ids:
                    ends.append(len(input_ids))
                continue
            i = self.vocab.get(p)
            if i is not None:
                input_ids.append(i)
        self.number_gaps, self.keep_vowels, self.hold_tokens, self.end_gaps, self.clitic_vowels = \
            gaps, keep, hold, ends, clitic
        logger.debug(f"phonemes: {phonemes} -> input_ids: {input_ids}")
        assert len(input_ids)+2 <= self.context_length, (len(input_ids)+2, self.context_length)
        input_ids = torch.LongTensor([[0, *input_ids, 0]]).to(self.device)
        ref_s = ref_s.to(self.device)
        audio, pred_dur = self.forward_with_tokens(input_ids, ref_s, speed)
        audio = audio.squeeze().cpu()
        pred_dur = pred_dur.cpu() if pred_dur is not None else None
        logger.debug(f"pred_dur: {pred_dur}")
        return self.Output(audio=audio, pred_dur=pred_dur) if return_output else audio

class KModelForONNX(torch.nn.Module):
    def __init__(self, kmodel: KModel):
        super().__init__()
        self.kmodel = kmodel

    def forward(
        self,
        input_ids: torch.LongTensor,
        ref_s: torch.FloatTensor,
        speed: float = 1
    ) -> tuple[torch.FloatTensor, torch.LongTensor]:
        waveform, duration = self.kmodel.forward_with_tokens(input_ids, ref_s, speed)
        return waveform, duration
