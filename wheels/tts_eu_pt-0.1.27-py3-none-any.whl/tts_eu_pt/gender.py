"""Grammatical gender for European Portuguese text normalisation.

Two questions the reader has to answer before it can speak a number or an honorific:

* NOUN gender, for number agreement: "2 vezes" -> "duas vezes", "200 mil pessoas" -> "duzentas mil pessoas".
  tugaphone guesses it from the word's last letter, which fails for every feminine noun not ending in -a (vez, fase,
  mão, cidade in the plural) and for masculine nouns in -a (dia, problema). The answer here comes from a lexicon:
  every noun form in MorphoBr (Apache-2.0, LR-POR/MorphoBr), which covers the pt-PT forms too (quilómetro, telemóvel,
  autocarro, equipa, ecrã, golo), filed in assets/noun_gender.tsv.gz.

* GIVEN-NAME gender, for "D." (Dom / Dona) and regnal numerals ("D. Maria II" -> "Dona Maria Segunda"). Rule: a name
  ending in -a or in a feminine ending (-ine, -ice, -ilde, ...) is feminine, plus the curated exceptions below.
  Measured against the IBGE 2010 census names (Brasil.IO): 94.5% people-weighted, the misses being mostly
  Brazilian-only names (Sueli, Marli). That data was used only to check the rule and is not shipped (CC BY-SA).
"""
from __future__ import annotations

import gzip
import unicodedata
from pathlib import Path
from typing import Optional

_ASSETS = Path(__file__).resolve().parent / "assets"
MASC, FEM, COMMON = "M", "F", "C"

# Counting units and scale words that MorphoBr files as either gender. When a number counts them, pt-PT uses the
# masculine: "dois milhões", "duzentos gramas" ("a grama" is the grass).
_NOUN_OVERRIDES = {w: MASC for w in (
    "milhão", "milhões", "bilião", "biliões", "trilião", "triliões", "milhar", "milhares",
    "grama", "gramas", "quilograma", "quilogramas", "miligrama", "miligramas", "micrograma", "microgramas",
)}

_TABLES: dict = {}


def _table(name: str) -> dict:
    if name not in _TABLES:
        table = {}
        with gzip.open(_ASSETS / name, "rt", encoding="utf-8") as f:
            for line in f:
                form, _, g = line.rstrip("\n").partition("\t")
                table[form] = g
        if name == "noun_gender.tsv.gz":
            table.update(_NOUN_OVERRIDES)
        _TABLES[name] = table
    return _TABLES[name]


def noun_gender(word: str) -> Optional[str]:
    """"M", "F", "C" (common gender: o/a colega) for a known noun form, None when the word is not a noun we know."""
    return _table("noun_gender.tsv.gz").get(word.lower())


def adjective_gender(word: str) -> Optional[str]:
    """"M", "F", "C" (one form for both: grande) for a known adjective form, None otherwise. An adjective between a
    number and its noun agrees with the noun, so it can decide the number's gender ("2 bonitas e grandes casas")."""
    return _table("adjective_gender.tsv.gz").get(word.lower())


# Acronyms take the gender of the noun they abbreviate: "2 SMS" -> "duas SMS" (a mensagem). Each acronym names its
# head noun, and the gender is read from the noun table, so every entry is checkable against MorphoBr. The overrides
# are pt-PT usage that differs from the head noun (or a head noun the table files as either gender).
_ACRONYM_HEADS = {
    "SMS": "mensagem", "MMS": "mensagem", "ONG": "organização", "PME": "empresa", "IPSS": "instituição",
    "PSP": "polícia", "PJ": "polícia", "UE": "união", "CE": "comissão", "ONU": "organização", "NATO": "organização",
    "OTAN": "organização", "OMS": "organização", "UNESCO": "organização", "SIDA": "síndrome", "EUA": "estados",
    "CTT": "correios", "IRS": "imposto", "IRC": "imposto", "IVA": "imposto", "IMI": "imposto", "IMT": "imposto",
    "IUC": "imposto", "PIB": "produto", "SNS": "serviço", "SEF": "serviço", "INE": "instituto", "INEM": "instituto",
    "IPO": "instituto", "BCE": "banco", "BCP": "banco", "BPI": "banco", "FMI": "fundo", "SIC": "sociedade",
    "TVI": "televisão", "TV": "televisão", "CGD": "caixa", "EDP": "energias", "PSD": "partido", "PS": "partido",
    "PCP": "partido", "CDS": "centro", "BE": "bloco", "IL": "iniciativa", "IA": "inteligência", "TAEG": "taxa",
    "TAN": "taxa", "PC": "computador", "CD": "disco", "DVD": "disco", "PDF": "documento", "GPS": "sistema",
    "NIF": "número", "NIB": "número", "IBAN": "número", "BI": "bilhete", "CC": "cartão", "ADN": "ácido",
    "UCI": "unidade", "FCT": "fundação", "DGS": "direção", "ETAR": "estação", "CV": "currículo", "RH": "recursos",
    "TI": "tecnologias", "URL": "endereço",
}
_ACRONYM_OVERRIDES = {"GNR": FEM, "RTP": FEM, "TAP": FEM, "CP": FEM, "PSP": FEM, "PJ": FEM, "CGD": FEM,
                      "PAN": MASC, "LTV": MASC}


def acronym_gender(acronym: str) -> Optional[str]:
    """"M" or "F" for a known acronym ("SMS" -> "F"); a plural with a lowercase s ("PMEs") is looked up singular."""
    key = acronym[:-1] if acronym.endswith("s") and acronym[:-1].isupper() else acronym
    if key in _ACRONYM_OVERRIDES:
        return _ACRONYM_OVERRIDES[key]
    head = _ACRONYM_HEADS.get(key)
    g = noun_gender(head) if head else None
    return g if g in (MASC, FEM) else None


# Feminine given names that do NOT end in -a (pt-PT usage, including the historical queens and infantas).
_FEM_NAMES = frozenset("""
Abigail Adelaide Alice Arlete Assunção Beatriz Brites Carmen Carmo Clarice Clotilde Conceição Cremilde Denise
Dolores Dulce Edite Elisabete Elizabete Ester Eunice Glória Guiomar Inês Ingrid Irene Íris Iris Isabel Ivete Ivone
Jaqueline Jéssica Leonilde Leonor Liliane Lourdes Lurdes Luz Madalena Marlene Matilde Mercedes Michele Miriam Nazaré
Nicole Noémi Odete Piedade Purificação Raquel Rosário Rute Ruth Salete Simone Trindade Violante Encarnação Ascensão
Anunciação Natividade Graciete Yasmin Karen Mel Solange Judite Sarah Nair Lilian Monique Joyce Shirley Elizabeth Ellen
""".split())

# Masculine given names that DO end in -a.
_MASC_NAMES = frozenset("Garcia Luca Gianluca Nicola Joshua Mustafa Juca Zeca Jonata René Antoine Davide Alcide".split())

# Name endings that are feminine in at least ~97% of the census population (measured 2026-10-24):
# Simone, Denise, Marlene, Liliane, Clarice, Arlete, Matilde, Adelaide, Gisele.
_FEM_ENDINGS = ("ANE", "INE", "ENE", "ETE", "ICE", "ISE", "ELE", "ILDE", "AIDE", "EIDE", "ENI", "ELLY")


def _strip_accents(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")


_FEM_KEYS = frozenset(_strip_accents(n).upper() for n in _FEM_NAMES)
_MASC_KEYS = frozenset(_strip_accents(n).upper() for n in _MASC_NAMES)


def name_gender(name: str) -> str:
    """"M" or "F" for a given name. Unknown names follow the -a rule; anything not a word is masculine."""
    key = _strip_accents(name).upper()
    if key in _MASC_KEYS:
        return MASC
    if key in _FEM_KEYS:
        return FEM
    return FEM if key.endswith("A") or key.endswith(_FEM_ENDINGS) else MASC
