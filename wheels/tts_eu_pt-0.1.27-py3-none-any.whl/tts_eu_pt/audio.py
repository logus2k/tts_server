"""Loudness and tone for the synthesised audio, numpy only (no scipy in the hosts that run this voice).

* integrated loudness in LUFS (ITU-R BS.1770-4 / EBU R128: K-weighting, 400 ms blocks with 75 % overlap, absolute gate
  -70 LUFS, relative gate -10 LU);
* a low-shelf boost (the RBJ cookbook shelf), for a voice that sounds thin;
* normalisation to a target loudness with a peak limiter, so a louder voice does not clip.

The filters are applied as their magnitude response in the frequency domain (zero phase): for a loudness measurement only
the energy matters, and a few dB of shelf has no audible phase effect on speech.
"""
from __future__ import annotations

import numpy as np


def _biquad_response(b, a, freqs: np.ndarray, sr: int) -> np.ndarray:
    z = np.exp(-2j * np.pi * freqs / sr)
    return (b[0] + b[1] * z + b[2] * z * z) / (a[0] + a[1] * z + a[2] * z * z)


def _shelf(sr: int, f0: float, gain_db: float, high: bool, q: float = 0.7071):
    """RBJ cookbook shelving biquad (b, a)."""
    A = 10 ** (gain_db / 40)
    w0 = 2 * np.pi * f0 / sr
    alpha = np.sin(w0) / (2 * q)
    c = np.cos(w0)
    s = 1 if high else -1
    b = [A * ((A + 1) + s * (A - 1) * c + 2 * np.sqrt(A) * alpha),
         -2 * s * A * ((A - 1) + s * (A + 1) * c),
         A * ((A + 1) + s * (A - 1) * c - 2 * np.sqrt(A) * alpha)]
    a = [(A + 1) - s * (A - 1) * c + 2 * np.sqrt(A) * alpha,
         2 * s * ((A - 1) - s * (A + 1) * c),
         (A + 1) - s * (A - 1) * c - 2 * np.sqrt(A) * alpha]
    return b, a


def _k_weighting(freqs: np.ndarray, sr: int) -> np.ndarray:
    """|H|^2 of the BS.1770 K filter: a +4 dB high shelf at ~1.7 kHz and a high-pass at ~38 Hz."""
    b1, a1 = _shelf(sr, 1681.97, 3.9998, high=True, q=0.7072)
    w0 = 2 * np.pi * 38.135 / sr
    alpha = np.sin(w0) / (2 * 0.5003)
    c = np.cos(w0)
    b2 = [(1 + c) / 2, -(1 + c), (1 + c) / 2]
    a2 = [1 + alpha, -2 * c, 1 - alpha]
    return np.abs(_biquad_response(b1, a1, freqs, sr) * _biquad_response(b2, a2, freqs, sr)) ** 2


def loudness_lufs(audio: np.ndarray, sr: int) -> float:
    """Integrated loudness of a mono signal, LUFS; -inf for silence."""
    x = np.asarray(audio, dtype=np.float64)
    if x.size < int(0.4 * sr):
        x = np.pad(x, (0, int(0.4 * sr) - x.size))
    X = np.fft.rfft(x)
    freqs = np.fft.rfftfreq(x.size, 1 / sr)
    y = np.fft.irfft(X * np.sqrt(_k_weighting(freqs, sr)), n=x.size)
    block, hop = int(0.4 * sr), int(0.1 * sr)
    n = 1 + (y.size - block) // hop
    sq = np.concatenate([[0.0], np.cumsum(y * y)])
    z = (sq[np.arange(n) * hop + block] - sq[np.arange(n) * hop]) / block
    lk = -0.691 + 10 * np.log10(np.maximum(z, 1e-20))
    z = z[lk > -70]
    if z.size == 0:
        return float("-inf")
    rel = -0.691 + 10 * np.log10(z.mean()) - 10
    z = z[-0.691 + 10 * np.log10(z) > rel]
    return float(-0.691 + 10 * np.log10(z.mean()))


def bass_boost(audio: np.ndarray, sr: int, gain_db: float, freq: float = 120.0) -> np.ndarray:
    """A low-shelf boost of gain_db below ~freq Hz."""
    if not gain_db:
        return audio
    x = np.asarray(audio, dtype=np.float64)
    b, a = _shelf(sr, freq, gain_db, high=False)
    freqs = np.fft.rfftfreq(x.size, 1 / sr)
    return np.fft.irfft(np.fft.rfft(x) * np.abs(_biquad_response(b, a, freqs, sr)), n=x.size).astype(np.float32)


def _limit(x: np.ndarray, sr: int, ceiling: float) -> np.ndarray:
    """Peak limiter: a gain that never lets |x| exceed ceiling, applied smoothly (5 ms blocks, look-ahead and release
    through a moving minimum and a moving average) so it does not click."""
    blk = max(1, int(0.005 * sr))
    n = -(-x.size // blk)
    peaks = np.abs(np.pad(x, (0, n * blk - x.size))).reshape(n, blk).max(axis=1)
    g = np.minimum(1.0, ceiling / np.maximum(peaks, 1e-9))
    w = 3                                                     # look-ahead / hold of 3 blocks each side
    gp = np.pad(g, w, mode="edge")
    g = np.min(np.stack([gp[i:i + n] for i in range(2 * w + 1)]), axis=0)
    k = np.ones(2 * w + 1) / (2 * w + 1)
    g = np.minimum(g, np.convolve(np.pad(g, w, mode="edge"), k, mode="valid"))
    gain = np.interp(np.arange(x.size), (np.arange(n) + 0.5) * blk, g)
    y = x * gain
    return np.clip(y, -ceiling, ceiling)                     # the last guard; the smooth gain already did the work


def normalize(audio: np.ndarray, sr: int, target_lufs: float, peak_dbfs: float = -1.5) -> np.ndarray:
    """Gain to target_lufs, peaks held at peak_dbfs by the limiter."""
    x = np.asarray(audio, dtype=np.float64)
    current = loudness_lufs(x, sr)
    if not np.isfinite(current):
        return np.asarray(audio, dtype=np.float32)
    y = x * 10 ** ((target_lufs - current) / 20)
    return _limit(y, sr, 10 ** (peak_dbfs / 20)).astype(np.float32)
