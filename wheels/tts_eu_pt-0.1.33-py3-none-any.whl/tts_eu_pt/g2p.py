#!/usr/bin/env python3
"""European Portuguese G2P via TugaPhone — the permissive replacement for espeak-ng.

WHY: espeak-ng is GPLv3, which forces copyleft on anyone redistributing a product built
on it. The project's goal is unrestricted commercial reuse, so espeak must go.
TugaPhone is Apache-2.0 and won an objective bake-off against espeak on a neutral
Wiktionary reference (PER 0.0994 vs 0.1147, n=30).

CRITICAL — THE TUGAPHONE VERSION MATTERS:
  Sub-regional lects need tugaphone >= 1.2.0a1 (pinned in pyproject.toml). On the OLDER
  STABLE release, get_dialect_inventory() only branched on pt-BR/AO/MZ/TL and defaulted
  everything else to EuropeanPortuguese(), so "pt-PT-x-lisbon", "pt-PT-x-porto" and even
  nonsense strings all returned generic pt-PT output and LisbonPortuguese was unreachable
  dead code. That fix has since shipped to PyPI, so the dev branch is no longer required:
  measured on 1.2.0a1, "pt-PT-x-lisbon" -> "u ˈviɲu ˈveɾd" vs generic "o ˈviɲu ˈveɾd".
  assert_lect_support() enforces this at run time, whatever release is installed.

  CAVEAT: an UNKNOWN lect string still falls back to generic pt-PT silently rather than
  raising, so a typo in LECT degrades quality without any error.

LECT: pt-PT-x-lisbon. TugaPhone's own scoreboard puts it far ahead of generic pt-PT
(PER 0.1007 vs 0.2294; word accuracy 0.4330 vs 0.1540).

This module mirrors scripts/ptpt_g2p.py so it can be swapped in as the single source of
truth for text -> input_ids. Training and inference MUST use the same one.
"""
import hashlib
import json
import sys
import unicodedata
from typing import Optional
from pathlib import Path

from . import gender as _gender

_ASSETS = Path(__file__).resolve().parent / "assets"

CFG = json.loads((_ASSETS / "kokoro_config.json").read_text())
VOCAB: dict[str, int] = CFG["vocab"]
N_TOKEN: int = CFG["n_token"]
ID2SYM: dict[int, str] = {i: s for s, i in VOCAB.items()}

MAX_PHONEME_LEN = 510   # kokoro/model.py caps input at 510 chars
BOUNDARY_ID = 0         # input_ids = [0, *ids, 0]
LECT = "pt-PT-x-lisbon"

# TugaPhone emits 4 symbols outside Kokoro's 178-token vocab. Measured over the full
# hard-case corpus; counts were r-uvular 12, dark-l 12, ascii-g 9, apico-alveolar-s 3.
SYMBOL_MAP = {
    "ʀ": "ʁ",   # uvular trill -> uvular fricative (id 128); pt-PT rhotic, same phoneme class
    "ɫ": "l",   # velarised (dark) l -> plain l (id 54); Kokoro has no dark-l token
    "g": "ɡ",   # ASCII g -> IPA script g (U+0261, id 92). Classic IPA trap.
    "̺": "",  # COMBINING INVERTED BRIDGE BELOW (apico-alveolar s). A genuine pt-PT
                   # feature Kokoro's vocab cannot represent -- dropped, not approximated.
}
SYLLABLE_SEP = "·"      # TugaPhone marks syllables; not a phoneme

_phonemizer = None


class UnmappedSymbol(ValueError):
    """Raised at prep time so unmapped symbols fail loudly instead of being silently
    dropped by kokoro's vocab.get(p) at inference time."""


def assert_lect_support() -> None:
    """Fail fast if the installed tugaphone ignores sub-regional lects.

    Probes behaviour rather than the version string, so it stays correct no matter which
    release or branch is installed.
    """
    tp = _get()
    a = tp.phonemize_sentence("o vinho verde", "pt-PT")
    b = tp.phonemize_sentence("o vinho verde", "pt-PT-x-porto")
    if a == b:
        raise RuntimeError(
            "The installed tugaphone ignores sub-regional lects, so "
            f"{LECT} would silently degrade to generic pt-PT. Upgrade:\n"
            '  pip install "tugaphone>=1.2.0a1"'
        )


# Former name, kept so existing callers keep working. The check is no longer about a
# branch -- the lect fix shipped to PyPI in 1.2.0a1.
assert_dev_branch = assert_lect_support


def _get():
    global _phonemizer
    if _phonemizer is None:
        from tugaphone import TugaPhonemizer
        _phonemizer = TugaPhonemizer()
        _phonemizer.phonemize_sentence("a", LECT)          # registers the tugalex overlay
        _restress_unmarked_entries()
    return _phonemizer


# tugalex entries that are wrong, each confirmed by the native listener AND Wiktionary (Portugal). Written in the overlay
# notation (stress mark at the syllable onset, no syllable dots).
_LEXICON_FIXES = {
    "cada": "ˈkɐdɐ",
    "iban": "ˈiban",          # said as a word with an open a, "íban" (the listener, 2026-11-01; not ˈibɐ̃ / ˈibɐn, heard "iben")          # tugalex kˈa·dɐ; Wiktionary kɐ.dɐ; heard wrong in the Cortex sample (2026-10-25)
    # de/em + este/esse/ele/aquele: tugalex lacks them and the rules opened the e (ˈdɛʃtɨ); the masculine is closed
    # (Wiktionary, Portugal: deste ˈdeʃ.tɨ, desse ˈde.sɨ, dele ˈde.lɨ, naquele nɐˈke.lɨ; the feminine dela ˈdɛ.lɐ is open)
    "deste": "ˈdeʃtɨ", "destes": "ˈdeʃtɨʃ", "neste": "ˈneʃtɨ", "nestes": "ˈneʃtɨʃ", "desse": "ˈdesɨ",
    "desses": "ˈdesɨʃ", "nesse": "ˈnesɨ", "nesses": "ˈnesɨʃ", "dele": "ˈdelɨ", "deles": "ˈdelɨʃ",
    "neles": "ˈnelɨʃ", "naquele": "nɐˈkelɨ", "naqueles": "nɐˈkelɨʃ", "daquele": "dɐˈkelɨ", "daqueles": "dɐˈkelɨʃ",
    # number words keep their final ɨ: tugalex drops it (doze ˈdoz), and "6, 12 ou 24" was heard "6, 2 ou 24" in 10 of
    # 10 samples; with ˈdozɨ, "12" in 10 of 10 (Whisper, no prompt, 2026-10-25; reported by the Cortex agent)
    "doze": "ˈdozɨ", "onze": "ˈõzɨ",
    # "treze": a secondary stress on its last syllable, so the final ɨ is said ("treze aspetos" was heard "três"; pauses,
    # a longer ɨ, ə, ɪ ("trezi") and ᵻ were each rejected by the native listener, who chose this, 2026-10-25)
    "treze": "ˈtɾeˌzɨ", "catorze": "kɐˈtoɾzɨ", "quinze": "ˈkĩzɨ", "sete": "ˈsɛtɨ",
    "nove": "ˈnɔvɨ", "vinte": "ˈvĩtɨ", "dezassete": "dɨzɐˈsɛtɨ", "dezanove": "dɨzɐˈnɔvɨ",
    # "dezoito": tugalex has the closed dɨˈzojtu; Lisbon says "dezóito" (the native listener; Wiktionary Portugal
    # /dɨˈzɔj.tu/ first, Central and Southern Portugal /dɨˈzɔj.tu/), 2026-10-25. "oito" stays closed (/ˈoj.tu/)
    "dezoito": "dɨˈzɔjtu",
    # "em": tugalex ẽj; pt-PT (Lisbon) /ɐ̃j̃/ as in "bem", "tem" (Wiktionary Portugal), and with ẽj "Em Aspeto" was
    # heard merged; the native listener's A/B "B" (2026-10-25)
    "em": "ɐ̃j̃",
    # "Aveiro": not in tugalex, the rules reduced the first a (ɐˈvɐjɾu); said "Áveiro" (the native listener; Wiktionary
    # Portugal /aˈvɐj.ɾu/), 2026-10-25
    "aveiro": "aˈvɐjɾu",
    # "Euribor": said "Euribór", open o (the native listener; the rules closed it, ewɾiˈboɾ), 2026-10-27
    "euribor": "ewɾiˈbɔɾ",
    # checked against Wiktionary (Portugal), 2026-10-30: "estas" as "esta" /ˈɛʃ.tɐ/;
    # "bebé" /bɛˈbɛ/; "sector" /sɛkˈtoɾ/ (its c is said); the French "madame", "dossier" (no reference: the listener's ear)
    "estas": "ˈɛʃtɐʃ", "bebé": "bɛˈbɛ", "bebés": "bɛˈbɛʃ", "sector": "sɛkˈtoɾ", "sectores": "sɛkˈtoɾɨʃ",
    "madame": "mɐˈdam", "dossier": "dɔˈsje", "dossiers": "dɔˈsjeʃ",
    "intercetação": "ĩtɨɾsɛtɐˈsɐ̃w̃", "intercetações": "ĩtɨɾsɛtɐˈsõj̃ʃ",   # as "intercetar" ĩtɨɾsɛˈtaɾ (tugalex)
    # tugaphone read "especificamente" ei_spɨsifikɐˈmẽt: a "_" outside the vocab (the validator's 5 unmapped hits, found
    # dropping a training clip, 2026-10-28); as its family (especificar ʃpɨsifiˈkaɾ, especialmente ʃpɨsjalˈmẽt)
    "especificamente": "ʃpɨsifikɐˈmẽt",
    # à + aquele(s)/aquela(s): the rules stressed the ending ("àqueles" akɛˈlɨʃ)
    "àquele": "aˈkelɨ", "àqueles": "aˈkelɨʃ", "àquela": "aˈkɛlɐ", "àquelas": "aˈkɛlɐʃ",
    # temperature scales: the rules read "Celsius" sɨˈlsiwʃ (the native listener expects "Célsius"; pt-PT ˈsɛlsjuʃ) and
    # "Fahrenheit" fɐˈɾɐɲɐjt (pt-PT ˈfaɾɨnajt), 2026-10-25
    "celsius": "ˈsɛlsjuʃ", "fahrenheit": "ˈfaɾɨnajt",
    # the watt family (the rules gave "quilowatts" kiˈlowɐttʃ); pt-PT ˈwɔt as in the pt-PT lexicon's megawatt mɛɡɐˈwɔt
    "watts": "ˈwɔtʃ", "quilowatt": "kilɔˈwɔt", "quilowatts": "kilɔˈwɔtʃ", "megawatt": "mɛɡɐˈwɔt",
    "megawatts": "mɛɡɐˈwɔtʃ",
}


def _restress_unmarked_entries() -> None:
    """tugalex has ~147 Lisbon entries with syllables but NO stress mark (paciente pɐ·sjẽt,
    experiência ɐjʃ·pɨ·ɾjẽ·sjɐ); the engine then stresses the FIRST syllable (ˈpɐsjẽt). In all of
    them that carry an "ie" glide syllable (-ente/-ência/-ense/-ento/-ieta/-ieza...), that syllable
    is the stressed one (Wiktionary pt-PT: experiente (i)ʃ.pɨˈɾjẽ.tɨ). Entries cut short by the
    lexicon (microfarad "mi·kɾɔ·") are dropped so the rules read the whole word. Patched in the
    in-memory overlay orthography2ipa reads on every lookup."""
    try:
        import orthography2ipa.lexicon as o2l
        from tugalex import TugaLexicon
    except ImportError:
        return
    overlay = o2l.get_lexicon(LECT)
    if not overlay:
        return
    for word, ipa in _LEXICON_FIXES.items():
        overlay[word] = ipa
    lex = TugaLexicon()
    # unstressed final -es read -iʃ in 8 tugalex entries ("simples" sˈĩ·pliʃ, heard "simplis" by the native listener,
    # 2026-10-25; Nunes, flandres, manes, nicles, postres, ademanes): pt-PT has ɨʃ (ˈsĩpləʃ)
    for word in lex.get_wordlist():
        if word.endswith("es") and word in overlay and not any(c in "áéíóúâêô" for c in word[-3:]):
            cur = unicodedata.normalize("NFD", overlay[word])
            if cur.endswith("iʃ") and "ˈ" in cur and cur.rfind("ˈ") < len(cur) - 4:
                overlay[word] = unicodedata.normalize("NFC", cur[:-2] + "ɨʃ")
    for word in lex.get_wordlist():
        ipa = lex.get_phonemes(word)
        if not ipa or "·" not in ipa or "ˈ" in ipa or "ˌ" in ipa or word not in overlay:
            continue
        if ipa.endswith("·"):
            overlay.pop(word, None)
            continue
        syl = ipa.split("·")
        glide = [i for i, x in enumerate(syl) if any(g in unicodedata.normalize("NFD", x)
                                                    for g in ("je", "jɛ"))]
        if glide:
            k = glide[-1]
            overlay[word] = "".join(("ˈ" if i == k else "") + x for i, x in enumerate(syl))


# European-Portuguese speech drops the connector "e" only INSIDE the twenties, and only
# before units 5-9:  25-29 -> "vinte cinco" ... "vinte nove", BUT 21/22/23/24 KEEP it ->
# "vinte e um/dois/três/quatro". Holds at any scale (124 -> "cento e vinte e quatro",
# 126 -> "cento e vinte seis", 2026 -> "dois mil e vinte seis"). Every other tens keeps it
# too (39 -> "trinta e nove"). Confirmed by the native speaker. The number reader always
# insert the "e", so we strip it only for vinte + {cinco..nove}.
_ELIDE_E_AFTER = {"vinte"}
_ELIDE_UNITS = {"cinco", "seis", "sete", "oito", "nove"}


def _drop_tens_units_e(text: str) -> str:
    words = text.split()
    out, i = [], 0
    n = len(words)
    while i < n:
        if (i + 2 < n and words[i].lower() in _ELIDE_E_AFTER
                and words[i + 1].lower() == "e" and words[i + 2].lower() in _ELIDE_UNITS):
            out.append(words[i])         # keep "vinte"
            out.append(words[i + 2])     # keep the unit (4-9), drop the "e" between
            i += 3
        else:
            out.append(words[i])
            i += 1
    return " ".join(out)


_DASHES = {"-", "–", "—", "−"}


def _split_number_ranges(text: str) -> str:
    """A dash BETWEEN two digits is a numeric range: "1139-1185" -> "1139 a 1185", read
    "mil ... a mil ...". Without this the glued token "1139-1185" reaches the number reader as one
    unparseable string, stays as raw digits, and gets DROPPED (digits aren't in the vocab).
    Char-scan (no regex): only a dash flanked by digits is touched, so word hyphens
    ("chamo-me", "guarda-chuva") stay intact."""
    n = len(text)
    out = []
    for i, ch in enumerate(text):
        if ch in _DASHES and 0 < i < n - 1 and text[i - 1].isdigit() and text[i + 1].isdigit():
            out.append(" a ")
        else:
            out.append(ch)
    return "".join(out)


_OPENING_MARKS = set('([{“‘«')
_CLOSING_MARKS = set(',;:!?.)]}”’»…')


def _detach_marks(text: str) -> str:
    """Put a space between a word and the punctuation glued to it, so tugaphone's number expander sees bare tokens.

    It splits on whitespace only, and measured on 1.2.0a1 it (a) leaves a number with a glued mark as raw digits, which
    the tokenizer then DROPS ("1185)" / "1185," / "«1185"), (b) swallows the '.' after a number, so a sentence end
    vanishes ("Nasceu em 1185. Depois" became one run-on chunk), and (c) misses gender agreement when the noun carries
    a mark ("2 casas," read "dois casas"). A mark BETWEEN two digits (a decimal or thousands separator) is left alone.
    _reattach_marks undoes the spacing afterwards. Char-scan (no regex)."""
    n = len(text)
    out = []
    for i, ch in enumerate(text):
        between_digits = 0 < i < n - 1 and text[i - 1].isdigit() and text[i + 1].isdigit()
        word_internal = i + 1 < n and text[i + 1].isalnum()   # "d’água", "n.º": the mark is inside the word
        if ch in _CLOSING_MARKS and not between_digits and not word_internal and i > 0 and text[i - 1].isalnum():
            out.append(" ")
        out.append(ch)
        if ch in _OPENING_MARKS and i + 1 < n and text[i + 1].isalnum():
            out.append(" ")
        elif ch == '"':                      # straight quote: opening before a word, closing after one
            if i + 1 < n and text[i + 1].isalnum() and (i == 0 or text[i - 1].isspace()):
                out.append(" ")
            elif i > 0 and text[i - 1].isalnum():
                out.insert(len(out) - 1, " ")
    return "".join(out)


def _reattach_marks(text: str) -> str:
    """Inverse of _detach_marks: a closing mark hugs the word before it, an opening mark the word after it."""
    words = text.split()
    out: list[str] = []
    glue_next = False
    open_quote = False
    for w in words:
        if w == '"':                          # straight quotes alternate: the 1st opens, the 2nd closes
            if open_quote and out:
                out[-1] += w
                glue_next = False
            else:
                out.append(w)
                glue_next = True
            open_quote = not open_quote
            continue
        if out and all(c in _CLOSING_MARKS for c in w):
            out[-1] += w
        elif glue_next:
            out[-1] += w
        else:
            out.append(w)
        glue_next = all(c in _OPENING_MARKS for c in w)
    return " ".join(out)


_ORDINAL_MARKS = {"º": False, "ª": True}      # masculine / feminine ordinal indicator -> is_feminine


_RBNF = None


def _ordinal_words(n: int, feminine: bool) -> str:
    """"vigésimo primeiro" / "vigésima primeira" (every word agrees), from unicode-rbnf (MIT, CLDR rules). Before 0.1.32
    num2words (LGPL), identical for 1-399 and wrong from 400 on ("quadrigentésimo"; quadringentésimo is right)."""
    global _RBNF
    if _RBNF is None:
        from unicode_rbnf import RbnfEngine
        _RBNF = RbnfEngine.for_language("pt")
    from unicode_rbnf import FormatPurpose
    forms = _RBNF.format_number(n, FormatPurpose.ORDINAL).text_by_ruleset
    return forms["spellout-ordinal-feminine" if feminine else "spellout-ordinal-masculine"]


def _expand_ordinals(text: str) -> str:
    """"8.º" -> "oitavo", "2.ª" -> "segunda", "3º" -> "terceiro". tugaphone RAISES on these (decimal.InvalidOperation),
    and that exception used to abort the expansion of every OTHER number in the same text, while the '.' of "8.º" was
    then cut by the sentence splitter ("o 8." + "º escalão"). The degree sign '°' is NOT treated as an ordinal.
    Token scan (no regex)."""
    out = []
    for w in text.split():
        lead, core, trail = _split_edges(w)
        head, hyphen, rest = core.partition("-")          # "1.º-ministro": the ordinal heads a compound
        mark = head[-1:] if head else ""
        if mark in _ORDINAL_MARKS:
            digits = head[:-1]
            if digits.endswith("."):
                digits = digits[:-1]
            if digits.isdigit():
                out.append(lead + _ordinal_words(int(digits), _ORDINAL_MARKS[mark]) + hyphen + rest + trail)
                continue
        out.append(w)
    return " ".join(out)


# Words that are never the noun a number counts, although MorphoBr files some as nouns (the letters "a", "o", "e";
# "mais", "cerca", "pela"). The lookahead for agreement stops at them.
_NOT_COUNTED = frozenset("""
a à às as o os ao aos e é de da das do dos em na nas no nos num numa um uma uns umas para pra pelo pela pelos pelas por
com sem até mais menos que ou se há tem têm são foi era eram será ser estar cerca entre sobre após desde apenas só quase
já não sim mesmo mesma todos todas cada quanto quantos quantas também ainda muito muitos muitas pouco poucos
este esta estes estas esse essa esses essas aquele aquela aqueles aquelas outro outra outros outras seu sua seus suas
vírgula mil
""".split())

# Nouns that NAME by number instead of counting: "página 2" is "página dois", "século 21" "século vinte e um". A number
# right after one of them is a masculine cardinal, whatever follows it.
_LABEL_NOUNS = frozenset("""
século séculos capítulo capítulos página páginas artigo artigos número alínea fase parte tomo volume livro ato cena
secção título anexo nível classe série lote bloco piso andar porta quarto sala linha ponto figura tabela quadro gráfico
temporada episódio versão modelo tipo grupo escalão item passo etapa jornada ronda opção cenário caso exemplo exercício
pergunta questão regra lei decreto norma via estrada lugar posição dia hora canal faixa
""".split())

# Before a number with no counted noun, these mean the hours: "às 2" -> "às duas", "das 2 às 3", "à 1 e meia".
_HOUR_WORDS = frozenset({"à", "às", "as", "das", "pelas"})


def _bare(w: str) -> str:
    return _split_edges(w)[1].lower()


_RANGE_WORDS = frozenset({"a", "e", "ou", "até"})


def _is_number(w: str) -> bool:
    from tugaphone.number_utils import NumberParser
    w = _split_edges(w)[1]
    return any(c.isdigit() for c in w) and (NumberParser.is_int(w) or NumberParser.is_float(w))


def _counted_gender(words: list[str], idx: int) -> str:
    """"M" or "F" for the number at words[idx]: agreement with the noun it counts, read off the text."""
    prev = _bare(words[idx - 1]) if idx > 0 else ""
    if prev == "vírgula" or prev in _LABEL_NOUNS:     # decimal digits; a label ("página 2")
        return _gender.MASC
    j = idx + 1
    while j < len(words):
        w = _bare(words[j])
        if w == "vírgula":                                  # "2,5 horas": the integer part agrees with "horas"
            j += 2
        elif w == "mil":                                    # "200 mil pessoas" -> "duzentas mil pessoas"
            j += 1
        elif (w in _RANGE_WORDS or words[j] == ",") and j + 1 < len(words) and _is_number(words[j + 1]):
            j += 2                                          # "2 a 3 semanas", "2, 3 ou 4 casas": the noun after all
        else:
            break
    if j < len(words):
        nxt = _bare(words[j])
        if nxt in ("das", "delas"):                     # "1 das casas" -> "uma das casas"
            return _gender.FEM
        if nxt in ("dos", "deles"):
            return _gender.MASC
        # Walk the noun phrase: the first word with a gender of its own decides, noun or adjective ("2 grandes e
        # bonitas casas": "grandes" has one form for both, "bonitas" is feminine). Words with no gender (common-gender
        # nouns, "grande"-type adjectives) and an "e" between adjectives are passed over; anything that is neither a
        # noun nor an adjective (a verb, a function word, a number) ends the phrase.
        k = j
        while k < len(words) and k - j < 6:
            w = _bare(words[k])
            if k > j and (w == "e" or words[k] == ","):     # "grandes e bonitas", "grandes , novas" (marks detached)
                k += 1
                continue
            if w in _NOT_COUNTED or not w.isalpha():
                break
            ng, ag = _gender.noun_gender(w), _gender.adjective_gender(w)
            for g in (ng, ag):
                if g in (_gender.MASC, _gender.FEM):
                    return g
            if ng is None and ag is None:
                break
            k += 1
    if prev in _HOUR_WORDS:
        return _gender.FEM
    return _gender.MASC


def _spell_number(word: str, gender: str) -> str:
    from tugaphone.number_utils import NumberParser
    return NumberParser.pronounce_number_word(word, gender="feminine" if gender == _gender.FEM else "masculine",
                                              is_brazilian=False)


def _spell_numbers(text: str) -> str:
    """Every number token -> pt-PT words, with the gender the counted noun asks for (see gender.py). This replaces
    tugaphone.number_utils.normalize_numbers, whose suffix-guess read "2 vezes" as "dois vezes" and, after "a"/"da",
    "a 2 quilómetros" as "a duas quilómetros"; its spelling engine is still the one used."""
    words = text.split()
    out = []
    for i, w in enumerate(words):
        if not _is_number(w):
            out.append(w)
            continue
        try:
            out.append(_spell_number(w, _counted_gender(words, i)))
        except Exception:
            out.append(w)
    return " ".join(out)


def _agree_with_acronyms(text: str) -> str:
    """A number before an acronym takes the acronym's gender: "2 SMS" -> "duas SMS", "21 PMEs" -> "vinte e uma PMEs".
    Runs at the TEXT level, before _spell_acronyms turns the acronym into letter names whose gender means nothing."""
    words = text.split()
    out = []
    for i, w in enumerate(words):
        lead, core, trail = _split_edges(w)
        if not trail and core.lstrip("-").isdigit() and i + 1 < len(words):
            g = _gender.acronym_gender(_split_edges(words[i + 1])[1])
            if g is not None:
                out.append(lead + _drop_tens_units_e(_spell_number(core, g)))
                continue
        out.append(w)
    return " ".join(out)


def normalize_numbers(text: str) -> str:
    """Expand digits to words. TugaPhone does NOT do this inside phonemize_sentence --
    raw digits pass straight through and would reach the tokenizer. Uses long scale for
    pt-PT and gender agreement from a noun lexicon. Expands ordinals (8.º -> oitavo), numeric
    ranges (1139-1185 -> "... a ...") and drops the tens+units "e" for natural pt-PT (25 -> "vinte cinco")."""
    text = _expand_ordinals(text)
    return _reattach_marks(_drop_tens_units_e(_spell_numbers(_detach_marks(_split_number_ranges(text)))))


# tugaphone writes a NASAL SCHWA (ɨ̃) for pretonic "en/em" in many words - pensou pɨ̃ˈso, sentindo sɨ̃ˈtĩdu,
# lembrou, mendigos, aventuras, compreendi - where pt-PT has ẽ (pẽˈso). Standard pt-PT has no nasal schwa; all 110
# distinct tokens carrying it in the training transcripts are this error. A native listener heard "pensou" as
# "pzou" (2026-10-24): the reduced vowel is dropped. Mapped to ẽ, which the voice knows from thousands of
# correctly transcribed words.
FIX_NASAL_SCHWA = True    # approved by the native listener, 2026-10-24
_NASAL_SCHWA = "ɨ\u0303"
_NASAL_E = "e\u0303"


# Two pt-PT phonological rules tugaphone applies in its dictionary words but not in its rule fallback (found by
# scripts/validate_frontend.py, 2026-10-25: the lemma is right, the inflected form wrong):
#   * a syllable-final s before a voiced consonant is voiced: "desmaiava" dɨʒmɐˈjavɐ, "transmitida", "rosnando";
#   * after a nasal vowel (written n/m + r) r is the strong ʁ: "honras" ˈõʁɐʃ, "enrolando" ẽʁuˈlɐ̃du.
_VOICED_CONSONANTS = set("bdɡvzʒmnɲlʎɾʁ")
_NASAL_TILDE = "\u0303"


_STRESS = "ˈ"


def _voicing_and_strong_r(ps: str) -> str:
    out = list(ps)
    for i, c in enumerate(out):
        j = i + 1
        while j < len(out) and out[j] in ("ˈ", "ˌ"):
            j += 1
        nxt = out[j] if j < len(out) else ""
        if c == "ʃ" and nxt in _VOICED_CONSONANTS:
            out[i] = "ʒ"
        elif c == "ɾ" and i > 0 and (out[i - 1] == _NASAL_TILDE or (i > 1 and out[i - 1] in "ˈˌ" and out[i - 2] == _NASAL_TILDE)):
            out[i] = "ʁ"
    return "".join(out)


def _penult_stress_emos(ps: str) -> str:
    """tugaphone put the stress of some of these paroxytones on the LAST syllable: "queremos" kɨɾeˈmuʃ, "esquecemos",
    "pequenos" pɨkeˈnuʃ. In the closed e / closed a endings (-emos, -enos, -ena, -amos, -ano...) the stress is on that
    vowel: move the mark before the consonant that opens its syllable (kɨˈɾemuʃ, pɨˈkenuʃ). Only when the word's only
    stress mark sits between that vowel and the final syllable."""
    words = []
    for w in ps.split(" "):
        core = w.rstrip(".,;:!?…\"()“”—")
        tail = w[len(core):]
        for fin in ("uʃ", "ɐʃ", "uz", "ɐz", "uʒ", "ɐʒ", "u", "ɐ"):
            if not core.endswith(fin):
                continue
            head = core[:-len(fin)]                         # ...V ˈ C
            if len(head) >= 4 and head[-1] in "mnɲ" and head[-2] == "ˈ" and head[-3] in "eɐ" \
                    and head.count("ˈ") == 1 and head[-4] not in "aɐeɛiɨoɔuˈ":
                core = head[:-4] + "ˈ" + head[-4] + head[-3] + head[-1] + fin
            break
        words.append(core + tail)
    return " ".join(words)


def _clean(ps: str) -> str:
    """Strip syllable separators, decompose precomposed nasals, apply the symbol map."""
    ps = ps.replace(SYLLABLE_SEP, "")
    # TugaPhone emits BOTH precomposed (ẽ) and decomposed (ɐ + U+0303) nasals.
    # NFD makes it uniform, and the combining tilde is vocab id 17.
    ps = unicodedata.normalize("NFD", ps)
    for src, dst in SYMBOL_MAP.items():
        ps = ps.replace(src, dst)
    if "$$" in ps:                                         # a dictionary entry with two pronunciations: keep one
        words = []
        for w in ps.split(" "):
            if "$$" in w:
                w = w.split("$$")[0]
                first = w.find(_STRESS)
                w = w[:first + 1] + w[first + 1:].replace(_STRESS, "") if first >= 0 else w
            words.append(w)
        ps = " ".join(words)
    if FIX_NASAL_SCHWA:
        ps = ps.replace(_NASAL_SCHWA, _NASAL_E)
    ps = _voicing_and_strong_r(_penult_stress_emos(ps))          # after NFD, so the tilde is the separate U+0303
    return " ".join(ps.split())


def _strip_ordinal_marks(text: str) -> str:
    """Remove masculine/feminine ordinal indicators (3.º, 2.ª).

    TugaPhone's number parser raises decimal.InvalidOperation on these, so they are
    stripped as a fallback. Plain string replacement, no pattern matching.
    """
    for mark in ("º", "ª", "°"):
        text = text.replace("." + mark, "").replace(mark, "")
    return text


# Loanword override: English-pronounced borrowings ("online", "site", "email") that
# TugaPhone would lusophonize. Phonemes generated OFFLINE with espeak (GPL at prep time);
# only the phoneme dict ships. Curated to lowercase common nouns -- proper nouns and
# acronyms are excluded (Portuguese does not use their English pronunciation).
_LOANWORDS = None


# English brand names, said in English like the loanwords (British phonemes from espeak-ng at preparation time); kept
# here because loanwords.json takes no proper nouns. Read as Portuguese, "Microsoft Teams" was miˈkɾozuft ˈtɛɐ̃ʃ (Whisper
# "Microsoft TENS"); the native listener chose the English reading (B, 2026-10-28). The two-word espeak readings of
# SharePoint / OneDrive are joined with a secondary stress, as "powerpoint" in loanwords.json.
_BRAND_WORDS = {
    "microsoft": "mˈaɪkɹəsˌɒft", "teams": "tˈiːmz", "excel": "ɛksˈɛl", "outlook": "ˈaʊtlʊk",
    "sharepoint": "ʃˈeəpˌɔɪnt", "onedrive": "wˈɒndɹˌaɪv",
}


def _loanwords() -> dict:
    global _LOANWORDS
    if _LOANWORDS is None:
        try:
            _LOANWORDS = json.loads((_ASSETS / "loanwords.json").read_text())
        except Exception:
            _LOANWORDS = {}
        _LOANWORDS = {**_LOANWORDS, **_BRAND_WORDS}
    return _LOANWORDS


def _loan_key(w: str) -> str:
    return w.strip(".,!?;:—…\"'()“”").lower()


# The letter x has four sounds in Portuguese (ʃ, ks, z, s) and tugaphone gets it right for the words it knows but
# falls back to ʃ for inflected forms (measured 2026-10-24): "existe" ɐˈʃiʃtɨ (heard "AX..."), "fixas" ˈfiʃɐʃ (heard
# "fichas"), "máximos" ˈmaʃimuʃ, while "existir", "fixa", "máximo" are right. Fixed by RESPELLING the word before
# tugaphone sees it, so its phrase-level processing is untouched:
#   * word-initial ex + vowel is always z in Portuguese: "existe" -> "iziste" (unstressed e is i), "êxito" keeps ê;
#   * a plural sounds like its singular: try x -> ks / ss / z / ch on the singular, keep the spelling that reproduces
#     the singular's own phonemes, apply it to the plural ("fixas" -> "fiksas", "máximos" -> "mássimos");
#   * forms of fixar/fixo take ks ("fixou", "fixam"), except the slang "fixe" (ˈfiʃ).
_VOWEL_LETTERS = set("aeiouáéíóúâêôãõà")
_X_SPELLINGS = ("ch", "ks", "ss", "z")    # ch first: if ʃ reproduces the singular the word is left alone ("peixe")
_x_cache: dict = {}


def _x_respelling_for(singular: str, lect: str) -> Optional[str]:
    if singular.count("x") != 1:
        return None
    key = (singular, lect)
    if key not in _x_cache:
        target = _clean(_get().phonemize_sentence(singular, lect))
        _x_cache[key] = next((r for r in _X_SPELLINGS
                              if _clean(_get().phonemize_sentence(singular.replace("x", r), lect)) == target), None)
    return _x_cache[key]


# A stressed a before m / n / nh is CLOSED (ɐ) in pt-PT unless written á: "vamos" ˈvɐmuʃ, "chegamos" (present)
# ʃɨˈɡɐmuʃ, but "chegámos" (past) ʃɨˈɡamuʃ. tugaphone gets it right in its dictionary ("cama") and gives open a in
# forms it lacks ("vamos", "estamos", "chamo", "ramos"), so present and past of every -ar verb sounded the same
# (found 2026-10-25, user report on "Chegámos"). Respelled with â, which tugaphone reads as ɐ, on words stressed on
# that a (no written accent, so stress is on the penultimate syllable).
_CLOSED_A_ENDINGS = ("amos", "amo", "amas", "ama", "anos", "ano", "anas", "ana", "anhos", "anho", "anhas", "anha")
_ACCENTED = set("áéíóúâêôãõàÁÉÍÓÚÂÊÔÃÕÀ")
# The same for e: stressed e before m / n is closed (e) unless written é; tugaphone gave open ɛ in forms it lacks
# ("comemos" kuˈmɛmuʃ, "temos", "podemos", "fazemos"). Not -enho: Lisbon "tenho" is ˈtɐɲu.
_CLOSED_E_ENDINGS = ("emos", "emo", "emas", "ema", "enos", "eno", "enas", "ena")


_DICTIONARY: Optional[set] = None
_TUGALEX: set = set()
def _in_dictionary(word: str) -> bool:
    """Is the word in tugalex, tugaphone's pronunciation dictionary? Its entries are right; only words it lacks go
    through tugaphone's rule fallback, which is where these vowel errors come from. Respelling a dictionary word would
    push it into that fallback ("oceano" ɔˈsjɐnu -> usɨˈɐnu, measured 2026-10-25), so dictionary words are left alone."""
    global _DICTIONARY, _TUGALEX
    if _DICTIONARY is None:
        from tugalex import TugaLexicon
        _TUGALEX = set(TugaLexicon().get_wordlist())
        _DICTIONARY = _TUGALEX | set(_LEXICON_FIXES)
    return word.lower() in _DICTIONARY


def _respell_closed_a(w: str) -> str:
    low = w.lower()
    if any(c in _ACCENTED for c in w) or len(low) < 3 or _in_dictionary(low):
        return w
    for end in _CLOSED_A_ENDINGS:
        if low.endswith(end):
            k = len(w) - len(end)
            return w[:k] + ("â" if w[k] == "a" else "Â") + w[k + 1:]
    for end in _CLOSED_E_ENDINGS:
        if low.endswith(end):
            k = len(w) - len(end)
            return w[:k] + ("ê" if w[k] == "e" else "Ê") + w[k + 1:]
    return w


# x is ks in these letter contexts (learned words: tóxico, lexical, sexual, ortodoxo, plexiforme, asfixia), where
# tugaphone's rules read ʃ. Contexts measured on pt-PT dictionary words (>= 15 words, >= 95% agreeing; on held-out
# words 99.2% right vs 74.3% for always-ʃ, 2026-10-25). "^" = word start, "$" = word end; the longest match wins.
_X_KS_CONTEXTS = frozenset({"lexi", "óxi", "exu", "exia$", "axia$", "oxo", "plexi"})


def _x_context(low: str) -> Optional[str]:
    i = low.index("x")
    keys = []
    for left in (3, 2, 1):
        for right in (2, 1):
            if i - left < 0:
                continue
            keys.append(("^" if i - left == 0 else "") + low[i - left:i] + "x" + low[i + 1:i + 1 + right]
                        + ("$" if i + 1 + right >= len(low) else ""))
    for k in sorted(keys, key=len, reverse=True):
        if k in _X_KS_CONTEXTS:
            return "ks"
    return None


def _respell_x_word(w: str, lect: str) -> str:
    w = _respell_closed_a(w)
    low = w.lower()
    if _in_dictionary(low):
        # tugalex already has it right; a respelling would only make the lookup miss and the rules guess
        # ("exercício" -> "izercício" lost its accent stress: iˈzɨɾsisiu, found 2026-10-25)
        return w
    if low.startswith("trans") and len(low) > 5 and low[5] in _VOWEL_LETTERS:
        w, low = w[:4] + "z" + w[5:], low[:4] + "z" + low[5:]   # "transitarmos": s between n and a vowel is z
    if "x" not in low:
        return w
    if low[:2] == "ex" and len(low) > 2 and low[2] in _VOWEL_LETTERS:
        return ("iz" if w[0].islower() else "Iz") + w[2:]
    for prefix in ("coex", "reex", "preex", "autoex"):                  # "coexistir", "reexaminar": ex+vowel after a prefix
        if low.startswith(prefix) and len(low) > len(prefix) and low[len(prefix)] in _VOWEL_LETTERS:
            k = len(prefix) - 2
            return w[:k] + "ez" + w[k + 2:]

    if low[:2] in ("êx", "éx") and len(low) > 2 and low[2] in _VOWEL_LETTERS:
        return w[0] + "z" + w[2:]
    if low.startswith("fix") and low not in ("fixe", "fixes"):
        return w[:2] + "ks" + w[3:]
    if low.count("x") == 1 and _x_context(low) == "ks":
        i = low.index("x")
        return w[:i] + "cs" + w[i + 1:]                       # "tóxico", "lexical", "sexual", "axial": ks
    if low.endswith("s") and len(low) > 3:
        # the singular: drop the s ("fixas" -> "fixa"); only for -es plurals whose -s singular fails, drop "es"
        # ("fluxes"). Stop at the first singular that resolves: a final z sounds ʃ, so "tax" would falsely match "taz".
        candidates = [low[:-1]] + ([low[:-2]] if low.endswith("es") else [])
        for singular in candidates:
            r = _x_respelling_for(singular, lect)
            if r is not None:
                return w if r == "ch" else w.replace("x", r, 1).replace("X", r.upper(), 1)
    return w


# tugalex (tugaphone's dictionary) stores two pronunciations for three homographs, joined by its internal "$$", and
# tugaphone passes both through: "a bordo" -> ɐ ˈbɔɾˈdu$$boɾdu, so the voice said "bordo" TWICE (the $ are dropped by
# the tokenizer). All 318,888 entries were scanned (2026-10-24); these are the only three. Respelled with an accent to
# pick one: the noun "a bordo" (closed o), the verb "desbordo" (open o).
_HOMOGRAPH_RESPELLINGS = {"bordo": "bôrdo", "bordos": "bôrdos", "contrabordo": "contrabôrdo", "desbordo": "desbórdo",
                          # the platform's name, written without the accent of the Portuguese word: read as "córtex"
                          # (it was kuɾˈtɐʃ, 2026-10-25)
                          "cortex": "córtex"}


def _respell_x(text: str, lect: str) -> str:
    out = []
    for tok in text.split():
        lead, core, trail = _split_edges(tok)
        if not core.isalpha():
            out.append(tok)
            continue
        homograph = _HOMOGRAPH_RESPELLINGS.get(core.lower())
        if homograph:
            core = homograph if core.islower() else homograph.capitalize()
        out.append(lead + _respell_x_word(core, lect) + trail)
    return " ".join(out)


def _phon_one(text: str, lect: str) -> str:
    text = _respell_x(text, lect)
    try:
        return _clean(_get().phonemize_sentence(normalize_numbers(text), lect))
    except Exception:
        # ordinals (3.º) crash tugaphone's number parser; retry without the markers
        t = _strip_ordinal_marks(text)
        return _clean(_get().phonemize_sentence(normalize_numbers(t), lect))


# Acronyms spoken as Portuguese LETTER NAMES, not read as a syllable. "IA" (inteligência
# artificial) must sound "i á", not "ia"; "LLM" must sound "éle-éle-éme", not "lãm".
# The letter names are written with accents so TugaPhone gives the open-e spelling form
# (L = ˈɛlɨ, not the pronoun "ele" ˈel). The trailing comma injects a pause so the last
# letter does not merge into the next word. Expanded at the TEXT level (see phonemize) so
# the comma becomes a real KEEP_PUNCT pause token.
_ACRONYMS = {
    "IA": "i á,", "LLM": "éle éle éme,", "UTC": "u tê cê,",
    # The project's own name. Left raw, TugaPhone returns vowel-less clusters that
    # Portuguese phonotactics cannot realise -- "tts" -> ˈttʃ and "pt" -> ˈpt -- and the
    # decoder emits noise rather than speech. Confirmed by ear on 0.1.0.
    "tts_eu_pt": "tê tê ésse eu pê tê,",
    "tts-eu-pt": "tê tê ésse eu pê tê,",
    "TTS": "tê tê ésse,", "tts": "tê tê ésse,",
    "PT": "pê tê,",
    # NOTE: keys are matched case-SENSITIVELY on purpose. Lowercase "eu" is the pronoun
    # ("eu vou") and lowercase "ia" is a verb form ("ele ia"); mapping those to letter
    # names would corrupt ordinary text. Only add a lowercase key when the token is not
    # also a real Portuguese word -- "tts" qualifies, "eu" does not.
}

# Abbreviations expanded to full words at the TEXT level (before punctuation splitting,
# so the trailing "." is consumed here instead of becoming a sentence pause and the letter
# is not read on its own). "D." is the Portuguese honorific: "D. Afonso Henriques" ->
# "Dom Afonso Henriques", "D. Maria" -> "Dona Maria": _expand_acronyms picks the form from the given name
# (gender.name_gender); "Dom" is only the fallback when no name follows.
_ABBREVIATIONS = {"D.": "Dom", "n.º": "número", "N.º": "Número", "nº": "número", "Nº": "Número",
                  # titles (found by the corpus diff, 2026-10-25: "o Celeste Sr. Teodoro" was read "ésse érre")
                  "Sr.": "Senhor", "Sra.": "Senhora", "Srs.": "Senhores", "Sras.": "Senhoras", "Dr.": "Doutor",
                  "Dra.": "Doutora", "Eng.": "Engenheiro", "Eng.ª": "Engenheira", "Prof.": "Professor",
                  "Prof.ª": "Professora", "Exmo.": "Excelentíssimo", "Exma.": "Excelentíssima", "Sr.ª": "Senhora", "Dr.ª": "Doutora",
                  "Tel.": "Telefone", "Telef.": "Telefone", "Tlf.": "Telefone", "Tlm.": "Telemóvel"}


_LEAD_PUNCT = '(“"‘¿¡\''
_TRAIL_PUNCT = '.,;:!?)"”…\''


def _split_edges(w: str) -> tuple[str, str, str]:
    """Return (leading punctuation, core, trailing punctuation) of a token."""
    i, j = 0, len(w)
    while i < j and w[i] in _LEAD_PUNCT:
        i += 1
    while j > i and w[j - 1] in _TRAIL_PUNCT:
        j -= 1
    return w[:i], w[i:j], w[j:]


def _expand_acronyms(text: str) -> str:
    words = text.split()
    out = []
    for i, w in enumerate(words):
        # Honorific abbreviations key on the EXACT token — the trailing '.' is PART of "D."
        # (it's what distinguishes it from a lone "D"), so it must not be stripped.
        if w == "D.":                          # Dom / Dona, by the given name that follows ("D. Maria" -> "Dona Maria")
            name = _split_edges(words[i + 1])[1] if i + 1 < len(words) else ""
            is_name = name[:1].isupper() and name.isalpha()
            out.append("Dona" if is_name and _gender.name_gender(name) == _gender.FEM else "Dom")
            continue
        if w in _ABBREVIATIONS:
            out.append(_ABBREVIATIONS[w])
            continue
        # Acronyms (IA, LLM, UTC) may carry surrounding punctuation ("UTC.", "(UTC)"):
        # strip it for the lookup and reattach, so they still expand at a sentence end.
        lead, core, trail = _split_edges(w)
        if core in _ABBREVIATIONS and not core.endswith("."):   # "n.º," / "(nº": the mark is not part of the key
            out.append(lead + _ABBREVIATIONS[core] + trail)
            continue
        repl = _ACRONYMS.get(core)
        if repl is not None:
            if trail and repl.endswith(","):
                repl = repl[:-1]   # the real punctuation already supplies the pause
            out.append(lead + repl + trail)
            continue
        out.append(w)
    return " ".join(out)


# Roman numerals, read the pt-PT way:
#   after a monarch's or pope's name: ordinal up to ten, gendered by the name ("D. Afonso I" -> "Primeiro",
#     "D. Maria II" -> "Segunda"), cardinal above ten ("Luís XIV" -> "catorze", "João XXIII" -> "vinte e três");
#   after a naming noun (século, capítulo, ...): cardinal ("século XIX" -> "dezanove");
#   before a noun: an ordinal that agrees with it ("II Guerra Mundial" -> "segunda Guerra Mundial").
# Only I, V and X (1-39) are read as numerals, so CD, CV, LX, MD and XL stay acronyms.
_ROMAN = {"I": 1, "V": 5, "X": 10}


def _roman_value(s: str) -> int | None:
    if not s or any(c not in _ROMAN for c in s):
        return None
    total = 0
    for k, c in enumerate(s):
        v = _ROMAN[c]
        total += -v if k + 1 < len(s) and _ROMAN[s[k + 1]] > v else v
    canon = "X" * (total // 10) + ["", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX"][total % 10]
    return total if 0 < total < 40 and canon == s else None      # only canonical forms ("IIII" is not 4)


def _split_trailing_punct(w: str) -> tuple[str, str]:
    """Split a token into (core, trailing punctuation), e.g. 'I.' -> ('I', '.')."""
    i = len(w)
    while i > 0 and w[i - 1] in '.,;:!?)"“”':
        i -= 1
    return w[:i], w[i:]


def _cardinal(n: int, gender: str = "M") -> str:
    return _drop_tens_units_e(_spell_number(str(n), gender))


def _expand_regnal_numerals(text: str) -> str:
    words = text.split()
    out = []
    for i, w in enumerate(words):
        core, trail = _split_trailing_punct(w)
        n = _roman_value(core)
        if n is None:
            out.append(w)
            continue
        prev, prev_trail = _split_trailing_punct(words[i - 1]) if i > 0 else ("", "")
        nxt = _split_edges(words[i + 1])[1] if i + 1 < len(words) else ""
        if prev.lower() in _LABEL_NOUNS:                                        # "século XIX", "capítulo V"
            out.append(_cardinal(n) + trail)
            continue
        # A monarch's name: capitalised, right before the numeral (no punctuation between: "Luís XIV, II Guerra"),
        # and not itself a numeral.
        if prev.isalpha() and prev[:1].isupper() and len(prev) > 1 and not prev_trail \
                and prev.lower() not in _NOT_COUNTED and _roman_value(prev) is None:
            if n <= 10:                                                         # "D. Maria II" -> "Segunda"
                words_ = _ordinal_words(n, _gender.name_gender(prev) == _gender.FEM)
                out.append(words_[:1].upper() + words_[1:] + trail)
            else:                                                               # "Luís XIV" -> "catorze"
                out.append(_cardinal(n) + trail)
            continue
        # The next token must be a real word: a single letter ("A X N", "H O S P I T A L") means letters are being spelled.
        g = _gender.noun_gender(nxt) if len(nxt) > 1 and nxt.lower() not in _NOT_COUNTED else None
        if g is not None and (len(core) >= 2 or nxt[:1].isupper()):            # "II Guerra Mundial"
            out.append(_ordinal_words(n, g == _gender.FEM) + trail)
            continue
        out.append((_cardinal(n) if len(core) >= 2 else core) + trail)          # a lone "I"/"V"/"X" stays a letter
    return " ".join(out)


# Clock times: whole hours ("16:00") are read "<hora> horas", NOT "... e zero"; others "<hora> e <minutos>". "hora"
# is feminine, so 1/2 (and 21/22) take feminine forms; every other hour has no gender issue and is left as digits
# for the number expander. Hours are 0-23.
_FEM_HOURS = {1: "uma", 2: "duas", 21: "vinte e uma", 22: "vinte e duas"}


def _expand_clock_times(text: str) -> str:
    """"16:00" -> "16 horas", "1:00" -> "uma hora", "1:30" -> "uma e 30", "16:54" -> "16 e 54". A token the scan
    cannot read as HH:MM (e.g. "(16:54") is left for _split_time_colons. Token scan (no regex), so it must run BEFORE
    _split_time_colons turns the colon into " e "."""
    out = []
    for tok in text.split():
        core, trail = _split_trailing_punct(tok)
        if core.endswith("h") and ":" in core and core[:-1].replace(":", "").isdigit():
            core = core[:-1]                   # "06:00h", "17:30h": the h repeats what the colon says
        hh_s, sep, mm_s = core.partition(":")
        if sep and hh_s.isdigit() and mm_s.isdigit() and len(mm_s) == 2 and 0 <= int(hh_s) <= 23 \
                and int(mm_s) <= 59:
            hh = int(hh_s)
            hour = _FEM_HOURS.get(hh, hh_s)   # feminine word ("hora"), else digits (expanded later)
            if mm_s == "00":
                out.append(f"{hour} {'hora' if hh == 1 else 'horas'}{trail}")
            else:                             # "1:30" -> "uma e 30", not "um e trinta"
                out.append(f"{hour} e {int(mm_s)}{trail}")
        else:
            out.append(tok)
    return " ".join(out)


def _split_time_colons(text: str) -> str:
    """A colon BETWEEN two digits is a clock time, read with "e": "16:54" ->
    "dezasseis e cinquenta e quatro". The colon is a KEEP_PUNCT token, so left alone it
    splits into a pause; this runs at the TEXT level before that split. Char-scan (no
    regex): only a colon flanked by digits is touched, so "Nota:", "são:" keep their pause."""
    n = len(text)
    out = []
    for i, ch in enumerate(text):
        if ch == ":" and 0 < i < n - 1 and text[i - 1].isdigit() and text[i + 1].isdigit():
            out.append(" e ")
        else:
            out.append(ch)
    return "".join(out)


def _normalize_separator_dashes(text: str) -> str:
    """A SPACED en/em-dash or hyphen used as a separator (" – ", " — ", " - ") becomes a
    comma pause, so "Henriques – Primeiro rei" doesn't run together (and isn't misheard as
    a regnal "Henriques Primeiro"). Number ranges ("1139-1185") have no surrounding spaces
    and are left for _split_number_ranges. Literal string replace, no regex."""
    for d in (" – ", " — ", " - "):
        text = text.replace(d, ", ")
    return text


def _normalize_number_separators(text: str) -> str:
    """European number formatting, handled BEFORE the '.'/',' splitter would break it:
    "." groups thousands and is dropped (92.073 -> 92073 -> "noventa e dois mil e setenta e
    três"); "," is the decimal mark, spoken "vírgula" (10,4 -> "dez vírgula quatro").
    Char-scan (no regex): only a separator BETWEEN two digits is touched, so sentence-final
    periods and list commas keep their pause."""
    n = len(text)
    out = []
    for i, ch in enumerate(text):
        between = 0 < i < n - 1 and text[i - 1].isdigit() and text[i + 1].isdigit()
        if between and ch == ".":
            # thousands only when EXACTLY three digits follow ("92.073", "1.234.567"); otherwise a version or an
            # English decimal, read "ponto": "2.0" was dropped to "20" ("DC2.0" -> "DC20"), found by the validator
            k = i + 1
            while k < n and text[k].isdigit():
                k += 1
            if k - (i + 1) == 3:
                continue                   # thousands separator -> drop
            out.append(" ponto ")
            continue
        if between and ch == ",":
            out.append(" vírgula ")        # decimal mark -> spoken word
            continue
        out.append(ch)
    return "".join(out)


# Any other acronym - a token of 2 to 6 capital letters (IMT, IRS, LTV, HPP, TAEG, CRC) - is SPELLED with the letter
# names below: Portuguese readers spell such tokens, and read raw they came out as a syllable ("IMT" -> ĩt) or as an
# unpronounceable cluster ("LTV" -> ltv, which the decoder renders as noise). Measured in the movies' narration,
# 2026-10-24. Runs after the regnal numerals (so "D. João VI" stays "Sexto"); _ACRONYMS above keeps its special forms.
_LETTER_NAMES = {"A": "á", "B": "bê", "C": "cê", "D": "dê", "E": "é", "F": "éfe", "G": "gê", "H": "agá", "I": "i",
                 "J": "jota", "K": "capa", "L": "éle", "M": "éme", "N": "éne", "O": "ó", "P": "pê", "Q": "quê", "R": "érre",
                 "S": "ésse", "T": "tê", "U": "u", "V": "vê", "W": "dâblio", "X": "xis", "Y": "ípsilon", "Z": "zê"}
# Capital-letter words that are read as words, not spelled (extend when one comes up: ONU, NATO, ...).
_READ_AS_WORDS = frozenset({"ONU", "NATO", "UNESCO", "OTAN", "SIDA", "IBAN"})    # IBAN: "íban" (the listener, 2026-11-01)
# brand names said as such, replaced before the acronym step (Cortex agent, 0.1.16: "MB WAY" was spelled "éme bê, dâblio
# á ípsilon")
_BRANDS = {("MB", "WAY"): ("éme bê", "WAY", "/ˈwɐj/")}       # the English word as an inline override (its phonemes)


def _letter_run(words: list, i: int) -> bool:
    """Is words[i] a single capital letter inside a run of >= 2 of them ("A X N", "H O S P I T A L", "P S P")?"""
    def single(k):
        return 0 <= k < len(words) and len(_split_edges(words[k])[1]) == 1 and _split_edges(words[k])[1] in _LETTER_NAMES
    return single(i) and (single(i - 1) or single(i + 1))


def _spell_acronyms(text: str) -> str:
    out = []
    words = text.split()
    for (a, b), (spelled, word, ipa) in _BRANDS.items():
        for i in range(len(words)):
            lead, core, trail = _split_edges(words[i])
            if core.upper() == a + b:                                  # "MBWAY" written as one word (Cortex agent)
                words[i] = lead + spelled + " " + _override_word(word, ipa) + trail
            elif core.upper() == a and i + 1 < len(words) and _split_edges(words[i + 1])[1].upper() == b:
                words[i] = lead + spelled + trail if trail else lead + spelled       # "MB WAY", "MB Way"
                words[i + 1] = _override_word(word, ipa) + _split_edges(words[i + 1])[2]
            elif core == b and core.isupper():                         # "WAY" alone: the English word, not spelled
                words[i] = lead + _override_word(word, ipa) + trail
    for i, w in enumerate(words):
        lead, core, trail = _split_edges(w)
        if "-" in core and not core.startswith("-") and all(core.split("-")):
            # a hyphenated identifier ("cj-transfers-be"): spell its vowel-less or all-capital parts
            parts = core.split("-")
            fixed = [" ".join(_LETTER_NAMES[c.upper()] for c in x)
                     if x.isalpha() and len(x) <= 6 and all(c.upper() in _LETTER_NAMES for c in x)
                     and (not any(c in "aeiouyáéíóúâêôãõàAEIOUY" for c in x) or (x.isupper() and len(x) > 1))
                     and x not in _READ_AS_WORDS else x for x in parts]
            if fixed != parts:
                out.append(lead + " ".join(fixed) + trail)
                continue
        if _letter_run(words, i):                       # spelled letters: every letter by name, vowels too
            out.append(lead + _LETTER_NAMES[core] + trail)
            continue
        for apostrophe in ("'s", "’s"):                 # "FIN's": an acronym with an English possessive/plural 's
            if core.endswith(apostrophe) and len(core) > 3 and core[:-2].isupper():
                core = core[:-2] + "s"
        if len(core) >= 3 and core.endswith("s") and core[:-1].isupper() and core[:-1].isalpha() \
                and core[:-1] not in _READ_AS_WORDS and all(c in _LETTER_NAMES for c in core[:-1]):
            # A plural acronym ("PMEs", "ONGs"): the letters, with the plural s on the last one ("pê éme és").
            spelled = " ".join(_LETTER_NAMES[c] for c in core[:-1]) + "s"
            out.append(lead + spelled + (trail if trail else ","))
            continue
        no_vowel = core.isalpha() and 2 <= len(core) <= 6 and not any(c in "aeiouyáéíóúâêôãõàAEIOUY" for c in core)
        if len(core) == 1 and core in _LETTER_NAMES and core not in "AEOÉ" and core.isupper():
            out.append(lead + _LETTER_NAMES[core] + trail)     # a lone capital consonant ("P S P", "participant C")
            continue
        if no_vowel and all(c.upper() in _LETTER_NAMES for c in core):
            core = core.upper()                                # "npm", "cj", "csv", "sql": no Portuguese word lacks a vowel
        if 2 <= len(core) <= 6 and core.isalpha() and core.isupper() and core not in _READ_AS_WORDS \
                and all(c in _LETTER_NAMES for c in core):
            spelled = " ".join(_LETTER_NAMES[c] for c in core)
            out.append(lead + spelled + (trail if trail else ","))   # the comma: the last letter does not merge into the next word
            continue
        out.append(w)
    return " ".join(out)


_DIGIT_NAMES = ("zero", "um", "dois", "três", "quatro", "cinco", "seis", "sete", "oito", "nove")


def _iban_head(t: str) -> bool:
    """"PT50": two capital letters (the country) and two check digits."""
    return len(t) == 4 and t[:2].isalpha() and t[:2].isupper() and t[2:].isdigit()


def _expand_iban(text: str) -> str:
    """An IBAN as pt-PT reads it out (the listener's choice "B", 2026-11-01): the country's letters by name, the two
    check digits as a number, then every group of the account digit by digit, a short pause between groups:
    "PT50 0035 0697 0001 2345 6789 0" -> "pê tê 50, zero zero três cinco, zero seis nove sete, ..., zero". Read as
    numbers, the leading zeros were lost ("0035" -> "trinta e cinco") and the groups merged into large numbers. Also
    written in one run ("PT50003506970001234567890"): its account digits in groups of four. Token scan, no regex."""
    words = text.split()
    out, i = [], 0
    while i < len(words):
        lead, core, trail = _split_edges(words[i])
        head, groups, j = None, [], i + 1
        if _iban_head(core) and not trail:
            head = core
            while j < len(words):
                l2, c2, t2 = _split_edges(words[j])
                if l2 or not c2.isdigit() or len(c2) > 4:
                    break
                groups.append(c2); j += 1; trail = t2
                if t2:
                    break
            if len(groups) < 2:
                head = None
        elif len(core) >= 16 and _iban_head(core[:4]) and core[4:].isdigit():
            head, rest = core[:4], core[4:]
            groups = [rest[k:k + 4] for k in range(0, len(rest), 4)]; j = i + 1
        if head is None:
            out.append(words[i]); i += 1
            continue
        spoken = " ".join(_LETTER_NAMES[c] for c in head[:2]) + " " + head[2:] + ", " \
            + ", ".join(" ".join(_DIGIT_NAMES[int(d)] for d in g) for g in groups)
        out.append(lead + spoken + trail); i = j
    return " ".join(out)


def _is_number_token(t: str) -> bool:
    """Digits with at most decimal / thousands separators ("3", "1920", "2,5", "1.080")."""
    return bool(t) and t[0].isdigit() and t[-1].isdigit() and all(c.isdigit() or c in ",." for c in t)


def _expand_times_sign(text: str) -> str:
    """"3 x 4", "1920 x 1080", "3x4", "3 × 4" -> "3 por 4": a multiplication or dimension sign between numbers is read
    "por" in pt-PT. The x was read as the letter "xis" and "×" was dropped ("três quatro") (the listener, 2026-11-01).
    Only between two plain numbers: "0x1F" (hexadecimal) and "x" as a letter elsewhere are left alone. Token scan."""
    out = []
    for w in text.split():
        lead, core, trail = _split_edges(w)
        for sign in ("x", "X", "×"):
            if sign in core and core.count(sign) == 1:
                left, _, right = core.partition(sign)
                if _is_number_token(left) and _is_number_token(right):
                    w = lead + left + " por " + right + trail
                    break
        out.append(w)
    for i in range(1, len(out) - 1):
        lead, core, trail = _split_edges(out[i])
        if core in ("x", "X", "×") and not lead and _is_number_token(_split_edges(out[i - 1])[1]) \
                and _is_number_token(_split_edges(out[i + 1])[1]):
            out[i] = "por" + trail
    return " ".join(out)


# 1st-person present verb forms (-o) that are also nouns ("gosto", "almoço", "jogo", "olho", "começo"): the noun has a closed
# stem vowel, the verb an open one, and the spelling does not say which word it is (_verb_vowel leaves them alone).
# After a word that only a verb can follow -- the subject "eu", a negation, a clitic pronoun, a time adverb -- the verb is
# meant, and it is respelled with its accent so the written-accent rules open the vowel: "Eu gosto" -> "Eu gósto",
# "hoje almoço" -> "hoje almóço" (the listener, 2026-11-01). Anything else (an article, "do", a possessive) keeps the
# noun's reading. Not "só", "o", "a": they precede nouns too.
_VERB_CUES = frozenset({"eu", "não", "nunca", "jamais", "também", "já", "ainda", "sempre", "hoje", "agora", "amanhã",
                        "me", "te", "se", "lhe", "nos", "vos"})


def _stressed_stem_vowel(w: str) -> int:
    """Index of the vowel letter of the penultimate syllable of a word ending in a vowel ("almoço" -> the o of "mo"),
    or -1. Skips the final vowel and the consonants before it."""
    i = len(w) - 1
    if i < 0 or w[i] not in "aeo":
        return -1
    i -= 1
    while i >= 0 and w[i] not in "aeiouáéíóúâêôãõ":
        i -= 1
    return i if i >= 0 and w[i] in "eo" and (i == 0 or w[i - 1] not in "aeiou") else -1


def _respell_verb_homographs(text: str) -> str:
    words = text.split()
    for k in range(1, len(words)):
        lead, core, trail = _split_edges(words[k])
        low = core.lower()
        prev_lead, prev, prev_trail = _split_edges(words[k - 1])
        if not core.islower() or not low.endswith("o") or prev.lower() not in _VERB_CUES or prev_trail or lead:
            continue                                  # 1st-person -o forms only: "já ela", "não deve" must not change
        if _VERB_VOWEL_OF(low) not in ("O", "E") or not (_gender.noun_gender(low) or _gender.adjective_gender(low)):
            continue
        i = _stressed_stem_vowel(core)
        if i >= 0:
            words[k] = lead + core[:i] + {"o": "ó", "e": "é"}[core[i]] + core[i + 1:] + trail
    return " ".join(words)


def _expand_percent(text: str) -> str:
    """"3,5%" / "12 %" -> "3,5 por cento": a percent sign glued to its number kept the number from being expanded (its
    digits were dropped: "a taxa é de 3,5%" was read "três vírgula", measured 2026-10-24). Char-level: every '%' becomes
    " por cento" (and '‰' " por mil"); the number before it is then a plain number token."""
    return text.replace("%", " por cento").replace("‰", " por mil").replace("  por", " por")


# Unit symbols after a number, read as pt-PT words (singular, plural). Left raw, "kg" phonemized as the vowel-less
# cluster ˈkɡ and "€" was dropped by the tokenizer, so "Custa 5 €." was read "Custa cinco." (measured 2026-10-24).
_UNITS = {
    "km": ("quilómetro", "quilómetros"), "m": ("metro", "metros"), "cm": ("centímetro", "centímetros"),
    "mm": ("milímetro", "milímetros"), "km/h": ("quilómetro por hora", "quilómetros por hora"),
    "m²": ("metro quadrado", "metros quadrados"), "km²": ("quilómetro quadrado", "quilómetros quadrados"),
    "m³": ("metro cúbico", "metros cúbicos"), "ha": ("hectare", "hectares"),
    "kg": ("quilo", "quilos"), "g": ("grama", "gramas"), "mg": ("miligrama", "miligramas"),
    "t": ("tonelada", "toneladas"), "l": ("litro", "litros"), "L": ("litro", "litros"),
    "ml": ("mililitro", "mililitros"), "cl": ("centilitro", "centilitros"), "dl": ("decilitro", "decilitros"),
    "h": ("hora", "horas"), "min": ("minuto", "minutos"), "s": ("segundo", "segundos"),
    # "3,5 kWh" was read "k dâblio agá" (numbers/dates exercise text, 2026-10-25)
    "W": ("watt", "watts"), "kW": ("quilowatt", "quilowatts"), "MW": ("megawatt", "megawatts"),
    "Wh": ("watt-hora", "watts-hora"), "kWh": ("quilowatt-hora", "quilowatts-hora"),
    "MWh": ("megawatt-hora", "megawatts-hora"),
}
_CURRENCIES = {"€": ("euro", "euros"), "$": ("dólar", "dólares"), "£": ("libra", "libras")}
_SCALE_WORDS = frozenset({"mil", "milhão", "milhões", "bilião", "biliões"})


def _is_raw_number(s: str) -> bool:
    """"5", "2,50", "1.234,5", "-3": digits with European separators, before _normalize_number_separators runs."""
    s = s[1:] if s[:1] in "-+" else s
    return bool(s) and s[0].isdigit() and s[-1].isdigit() and all(c.isdigit() or c in ".," for c in s)


def _amount(num: str, unit: str) -> str:
    """'2,50' + '€' -> '2 euros e 50 cêntimos'; '1' + 'km' -> '1 quilómetro'; '2,5' + 'km' -> '2,5 quilómetros'."""
    if unit in _CURRENCIES:
        sing, plur = _CURRENCIES[unit]
        whole, comma, cents = num.rpartition(",")
        if comma and len(cents) == 2 and whole:
            units_n = int(whole.lstrip("-+").replace(".", "") or 0)
            cents_n = int(cents)
            parts = []
            if units_n:
                parts.append(f"{whole} {sing if units_n == 1 else plur}")
            if cents_n or not units_n:
                parts.append(f"{cents_n} {'cêntimo' if cents_n == 1 else 'cêntimos'}")
            return " e ".join(parts)
        n = num.lstrip("-+").replace(".", "")
        if n.isdigit() and int(n) >= 1_000_000 and int(n) % 1_000_000 == 0:
            return f"{num} de {plur}"                  # "300 000 000 €" -> "trezentos milhões de euros"
    else:
        sing, plur = _UNITS[unit]
        # a half is said as such: "3,5 kg" -> "3 quilos e meio", "0,5 l" -> "meio litro", "1,5 h" -> "1 hora e meia"
        # (native listener, 2026-10-25). ".5" too: one digit after a dot cannot be a thousands group.
        whole, sep, frac = num.rpartition("," if "," in num else ".")
        # not for compound units: "3,5 kWh" read "três quilowatts-hora e meio"
        if sep and frac == "5" and whole.lstrip("-+").isdigit() and " " not in sing and "-" not in sing:
            half = "meia" if sing in _FEM_UNITS else "meio"
            if int(whole.lstrip("-+")) == 0:
                return f"{half} {sing}"
            return f"{whole} {sing if whole.lstrip('-+') == '1' else plur} e {half}"
    return f"{num} {sing if num.lstrip('-+') == '1' else plur}"


_FEM_UNITS = frozenset({"hora", "tonelada"})


def _split_number_prefix(core: str) -> tuple[str, str]:
    """'5km' -> ('5', 'km'); '2,50€' -> ('2,50', '€'). ('', core) when core does not start with a number."""
    i = 1 if core[:1] in "-+" else 0
    j = i
    while j < len(core) and (core[j].isdigit() or core[j] in ".,"):
        j += 1
    while j > i and core[j - 1] in ".,":
        j -= 1
    num = core[:j]
    return (num, core[j:]) if _is_raw_number(num) else ("", core)


def _expand_units(text: str) -> str:
    """Units and currencies after (or, for currencies, before) a number: "2 kg" -> "2 quilos", "5€" -> "5 euros",
    "€ 2,50" -> "2 euros e 50 cêntimos", "100 km/h" -> "100 quilómetros por hora". Also the pt-PT clock form
    "16h30" -> "16 e 30" and "9h" -> "9 horas". Only next to a number, so a lone "m" or "g" is untouched.
    Token scan (no regex). Runs before _normalize_number_separators, which still has to see "2,50"."""
    words = text.split()
    out: list[str] = []
    i = 0
    while i < len(words):
        lead, core, trail = _split_edges(words[i])
        num, rest = _split_number_prefix(core)
        if num and (rest in _UNITS or rest in _CURRENCIES):                         # "5km", "5€"
            out.append(lead + _amount(num, rest) + trail)
        elif num and rest[:1] == "h" and (rest == "h" or (len(rest) == 3 and rest[1:].isdigit())) \
                and num.isdigit() and int(num) <= 23:                                 # "16h30", "9h"
            hour = _FEM_HOURS.get(int(num), num)
            whole = rest in ("h", "h00")                                               # "15h00" -> "15 horas"
            out.append(lead + (f"{hour} {'hora' if num == '1' else 'horas'}" if whole
                               else f"{hour} e {int(rest[1:])}") + trail)
        elif core[:1] in _CURRENCIES and _is_raw_number(core[1:]):                    # "€5"
            out.append(lead + _amount(core[1:], core[0]) + trail)
        elif core in _CURRENCIES and not trail and i + 1 < len(words) and not _split_edges(words[i + 1])[0] \
                and _is_raw_number(_split_edges(words[i + 1])[1]):                      # "€ 5"
            _, ncore, ntrail = _split_edges(words[i + 1])
            out.append(lead + _amount(ncore, core) + ntrail)
            i += 2
            continue
        elif (core in _UNITS or core in _CURRENCIES) and not lead and out:           # "5 km", "2,50 €", "300 mil €"
            plead, pcore, ptrail = _split_edges(out[-1])
            if _is_raw_number(pcore) and not ptrail:
                out[-1] = plead + _amount(pcore, core) + trail
            elif core in _CURRENCIES and not ptrail and pcore in _SCALE_WORDS and len(out) >= 2 \
                    and _is_raw_number(_split_edges(out[-2])[1]):
                # "300 mil €" -> "300 mil euros"; "2 milhões €" -> "2 milhões de euros"
                plural = _CURRENCIES[core][1]
                out.append(("de " if pcore != "mil" else "") + plural + trail)
            elif core in _CURRENCIES:                                             # a lone sign: "o €" -> "o euro"
                out.append(_CURRENCIES[core][0] + trail)
            else:
                out.append(words[i])
        elif core in _CURRENCIES:
            out.append(lead + _CURRENCIES[core][0] + trail)
        else:
            out.append(words[i])
        i += 1
    return " ".join(out)


_DEGREE_SCALES = {"C": "Celsius", "F": "Fahrenheit"}


def _expand_degrees(text: str) -> str:
    """"20°" -> "20 graus", "-3 °C" -> "-3 graus Celsius", "1°" -> "1 grau". The degree sign is not in the vocab and,
    glued to its number, kept the number from being expanded, so "Temperatura de 20°." was read "Temperatura de"
    (measured 2026-10-24). Token scan (no regex); a '°' not preceded by a number is left alone."""
    toks = text.split()
    out = []
    for i, w in enumerate(toks):
        # "21,5 ºC": the ordinal mark º typed for the degree sign (read "º cê", 2026-10-25); only before C/F, as "1º"
        # alone is an ordinal
        w = w.replace("ºC", "°C").replace("ºF", "°F")
        lead, core, trail = _split_edges(w)
        num, deg, scale = core.partition("°")
        if deg and not num and out:                     # "20 °C": the sign is its own token, the number before it
            prev = _split_edges(out[-1])[1]
            num_ok = prev.replace(",", "").replace(".", "").lstrip("-").isdigit()
            if num_ok and scale in ("", *_DEGREE_SCALES):
                unit = "grau" if prev == "1" else "graus"
                out.append(lead + " ".join(x for x in (unit, _DEGREE_SCALES.get(scale, "")) if x) + trail)
                continue
        if deg and num.replace(",", "").replace(".", "").lstrip("-").isdigit() and scale in ("", *_DEGREE_SCALES):
            unit = "grau" if num == "1" else "graus"
            out.append(lead + " ".join(x for x in (num, unit, _DEGREE_SCALES.get(scale, "")) if x) + trail)
            continue
        out.append(w)
    return " ".join(out)


_DIGIT_NAMES = ["zero", "um", "dois", "três", "quatro", "cinco", "seis", "sete", "oito", "nove"]
_PHONE_PREFIXES = {"+351": "mais três cinco um,", "00351": "zero zero três cinco um,"}


def _is_phone_start(digits: str) -> bool:
    # pt-PT: 2 landline, 9 mobile, 3 nomadic, 7 shared-cost (707/708), 8 freephone (800/808)
    return len(digits) == 9 and digits[0] in "23789"


def _read_digits(digits: str) -> str:
    """'912345678' -> 'nove um dois, três quatro cinco, seis sete oito' (digit by digit, a pause per group of 3)."""
    return ", ".join(" ".join(_DIGIT_NAMES[int(c)] for c in digits[k:k + 3]) for k in range(0, len(digits), 3))


def _read_digit_groups(groups: list) -> str:
    """The groups as written ("21 123 4567", "800 20 30 40"), digit by digit, a pause between groups."""
    return ", ".join(" ".join(_DIGIT_NAMES[int(c)] for c in g) for g in groups)


_NOT_AFTER_A_PHONE = set(_CURRENCIES) | {"euros", "euro", "€", "mil", "milhões", "milhão", "dólares", "pessoas"}


def _expand_phone_numbers(text: str) -> str:
    """Portuguese phone numbers, read digit by digit in the groups they are written in: "912 345 678", "912345678",
    "21 123 4567", "800 20 30 40", "707 200 500", with "+351", "(+351)" or "00351" in front. Nine digits starting with 2,
    3, 7, 8 or 9, in up to four space-separated groups of 2-4 digits (or one run, read 3+3+3). Up to 0.1.11 only 3+3+3
    and whole runs were recognised: "21 123 4567" was read as thousands and "707 200 500" as millions (reported by
    the Cortex agent, 2026-10-25). An amount ("300 000 000 €", groups of 000) is left alone. Token scan (no regex)."""
    words = text.split()
    out, i = [], 0
    while i < len(words):
        lead, core, trail = _split_edges(words[i])
        prefix, j = "", i
        bare = core.strip("()")
        if bare in _PHONE_PREFIXES and i + 1 < len(words) and trail.strip(")") == "":
            prefix, j = _PHONE_PREFIXES[bare] + " ", i + 1
            lead, core, trail = _split_edges(words[j])
            lead = lead.replace("(", "")
        groups, last, end_trail = [], j, trail
        if core.isdigit() and len(core) == 9:
            groups, last = [core[:3], core[3:6], core[6:]], j
        elif core.isdigit() and 2 <= len(core) <= 4:
            k, acc, tr = j, [core], trail
            while sum(map(len, acc)) < 9 and not tr and k + 1 < len(words) and len(acc) < 4:
                l2, c2, t2 = _split_edges(words[k + 1])
                if l2 or not (c2.isdigit() and 2 <= len(c2) <= 4):
                    break
                acc.append(c2); tr = t2; k += 1
            if sum(map(len, acc)) == 9 and len(acc) > 1:
                groups, last, end_trail = acc, k, tr
        nxt = _split_edges(words[last + 1])[1].lower() if last + 1 < len(words) else ""
        if groups and _is_phone_start("".join(groups)) and "000" not in groups[1:] and nxt not in _NOT_AFTER_A_PHONE:
            # a pause after the number when a word follows: "sete oito nove ou pelo..." was heard glued (2026-10-25)
            if not end_trail and last + 1 < len(words):
                end_trail = ","
            out.append(lead + prefix + _read_digit_groups(groups) + end_trail)
            i = last + 1
            continue
        out.append(words[i])
        i += 1
    return " ".join(out)


def _join_spaced_thousands(text: str) -> str:
    """pt-PT's official thousands separator is a space: "1 000", "2 300 000". Up to 0.1.4 the groups were read as
    separate numbers ("um zero"). A 1-3 digit group followed by groups of exactly 3 digits, with no punctuation
    between, is one number. Runs after _expand_phone_numbers, which claims 3+3+3 phone numbers first. Token scan."""
    words = text.split()
    out, i = [], 0
    while i < len(words):
        lead, core, trail = _split_edges(words[i])
        j, joined = i, core
        while (not trail and core.isdigit() and 1 <= len(core) <= 3 and j + 1 < len(words)):
            l2, c2, t2 = _split_edges(words[j + 1])
            if l2 or not (c2.isdigit() and len(c2) == 3):
                break
            joined += c2; trail = t2; j += 1
        if j > i:
            out.append(lead + joined + trail); i = j + 1
            continue
        out.append(words[i]); i += 1
    return " ".join(out)


_MONTHS = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro",
           "novembro", "dezembro"]
_FRACTIONS = {2: ("meio", "meios"), 3: ("terço", "terços"), 4: ("quarto", "quartos"), 5: ("quinto", "quintos"),
              6: ("sexto", "sextos"), 7: ("sétimo", "sétimos"), 8: ("oitavo", "oitavos"), 9: ("nono", "nonos"),
              10: ("décimo", "décimos"), 100: ("centésimo", "centésimos"), 1000: ("milésimo", "milésimos")}
_REFERENCE_NOUNS = frozenset({"lei", "decreto", "decreto-lei", "portaria", "despacho", "processo", "acórdão",
                              "regulamento", "resolução", "diretiva", "circular", "aviso", "norma", "número", "n.º"})


def _fraction(a: int, b: int, next_word: str) -> tuple[str, bool]:
    """'1/2' + 'chávena' -> ('meia', False); '3/4' + 'h' -> ('3 quartos de hora', True: the unit was consumed)."""
    unit = _UNITS.get(next_word)
    noun = unit[0] if unit else next_word.lower()
    g = _gender.noun_gender(noun)
    fem = g == _gender.FEM
    if b == 2 and a == 1:
        word = "meia" if fem else "meio"
        return (f"{word} {unit[0]}", True) if unit else (word, False)
    if b in _FRACTIONS:
        sing, plur = _FRACTIONS[b]
        frac = f"{a} {sing if a == 1 else plur}"
    else:
        frac = f"{a} {b} {'avo' if a == 1 else 'avos'}"
    return (f"{frac} de {unit[0]}", True) if unit else (frac, False)


def _expand_slashes(text: str) -> str:
    """Numbers with slashes, which the model cannot read (no '/' token: up to 0.1.4 the whole token was DROPPED, so
    "a reunião é a 24/10/2026" was read "a reunião é a"). Token scan (no regex):
      24/10/2026 -> "24 de outubro de 2026"; 5/3 -> "5 de março" (a valid day/month, not before a noun);
      1/2 chávena -> "meia chávena"; 3/4 h -> "3 quartos de hora"; 2/3 -> "2 terços" (before a noun or a unit, or not
      a valid date); Lei 2/2020 -> "Lei 2 barra 2020" (after a reference noun). Words with a slash ("e/ou") are left."""
    words = text.split()
    out, i = [], 0
    while i < len(words):
        lead, core, trail = _split_edges(words[i])
        parts = core.split("/")
        prev = _split_edges(words[i - 1])[1].lower() if i > 0 else ""
        lettered = len(parts) == 2 and prev in _REFERENCE_NOUNS and parts[1].isdigit() and "-" in parts[0] \
            and parts[0].split("-")[0].isdigit() and len(parts[0].split("-")[1]) == 1 and parts[0][-1].isalpha()
        if lettered:                     # "DL n.º 74-A/2017": the 74 was dropped and the slash lost (Cortex agent, 0.1.16)
            num, letter = parts[0].split("-")
            out.append(lead + f"{num} {_LETTER_NAMES.get(letter.upper(), letter)} barra {parts[1]}" + trail); i += 1
            continue
        if len(parts) not in (2, 3) or not all(x.isdigit() for x in parts):
            out.append(words[i]); i += 1
            continue
        n = [int(x) for x in parts]
        prev = _split_edges(words[i - 1])[1].lower() if i > 0 else ""
        nxt = _split_edges(words[i + 1])[1] if i + 1 < len(words) and not trail else ""
        valid_date = 1 <= n[0] <= 31 and 1 <= n[1] <= 12
        after = _split_edges(words[i + 2])[1] if i + 2 < len(words) else ""
        # a fraction is typically followed by its noun or "do/da" ("2/3 do leite"); a date by nothing or "de <year>"
        before_noun = bool(nxt) and (nxt in _UNITS or nxt.lower() in ("do", "da", "dos", "das")
                                     or (nxt.lower() == "de" and not (after.isdigit() and len(after) == 4))
                                     or (nxt.lower() not in _NOT_COUNTED and _gender.noun_gender(nxt) is not None))
        consumed = False
        if prev in _REFERENCE_NOUNS:
            spoken = " barra ".join(parts)
        elif len(parts) == 3:
            spoken = f"{parts[0]} de {_MONTHS[n[1] - 1]} de {parts[2]}" if valid_date else " barra ".join(parts)
        elif valid_date and not before_noun:
            spoken = f"{parts[0]} de {_MONTHS[n[1] - 1]}"
        elif n[1] >= 2:
            spoken, consumed = _fraction(n[0], n[1], nxt)
        else:
            spoken = " barra ".join(parts)
        if consumed:
            trail = _split_edges(words[i + 1])[2]
            i += 1
        out.append(lead + spoken + trail)
        i += 1
    return " ".join(out)


def _spell_dotted_abbreviations(text: str) -> str:
    """"D.O." / "S.A." / "E.U.A." -> letter names ("dê ó"). Up to 0.1.4 "D.O." hit the honorific rule and was read
    "Dom O.". The final '.' ends the sentence only before a capitalised word or at the end. Token scan (no regex)."""
    words = text.split()
    out = []
    for i, w in enumerate(words):
        lead, rest = "", w
        while rest[:1] in _LEAD_PUNCT and rest:
            lead, rest = lead + rest[0], rest[1:]
        tail = ""
        while rest and rest[-1] in ",;:!?)\"”…":
            tail, rest = rest[-1] + tail, rest[:-1]
        letters = rest[0::2]
        is_abbr = (len(rest) >= 4 and len(rest) % 2 == 0 and rest[1::2] == "." * (len(rest) // 2)
                   and letters.isupper() and all(c in _LETTER_NAMES for c in letters))
        if not is_abbr:
            out.append(w)
            continue
        nxt = words[i + 1] if i + 1 < len(words) else ""
        end = "." if (not nxt or _split_edges(nxt)[1][:1].isupper()) and not tail else ""
        out.append(lead + " ".join(_LETTER_NAMES[c] for c in letters) + (tail or end or ","))
    return " ".join(out)


def _expand_numeric_dates(text: str) -> str:
    """Numeric dates with dots or dashes: "2026.05.07", "2026-05-07", "07-05-2026", "07.05.2026" -> "7 de maio de
    2026". Up to 0.1.6 a dotted date became one 8-digit number and a dashed one a range ("2026 a 05 a 07"). Only three
    numeric parts forming a valid date, with the year (4 digits) first or last. Token scan (no regex)."""
    out = []
    for tok in text.split():
        lead, core, trail = _split_edges(tok)
        for sep in (".", "-"):
            parts = core.split(sep)
            if len(parts) == 3 and all(x.isdigit() for x in parts):
                if len(parts[0]) == 4:
                    y, m, d = parts
                elif len(parts[2]) == 4:
                    d, m, y = parts
                else:
                    continue
                if 1 <= int(d) <= 31 and 1 <= int(m) <= 12:
                    tok = f"{lead}{int(d)} de {_MONTHS[int(m) - 1]} de {y}{trail}"
                    break
        out.append(tok)
    return " ".join(out)


_OPTIONAL_SUFFIXES = ("(s)", "(es)", "(a)", "(as)", "(o)", "(os)")


def _drop_optional_suffixes(text: str) -> str:
    """"Executado(s)" -> "Executados", "caro(a)" -> "caro": a written optional ending cannot be spoken; the plural
    reading keeps the most information. Up to 0.1.6 the "(s)" became a stray ʃ. Token scan (no regex)."""
    out = []
    for tok in text.split():
        for suf in _OPTIONAL_SUFFIXES:
            k = tok.find(suf)
            if k > 0 and tok[k - 1].isalpha():
                tok = tok[:k] + ("s" if suf in ("(s)", "(es)") else "") + tok[k + len(suf):]
                break
        out.append(tok)
    return " ".join(out)


def _split_camel_case(text: str) -> str:
    """"DevOps" -> "Dev Ops", "IdP" -> "Id P", "eSign" -> "e Sign", "OAuth" -> "O Auth": an identifier glued from words
    was read as one word. Splits at lower->upper and at the last capital of a capital run before lowercase. ALL-CAPS
    acronyms and ordinary capitalised words are untouched. Token scan (no regex)."""
    out = []
    for tok in text.split():
        lead, core, trail = _split_edges(tok)
        plural_acronym = len(core) > 2 and core.endswith("s") and core[:-1].isupper()         # "ONGs", "PMEs"
        brand = core.lower() in _BRAND_WORDS                                                   # "SharePoint": one name
        if plural_acronym or brand or not core.isalpha() or core.isupper() or core.islower() or not any(c.isupper() for c in core[1:]):
            out.append(tok)
            continue
        pieces, cur = [], core[0]
        for k in range(1, len(core)):
            c, prev = core[k], core[k - 1]
            nxt = core[k + 1] if k + 1 < len(core) else ""
            if c.isupper() and (prev.islower() or (nxt and nxt.islower() and prev.isupper())):
                pieces.append(cur); cur = c
            else:
                cur += c
        pieces.append(cur)
        out.append(lead + " ".join(pieces) + trail)
    return " ".join(out)


def _spell_consonant_tail(label: str) -> str:
    """A domain label ending in three or more consonants is a word plus an acronym ("bancoctt" = banco + CTT, read
    ˈbɐ̃kuktt, found from the Cortex agent's e-mail case, 2026-10-25): the tail is spelled. Only in dotted words."""
    k = len(label)
    while k > 0 and label[k - 1].isalpha() and label[k - 1].lower() not in "aeiouyáéíóúâêôãõà":
        k -= 1
    tail = label[k:]
    # only after a dictionary word ("banco"): "appsettings", "PATCH" end in consonant clusters too (corpus diff)
    if len(tail) >= 3 and k >= 3 and label[:k].isalpha() and _in_dictionary(label[:k].lower()) \
            and all(c.upper() in _LETTER_NAMES for c in tail):
        return label[:k] + " " + " ".join(_LETTER_NAMES[c.upper()] for c in tail)
    return label


def _split_dotted_words(text: str) -> str:
    """"Node.js" -> "Node ponto js", "exemplo.csv" -> "exemplo ponto csv": a dot between two letters inside a token
    (file names, domains). Dotted abbreviations ("D.O.", "n.º") are handled earlier. Token scan (no regex)."""
    out = []
    for tok in text.split():
        lead, core, trail = _split_edges(tok)
        if "." in core and core.count(".") <= 3 and all(p and p.isalnum() for p in core.split(".")) \
                and any(len(p) > 1 for p in core.split(".")) and not core.replace(".", "").isdigit() \
                and not all(core[k - 1].isdigit() and core[k + 1].isdigit() for k, c in enumerate(core) if c == "."):
            # a dot between two digits is a number's ("3.5kg", "dc2.0"): the unit and separator steps read it
            core = " ponto ".join(_spell_consonant_tail(p) for p in core.split("."))
        out.append(lead + core + trail)
    return " ".join(out)


def _split_letter_digit_tokens(text: str) -> str:
    """"PSD2" -> "PSD 2", "B2C" -> "B 2 C", "canais2" -> "canais 2", "D365" -> "D 365": letters and digits glued in one
    token. The letter parts are then spelled or read as words by the steps after. Token scan (no regex)."""
    out = []
    for tok in text.split():
        lead, core, trail = _split_edges(tok)
        # each hyphen part on its own: "ms-devices-be-v1-blue" must split "v1" in the FIRST pass, or the hyphenated-
        # acronym step frees "v1" and the second pass splits it (non-idempotent, found by the corpus check 2026-10-25)
        # A split part is set apart by spaces, and so is a number joined to a word by "-" or "/" ("1.2.0-ci",
        # "2.0/OpenID"): a digit left glued to the mark is dropped by the phonemizer (measured 2026-10-25).
        pieces, seps, cur = [], [], ""
        for c in core:
            if c in "-/" and cur:
                pieces.append(cur); seps.append(c); cur = ""
            else:
                cur += c
        pieces.append(cur)
        done = [_split_letter_digit_part(p) for p in pieces]
        out_core = done[0]
        for k in range(1, len(done)):
            a, b = pieces[k - 1], pieces[k]
            apart = done[k] != b or done[k - 1] != a or (_is_raw_number(a) != _is_raw_number(b)
                                                       and any(ch.isalpha() for ch in a + b)
                                                       and not (seps[k - 1] == "-" and (a + b).replace(".", "").isupper()))
            # (an upper-case acronym and a number across a HYPHEN, "COVID-19", are read by the acronym step)
            out_core += (" " if apart else seps[k - 1]) + done[k]
        core = out_core
        out.append(lead + core + trail)
    return " ".join(out)


def _split_letter_digit_part(core: str) -> str:
    # a "." or "," between digits belongs to the number ("dc2.0" -> "dc" + "2.0"); the separator step reads it later
    plain = core.replace(".", "").replace(",", "")
    if not (plain.isalnum() and any(c.isdigit() for c in core) and any(c.isalpha() for c in core)
            and not (core[-1:] in "ºª") and core[0].isalnum() and core[-1].isalnum()):
        return core
    if any(core[i] in ".," and not (core[i - 1].isdigit() and core[i + 1].isdigit()) for i in range(1, len(core) - 1)):
        return core                                       # a dot between words ("e.g") is not a number's
    parts, cur = [], core[0]
    for c in core[1:]:
        if c in ".,":
            cur += c
        elif c.isdigit() != (cur[-1].isdigit() or cur[-1] in ".,"):
            parts.append(cur); cur = c
        else:
            cur += c
    parts.append(cur)
    # a single letter or a vowel-less letter group is spelled HERE: left bare beside a number, a later pass
    # read it as a unit ("k8s" -> "k 8 s" -> "8 segundos"), measured by the idempotence check
    spelled = []
    for part in parts:
        if part.isalpha() and (len(part) == 1 or not any(c in "aeiouyáéíóúâêôãõàAEIOUY" for c in part)) \
                and all(c.upper() in _LETTER_NAMES for c in part):
            spelled.append(" ".join(_LETTER_NAMES[c.upper()] for c in part))
        else:
            spelled.append(part)
    return " ".join(spelled)


# pt-PT abbreviations read as letters by the voice (audio round trip, 2026-10-25: "Obs." heard "ó bê ésse", "ex." as
# "es ponto", "etc." as "é tê cê"). Only with their dot or colon: a bare "ex" stays (ex-ministro is a hyphenated word).
_ABBREV_WORDS = {"obs": ("Observação", "observação"), "ex": ("Exemplo", "por exemplo"), "etc": ("Etcétera", "etcétera"),
                 "p.ex": ("Por exemplo", "por exemplo"), "p. ex": ("Por exemplo", "por exemplo"),
                 # found by the numbers/dates exercise text (2026-10-25): "séc." and "art." ended the sentence and
                 # "séc. XX" was read "séc. vigésimo"
                 "séc": ("Século", "século"), "sécs": ("Séculos", "séculos"), "art": ("Artigo", "artigo"),
                 "arts": ("Artigos", "artigos"), "pág": ("Página", "página"), "págs": ("Páginas", "páginas"),
                 "cap": ("Capítulo", "capítulo"), "vol": ("Volume", "volume"),
                 # "0,25 p.p." stayed "p. p." (Cortex agent, 0.1.16): percentage points
                 "p.p": ("Pontos percentuais", "pontos percentuais")}


# followed by what they refer to, never the end of a sentence: "séc. XX" (a capital Roman numeral) is one phrase
_REF_ABBREVS = frozenset({"séc", "sécs", "art", "arts", "pág", "págs", "cap", "vol"})


def _expand_common_abbreviations(text: str) -> str:
    words = text.split()
    out = []
    i = 0
    while i < len(words):
        w = words[i]
        if w.lower() == "p." and i + 1 < len(words) and _split_edges(words[i + 1])[1].lower() == "ex" \
                and _split_edges(words[i + 1])[2][:1] in (".", ":"):
            w = "p. " + words[i + 1]; i += 1                  # "p. ex." written with a space
        lead, core, trail = _split_edges(w)
        key = core.lower()
        if core.endswith("ª") and core in _ABBREVIATIONS:        # "Sr.ª", "Eng.ª": the later dotted-word split read
            out.append(lead + _ABBREVIATIONS[core] + trail)      # "Sr.ª" as "ésse érre, ponto ª" (2026-10-25)
        elif key in _ABBREV_WORDS and trail[:1] in (".", ":"):
            upper, lower = _ABBREV_WORDS[key]
            word = upper if core[:1].isupper() else lower
            if key == "ex" and out and _split_edges(out[-1])[1].lower() == "por":
                word = "exemplo"                                  # "por ex." -> "por exemplo"
            if key == "p.p" and out and _split_edges(out[-1])[1] in ("1", "um"):
                word = "ponto percentual"                          # "1 p.p."
            rest = trail[1:] if trail[:1] == "." else trail      # the abbreviation's own dot is not punctuation...
            nxt = words[i + 1] if i + 1 < len(words) else ""
            if trail == "." and (not nxt or (nxt[:1].isupper() and key not in _REF_ABBREVS)):
                rest = "."                                        # ...unless it also ends the sentence ("..., etc.")
            out.append(lead + word + rest)
        else:
            out.append(words[i] if w == words[i] else w)
        i += 1
    return " ".join(out)


# Inline pronunciation overrides, for the words the front-end still gets wrong (a name, a brand) without waiting for a
# release: "[Cortex](Córtex)" reads the word as respelled in Portuguese, "[Cortex](/ˈkɔɾtɛkʃ/)" reads exactly those
# phonemes ("'" may stand for the stress mark). The syntax is misaki's (Kokoro's English G2P), which TugaPhone lacks.
# An override is swapped for a placeholder word that survives normalisation and the sentence split untouched, and the
# placeholder is read as its phonemes in _raw_phonemize. A markdown link "[texto](https://...)" is read as its text
# (the address was read out letter by letter); any other "(...)" is left as it was, and phonemes outside the model's
# vocabulary drop the markup so the word is read normally.
_OVERRIDES: dict = {}
_OVERRIDE_PREFIX = "ouvriz"
_RESPELL_OK = set(" -'")


def _override_word(label: str, target: str) -> Optional[str]:
    target = target.strip()
    if len(target) > 2 and target[0] == "/" and target[-1] == "/":
        ps = unicodedata.normalize("NFD", target[1:-1].strip()).replace("'", "ˈ")
        if not ps or any(c not in VOCAB or c in KEEP_PUNCT for c in ps):
            return label
        h = int(hashlib.sha1(ps.encode("utf-8")).hexdigest()[:12], 16)
        key = _OVERRIDE_PREFIX
        for _ in range(4):                       # word-like syllables, so no other rule mistakes it for an acronym
            h, r = divmod(h, 60)
            key += "bdfglmnprstv"[r // 5] + "aeiou"[r % 5]
        _OVERRIDES[key] = ps
        return key
    if target and all(c.isalpha() or c in _RESPELL_OK for c in target):
        return target
    if target.startswith(("http://", "https://", "www.", "mailto:")):
        return label                             # a markdown link: its text is read, never the address
    return None


def _expand_emails(text: str) -> str:
    """"apoio@bancoctt.pt" -> "apoio arroba bancoctt.pt" (the domain is read by the dotted-word step): the "@" is not in
    the vocab and was silently dropped (Cortex agent, 0.1.16). Token scan."""
    out = []
    for tok in text.split():
        lead, core, trail = _split_edges(tok)
        user, at, domain = core.partition("@")
        if at and user and "." in domain and "@" not in domain:
            core = f"{user} arroba {domain}"
        out.append(lead + core + trail)
    return " ".join(out)


def _expand_decree_law(text: str) -> str:
    """"DL n.º 74-A/2017": "DL" before a number reference is "Decreto-Lei" (it was spelled "dê éle," with a pause)."""
    words = text.split()
    for i in range(len(words) - 1):
        lead, core, trail = _split_edges(words[i])
        if core == "DL" and not trail and _split_edges(words[i + 1])[1].lower() in ("n.º", "nº", "n."):
            words[i] = lead + "Decreto-Lei" + trail
    return " ".join(words)


def _apply_inline_overrides(text: str) -> str:
    out, i = [], 0
    while True:
        b = text.find("](", i)
        if b < 0:
            break
        a = text.rfind("[", i, b)
        c = text.find(")", b + 2)
        if c < 0:
            break
        rep = None if a < 0 or "]" in text[a + 1:b] else _override_word(text[a + 1:b], text[b + 2:c])
        if rep is None:
            out.append(text[i:b + 2])
            i = b + 2
            continue
        out.append(text[i:a] + rep)
        i = c + 1
    out.append(text[i:])
    return "".join(out)


def _drop_comma_after_e(text: str) -> str:
    """"seguro e, sobretudo, verificável": the comma after the conjunction (opening an aside) made the model pause
    around the lone "e" ("seguroo... e,"); read without it, "e sobretudo," flows (the native listener's A/B "D",
    2026-10-25). The aside's closing comma stays. Token scan."""
    words = text.split()
    return " ".join("e" if w == "e," and i + 1 < len(words) else ("E" if w == "E," and i + 1 < len(words) else w)
                    for i, w in enumerate(words))


def normalize_text(text: str) -> str:
    """Text-level normalisation applied BEFORE phonemization or any '.'-based sentence
    splitting: number separators (92.073 / 10,4), separator dashes (" – " -> ", "), acronyms
    (IA -> 'i á'), honorific abbreviations (D. -> Dom / Dona) and Roman numerals (Afonso I ->
    Afonso Primeiro, D. Maria II -> Dona Maria Segunda, século XIX -> século dezanove).
    Idempotent, so it is safe to call more than once (the TTS server calls it before its
    streaming split; phonemize() calls it too)."""
    text = _drop_comma_after_e(_expand_common_abbreviations(_expand_decree_law(_expand_emails(_modern_spelling(_apply_inline_overrides(text))))))
    text = _respell_verb_homographs(_expand_times_sign(_expand_iban(text)))
    text = _expand_slashes(_join_spaced_thousands(_expand_phone_numbers(_expand_ordinals(_expand_numeric_dates(text)))))
    text = _split_dotted_words(_drop_optional_suffixes(text))
    return _spell_lone_letters(_spell_acronyms(_expand_regnal_numerals(_expand_acronyms(_spell_dotted_abbreviations(_normalize_separator_dashes(
        _agree_with_acronyms(_split_time_colons(_expand_clock_times(_normalize_number_separators(_split_camel_case(_split_dotted_words(_expand_units(_split_letter_digit_tokens(_expand_units(_expand_degrees(_expand_percent(text)))))))))))))))))


_LONE_LETTERS = frozenset("bcdfghjklmnpqrstvwxyz")


def _spell_lone_letters(text: str) -> str:
    """A lowercase consonant letter standing alone ("a letra t", "o ponto x", "a variável b") is said by its name, as a
    capital one already is: it was read as a bare consonant (ˈt, ˈʃ), measured against a pt-PT dictionary, 2026-10-30.
    Not next to a number: "3 x 4", "1920 x 1080" (units are expanded before this)."""
    words = text.split()
    for i, w in enumerate(words):
        lead, core, trail = _split_edges(w)
        if len(core) != 1 or core not in _LONE_LETTERS:
            continue
        near = [words[k] for k in (i - 1, i + 1) if 0 <= k < len(words)]
        if any(any(c.isdigit() for c in n) for n in near):
            continue
        words[i] = lead + _LETTER_NAMES[core.upper()] + trail
    return " ".join(words)


# Pre-1990 spellings with a silent consonant are read as the modern spelling, which keeps the open vowel the consonant
# protected (Wiktionary, Portugal: "respetivo" /ʁɨʃpɛˈti.vu/ for "respectivo"; "otimizar" /ɔ.ti.miˈzaɾ/). Read as
# written, the rules reduced the vowel and said the consonant (ʁɨʃpɨˈktivu), 2026-10-30.
_OLD_SPELLINGS = (("respectiv", "respetiv"), ("excepcion", "excecion"), ("excepç", "exceç"), ("intercept", "intercet"),
                  ("optimiz", "otimiz"), ("óptim", "ótim"))


def _modern_spelling(text: str) -> str:
    out = []
    for w in text.split():
        lead, core, trail = _split_edges(w)
        low = core.lower()
        for old, new in _OLD_SPELLINGS:
            if low.startswith(old):
                core = (new.capitalize() if core[:1].isupper() else new) + core[len(old):]
                break
        out.append(lead + core + trail)
    return " ".join(out)


def _in_prefix_word(w: str) -> bool:
    """"inesquecível", "inesperado", "inexplicável": in- + es/ex + consonant."""
    low = _loan_key(w)
    return len(low) > 5 and low[:2] == "in" and low[2:4] in ("es", "ex") and low[4] not in _VOWEL_LETTERS


def _phon_in_prefix(w: str, lect: str) -> str:
    """tugaphone (and tugalex) read the prefix as "ini": "inesquecível" iniʃkɛˈsivɛl, where pt-PT has inɨʃkɛˈsivɛl
    (Wiktionary, Portugal; the user heard it wrong, 2026-10-25). The rest of the word without "in" is read right
    ("esquecível" ʃkɛˈsivɛl, "explicável" ɐjʃpliˈkavɛl), so: "in" + that, restoring the dropped initial e as ɨ."""
    rest = _phon_one(w[2:], lect)
    return "in" + ("ɨ" + rest if rest[:1] in ("ʃ", "ʒ") else rest)


# Written accent ignored (measured on a pt-PT reference pronunciation list, 2026-10-25): for a word tugalex lacks, orthography2ipa counts a final
# "-io"/"-ia" as two syllables in the spelling but one in the IPA, and anchors the stress from the end, so it lands one
# syllable early: "regulatório" ʁɨɡuˈlɐtɔɾiu, "subdomínio" suˈbduminiu. In a sample of 600 such accented reference words,
# 72 were wrong; 2 with this fix. The accent decides the stressed vowel; the final unstressed i/u before a vowel is a
# glide (ˈtɔɾju). Applied only when the stress is not already on the accented vowel.
_ACC = set("áéíóúâêô")
_OV = set("aeiouáéíóúâêôãõày")            # orthographic vowels
_IV = set("aɐeɛiɨəoɔu")                   # IPA nuclei (NFD base chars)
_FINAL_GLIDE_ENDINGS = ("io", "ia", "ios", "ias", "ea", "eas", "eo", "eos", "ua", "uas", "uo", "uos")
_ONSET2 = {"ɾ", "l"}
_STOPS = set("pbtdkɡfv")

def _nuclei_after_accent(word, glide_is_syllable: bool = False):
    """(vowel groups after the accented vowel, final -io/-ia glide?). The i/u of ói/éu/ái is the accented vowel's glide,
    not a syllable -- unless glide_is_syllable, which _fix_accent_stress needs: the IPA it re-marks still has that i as a
    vowel (sɔiʃ), turned into j only after the mark is placed."""
    low = word.lower()
    pos = [i for i, c in enumerate(low) if c in _ACC]
    if len(pos) != 1: return None
    rest = low[pos[0] + 1:]
    glide_end = low.endswith(_FINAL_GLIDE_ENDINGS) and len(rest) >= 2
    if rest[:1] in ("i", "u") and rest[1:2] not in _OV and not glide_is_syllable:
        rest = rest[1:]                  # ói, éu, ái: the i/u is the accented vowel's glide, not a syllable (sóis)
    groups, prev = 0, False
    for c in rest:
        if c in _OV:
            if not prev: groups += 1
            prev = True
        else:
            prev = False
    return groups, glide_end

def _final_glide(s: str) -> str:
    """Final unstressed -io/-ia after an accented syllable: the i (u) before the last vowel is a glide (ˈtɔɾju,
    "vídeos" ˈvidjuʃ). Also before the plural ʃ."""
    for a, b in (("iu", "ju"), ("iɐ", "jɐ"), ("ɨɐ", "jɐ"), ("ɨu", "ju"), ("uɐ", "wɐ"), ("uu", "wu")):
        for tail in ("", "ʃ"):
            if s.endswith(a + tail):
                return s[: len(s) - len(a + tail)] + b + tail
    return s


def _place_stress(s: str, k: int):
    """Put the stress mark on the nucleus with k nuclei after it, at that syllable's onset. s has no mark. Returns
    (marked string, index of the nucleus in s) or None when s has too few nuclei."""
    nuc = [i for i, c in enumerate(s) if c in _IV]
    # adjacent IPA vowels where the spelling had a diphthong are already glides (j/w), so each IV char is a nucleus
    if len(nuc) <= k:
        return None
    t = nuc[len(nuc) - 1 - k]
    j = t
    if j > 0 and s[j - 1] not in _IV and s[j - 1] not in "\u0303jw":
        j -= 1
        if s[j] in _ONSET2 and j > 0 and s[j - 1] in _STOPS: j -= 1
    elif j > 0 and s[j - 1] in "jw" and j > 1 and s[j - 2] not in _IV:
        j -= 1                                  # glide onset (kwa)
        if j > 0 and s[j - 1] not in _IV and s[j - 1] != "\u0303": j -= 1
    return s[:j] + "ˈ" + s[j:], t


def _penult_em(w: str, ps: str) -> str:
    """A word ending in unaccented -em is stressed on the syllable before it (devem, homem, conseguem). After gu/qu the
    rules counted the silent u and stressed -em itself ("conseguem" kõsɨˈɡɐ̃j̃, "querem" kɛˈɾɐ̃j̃)."""
    s = unicodedata.normalize("NFD", ps)
    if not s.rstrip("\u0303").endswith("ɐ̃j") or "ˈ" not in s:
        return ps
    tail = s.split("ˈ")[-1]
    if sum(1 for c in tail if c in _IV) != 1:      # the stress is already before -em
        return ps
    placed = _place_stress(s.replace("ˈ", ""), 1)
    return placed[0] if placed else ps


def _penult_es(ps: str) -> str:
    """-gues/-ques (consegues, chegues, sapeques): the rules counted the silent u and stressed the -es (kõsɨˈɡɛʃ); an
    unaccented word in -es is stressed on the syllable before, and that final e is reduced (kõˈsɛɡɨʃ)."""
    s = unicodedata.normalize("NFD", ps)
    if "ˈ" not in s or not s.endswith("ʃ"):
        return ps
    tail = s.split("ˈ")[-1]
    if sum(1 for c in tail if c in _IV) != 1:
        return ps
    body = s.replace("ˈ", "")
    k = max(i for i, c in enumerate(body) if c in _IV)
    body = body[:k] + "ɨ" + body[k + 1:]                    # the unstressed final e is ɨ
    placed = _place_stress(body, 1)
    return placed[0] if placed else ps


def _fix_accent_stress(word: str, ipa: str) -> str:
    r = _nuclei_after_accent(word, glide_is_syllable=True)
    if r is None or " " in ipa: return ipa
    k, glide_end = r
    s = unicodedata.normalize("NFD", ipa).replace("ˈ", "")
    if glide_end:
        s = _final_glide(s)
    placed = _place_stress(s, k)
    if placed is None: return ipa
    out, t = placed
    low = word.lower()
    a = next(i for i, c in enumerate(low) if c in _ACC)
    if low[a + 1:a + 2] in ("i", "u") and low[a + 2:a + 3] not in _OV:
        # ói, éi, ái, éu: a falling diphthong, the i/u a glide ("sóis" ˈsɔjʃ, "destrói" dɨʃˈtɾɔj)
        q = t + 1 + 1                                    # +1 for the inserted mark
        while q < len(out) and out[q] == "\u0303":
            q += 1
        if q < len(out) and out[q] in "iu":
            out = out[:q] + {"i": "j", "u": "w"}[out[q]] + out[q + 1:]
    return out


def _accented_unknown(w: str) -> bool:
    low = _loan_key(w)
    return len(low) > 3 and low.isalpha() and sum(c in _ACC for c in low) == 1 and not _in_dictionary(low)


def _stress_on_accent(word: str, ipa: str) -> bool:
    """Is the stress on the accented SYLLABLE? Both the vowel (á -> a/ɐ ...) and the position (syllables after it) must
    agree: the vowel alone is fooled by "acácio" ˈɐkasju (a stressed ɐ, on the wrong a), the position alone by "sóis"
    sɔˈiʃ (nothing after the stressed i, but it is not the ó)."""
    r = _nuclei_after_accent(word)
    s = unicodedata.normalize("NFD", ipa)
    if r is None or "ˈ" not in s:
        return False
    tail = s.split("ˈ")[-1]
    v = next((i for i, c in enumerate(tail) if c in _IV), None)
    if v is None:
        return False
    runs, prev = 0, True                          # vowel runs after the stressed nucleus (a hiatus run counts once)
    for c in tail[v + 1:]:
        if c in _IV:
            if not prev:
                runs += 1
            prev = True
        elif c != "\u0303":
            prev = False
    acc = next(c for c in word.lower() if c in _ACC)
    base = unicodedata.normalize("NFD", acc)[0]
    return runs == r[0] and tail[v] in {"a": "aɐ", "e": "eɛɐ", "i": "i", "o": "oɔ", "u": "u"}[base]



def _veis_plural(w: str) -> bool:
    low = _loan_key(w)
    return len(low) > 5 and low.endswith("veis") and not _in_dictionary(low)


# Plural o-metaphony: these singulars have a closed stressed o and their plurals an OPEN one (ovo ˈovu, ovos ˈɔvuʃ). The
# set is the grammars' list of metaphonic nouns and adjectives; every adjective in -oso follows it too (famosos).
_METAPHONY = frozenset("""corpo porco povo ovo olho osso fogo jogo poço porto posto novo morto torto grosso forno imposto
    socorro esforço tijolo caroço miolo despojo destroço reforço troço corvo sogro coro fosso rogo poço tremoço
    composto disposto exposto proposto suposto oposto deposto reposto antiporto aeroporto""".split())


# Unstressed contractions and function words that look like a plural of a stressed word ("pelos" is por+os pɨluʃ,
# not the plural of the noun "pelo" ˈpelu; found by the corpus diff, 2026-10-25).
_NOT_PLURALS = frozenset({"pelos", "pelas", "polos", "polas", "nuns", "numas", "duns", "dumas", "doutros", "doutras",
                          "noutros", "noutras", "destes", "destas", "desses", "dessas", "nestes", "nestas", "nesses",
                          "nessas", "daqueles", "daquelas", "naqueles", "naquelas"})


def _known_word(w: str) -> bool:
    return _in_dictionary(w) or bool(_gender.noun_gender(w) or _gender.adjective_gender(w))


def _plural_base(w: str):
    """(singular, ending to add) when w is a plural tugalex lacks whose singular is a known word, else None.
    tugaphone's rules stressed "-ens" plurals on the last syllable ("passagens" pɐsɐˈʒẽʃ, heard wrong by the native
    listener 2026-10-25), opened the e of "meses"/"vezes" and lost the stress of "portugueses": a plural sounds like its
    singular plus -ʃ, so it is read from the singular instead."""
    low = _loan_key(w)
    if len(low) < 4 or not low.isalpha() or not low.endswith("s") or _in_dictionary(low) or low in _NOT_PLURALS:
        return None
    if low.endswith("ens") and _known_word(low[:-2] + "m"):
        return low[:-2] + "m", "ʃ"                                # passagens <- passagem, homens <- homem
    if low.endswith("ns") and low[-3] in "aiou" and _known_word(low[:-2] + "m"):
        return low[:-2] + "m", "ʃ"                                # jardins <- jardim, bons <- bom, atuns <- atum
    if low.endswith(("res", "zes")) and _known_word(low[:-2]):
        return low[:-2], "ɨʃ"                                     # mares <- mar, vezes <- vez
    if low.endswith("eses") and _known_word(low[:-4] + "ês"):
        return low[:-4] + "ês", "ɨʃ"                              # meses <- mês, portugueses <- português
    if low[-2] in "aeo" and _known_word(low[:-1]):
        return low[:-1], "ʃ"                                      # casas <- casa, dados <- dado, pontes <- ponte
    return None


def _phon_plural(w: str, lect: str) -> Optional[str]:
    base = _plural_base(w)
    if base is None:
        return None
    sing, end = base
    ps = unicodedata.normalize("NFD", _phon_word(sing, lect))
    if " " in ps or not ps:
        return None
    if sing.endswith("m") and not ps.rstrip("\u0303").endswith(("ɐ̃j", "ĩ", "õ", "ũ", "ɐ̃")):
        return None                                   # "item" ˈitɛm: an oral -m singular, not a nasal one (itens)
    if end == "ɨʃ":
        if ps.endswith("ʃ"):
            ps = ps[:-1] + "z"                                    # vez ˈveʃ -> vezes ˈvezɨʃ
        elif ps.endswith(("ɾ", "l")) is False and not ps[-1:].isalpha():
            return None
    elif sing.endswith("e") and ps[-1:].isalpha() and ps[-1:] not in _IV and ps[-1:] not in "jw":
        end = "ɨʃ"                                  # ponte ˈpõt -> pontes ˈpõtɨʃ (not after a nasal: mãe ˈmɐ̃j̃ -> mães)
    if sing in _METAPHONY or (sing.endswith("oso") and len(sing) > 4):
        k = ps.rfind("ˈ")
        o = ps.find("o", k)
        if k >= 0 and o > k:
            ps = ps[:o] + "ɔ" + ps[o + 1:]                        # ovos ˈɔvuʃ, famosos fɐˈmɔzuʃ
    return ps + end


# Enclitic pronouns after a hyphen ("aprova-o", "corrige-o", "dá-lo", "diz-me"): tugaphone read the pronoun as a word
# of its own, so "aprova-o" was heard with its "o" spoken apart (native listener, 2026-10-25). In speech the pronoun is
# an unstressed syllable of the verb.
_ENCLITICS = {"o": "u", "a": "ɐ", "os": "uʃ", "as": "ɐʃ", "lo": "lu", "la": "lɐ", "los": "luʃ", "las": "lɐʃ",
              "no": "nu", "na": "nɐ", "nos": "nuʃ", "nas": "nɐʃ", "me": "mɨ", "te": "tɨ", "se": "sɨ", "lhe": "ʎɨ",
              "lhes": "ʎɨʃ", "vos": "vuʃ"}


def _enclitic_split(w: str):
    low = _loan_key(w)
    verb, hy, pron = low.rpartition("-")
    if hy and verb and verb.replace("-", "").isalpha() and pron in _ENCLITICS and len(verb) >= 2:
        return verb, pron
    return None


def _phon_enclitic(w: str, lect: str) -> Optional[str]:
    split = _enclitic_split(w)
    if split is None:
        return None
    verb, pron = split
    ps = unicodedata.normalize("NFD", _phon_word(verb, lect))
    if " " in ps or not ps:
        return None
    clitic = _ENCLITICS[pron]
    if verb.endswith("e") and ps[-1:].isalpha() and ps[-1:] not in _IV and ps[-1:] not in "jw":
        ps += "ɨ"                  # corrige ˈkuʁiʒ + o -> kuˈʁiʒɨu: the e is kept (not after a nasal: sobrepõe-se)
    if ps.endswith("ʃ") and clitic[0] in "mnlvʎ":
        ps = ps[:-1] + "ʒ"                          # diz-me ˈdiʒmɨ
    return ps + clitic


# Stressed stem vowel of verb forms tugalex lacks: tugaphone's rules close it ("gosta" ˈɡoʃtɐ, "aprova" ɐˈpɾovɐ), where
# the stem-stressed forms of a regular verb have an open one (Wiktionary, Portugal: gosta ˈɡɔʃ.tɐ, leva ˈlɛ.vɐ) -- and
# -er/-ir verbs a closed one in the 1st person and the subjunctive (devo, deva). assets/verb_stem_vowel.tsv.gz
# (scripts/build_verb_stress.py, from MorphoBr) says which, per form. A form that is also a noun or an adjective
# ("gosto", "jogo") is left alone: the spelling does not say which word it is.
_VERB_VOWEL: Optional[dict] = None


def _verb_vowel(w: str) -> Optional[str]:
    global _VERB_VOWEL
    if _VERB_VOWEL is None:
        import gzip
        _VERB_VOWEL = {}
        with gzip.open(Path(__file__).parent / "assets" / "verb_stem_vowel.tsv.gz", "rt", encoding="utf-8") as f:
            for line in f:
                form, _, v = line.rstrip("\n").partition("\t")
                _VERB_VOWEL[form] = v
    low = _loan_key(w)
    v = _VERB_VOWEL.get(low)
    if v is None or v in ("I", "V") or _in_dictionary(low) or _gender.noun_gender(low) or _gender.adjective_gender(low) \
            or any(c in "áéíóúâêô" for c in low):         # a written accent already says the quality (revê ʁɨˈve)
        return None
    return v


def _VERB_VOWEL_OF(low: str) -> Optional[str]:
    _verb_vowel("a")
    return _VERB_VOWEL.get(low)


def _is_verb_form(w: str) -> bool:
    """A verb form the table knows (stem-stressed, infinitive, or one that another rule would mistake for a noun)."""
    _verb_vowel("a")
    return _loan_key(w) in _VERB_VOWEL


def _verb_lemma(w: str) -> Optional[str]:
    """The word itself when it is a Portuguese verb infinitive (MorphoBr), else None."""
    _verb_vowel("a")                                  # loads the table
    low = _loan_key(w)
    return low if _VERB_VOWEL.get(low) == "I" else None


def _apply_verb_vowel(ps: str, v: str) -> str:
    s = unicodedata.normalize("NFD", ps)
    k = s.rfind("ˈ")
    if k < 0:
        return ps
    i = next((j for j in range(k + 1, len(s)) if s[j] in _IV), None)
    if i is None or s[i] not in "eɛɨoɔ" or s[i + 1:i + 2] in ("\u0303", "j", "w", "ɲ"):
        return ps                    # nasal (pensa), a diphthong (deixa, rouba), or before ɲ (sonha ˈsoɲɐ, Wiktionary)
    nxt = s[i + 1:i + 2]
    if v in ("O", "E"):              # a stressed ɨ is a reduced e the rules left under the stress ("segue" ˈsɨɡɨ)
        new = {"e": "ɛ", "ɛ": "ɛ", "ɨ": "ɛ", "o": "ɔ", "ɔ": "ɔ"}[s[i]]
        if v == "O" and new == "ɛ" and nxt in ("ʃ", "ʒ", "ʎ") and s[i + 2:i + 3] in _IV:
            # Lisbon: the closed e of an -ar stem before a palatal that OPENS the next syllable is ɐ (fecha ˈfɐʃɐ,
            # deseja); before a coda ʃ (pesca) and in -er/-ir verbs (rege ˈʁɛʒɨ, desce) the open ɛ stays
            new = "ɐ"
    else:
        new = {"e": "e", "ɛ": "e", "ɨ": "e", "o": "o", "ɔ": "o"}[s[i]]
    return s[:i] + new + s[i + 1:]


def _em_word(w: str) -> bool:
    low = _loan_key(w)
    return low.endswith(("em", "gues", "ques")) and len(low) > 4 and low.isalpha() and not _in_dictionary(low) \
        and not any(c in _ACC for c in low)


def _io_word(w: str) -> bool:
    """An unaccented word in consonant + -io is stressed on that i (navio, desvio, abunhadio ɐbuɲɐˈdiu)."""
    low = _loan_key(w)
    return (low.endswith("io") and len(low) > 4 and low.isalpha() and low[-3] not in _OV and low[-3] not in "gq"
            and not _in_dictionary(low) and not any(c in _ACC for c in low))


def _feminine_base(w: str) -> Optional[str]:
    """The masculine of a feminine form tugalex lacks ("correta" <- "correto", "próxima" <- "próximo"). Rules measured on
    dictionary headwords never saw these (headwords are masculine), and a feminine sounds like its masculine with -ɐ:
    read it from there (found by the corpus diff: "completa" had been closed, 2026-10-25)."""
    low = _loan_key(w)
    if len(low) < 4 or not low.isalpha() or not low.endswith("a") or _in_dictionary(low):
        return None
    masc = low[:-1] + "o"
    if not _in_dictionary(masc):
        return None
    # a past participle in -ada/-ida is its masculine with -ɐ, whatever the verb table says: "indexada" was read
    # ĩdɨˈʃadɐ while "indexado" is ĩdɛkˈsadu (Wiktionary, Portugal: indexar ĩ.dɨkˈsaɾ), 2026-10-27
    if low.endswith(("ada", "ida")):
        return masc
    if _verb_vowel(low) or _VERB_VOWEL.get(low) == "V":
        return None                  # a verb form the verb rule reads (retorna), or a verb, not a feminine (copia)
    return masc


def _phon_feminine(w: str, lect: str) -> Optional[str]:
    masc = _feminine_base(w)
    if masc is None:
        return None
    ps = unicodedata.normalize("NFD", _phon_word(masc, lect))
    if " " in ps or not ps.endswith("u"):
        return None
    ps = ps[:-1] + "ɐ"
    if masc in _METAPHONY or (masc.endswith("oso") and len(masc) > 4):     # nova ˈnɔvɐ, famosa fɐˈmɔzɐ
        k = ps.rfind("ˈ")
        o = ps.find("o", k)
        if k >= 0 and o > k:
            ps = ps[:o] + "ɔ" + ps[o + 1:]
    return ps


_ACCENT_OPTIONS = {"a": "áâ", "e": "éê", "i": "í", "o": "óô", "u": "ú"}


# Frequent words often typed without their final accent; none of the unaccented spellings is a word of its own
_FINAL_ACCENT_TYPOS = {"tambem": "também", "atraves": "através", "voce": "você", "voces": "vocês", "apos": "após",
                       "alguem": "alguém", "ninguem": "ninguém", "alem": "além"}


def _accent_rescue(w: str) -> Optional[str]:
    """Text written without accents ("necessario", "repositorio", "dominio" in the knowledge base): when putting ONE
    accent on one of the last vowels gives exactly one dictionary word, the word is read as that one."""
    low = _loan_key(w)
    if low in _FINAL_ACCENT_TYPOS:
        return _FINAL_ACCENT_TYPOS[low]
    if len(low) < 5 or not low.isalpha() or any(c in _ACC or c in "ãõç" for c in low) or _in_dictionary(low) \
            or _known_word(low) or _is_verb_form(low):
        return None
    vowels = [i for i, c in enumerate(low) if c in _ACCENT_OPTIONS][-3:]
    # only an accent before two vowel letters (necessário, domínio, número): an unaccented word
    # stressed on its penult is usually a valid word of its own (chegamos / chegámos, pode / pôde)
    # and never on the LAST vowel: tugalex has rare words that would capture common ones ("disse" -> "dissê")
    vowels = [i for i in vowels if sum(1 for c in low[i + 1:] if c in _ACCENT_OPTIONS) >= 2]
    hits = {low[:i] + a + low[i + 1:] for i in vowels for a in _ACCENT_OPTIONS[low[i]]}
    _in_dictionary("a")                                  # loads the word sets
    hits = [h for h in hits if h in _TUGALEX]           # tugalex only: the verb-collision table was built against it,
    return hits[0] if len(hits) == 1 else None         # so a rare extra-lexicon noun cannot capture a verb (ficaria)


def _phon_word(w: str, lect: str) -> str:
    """One word through the special cases that need the whole word: -veis plurals, then the in- prefix."""
    if _veis_plural(w):
        # "esquecíveis" was stressed on the last syllable (eʃkɨsiˈvɐjʃ); the native listener confirmed the stress on
        # -cí- (2026-10-25). A -veis plural sounds like its -vel singular with -vɐjʃ: read the singular, swap the end.
        core = _loan_key(w)
        sing = _phon_word(core[:-3] + "el", lect)                   # "esquecíveis" -> "esquecível"
        for end in ("vɛl", "vɛɫ", "vel"):
            if sing.endswith(end):
                return sing[:-len(end)] + "vɐjʃ"
    rescued = _accent_rescue(w)
    if rescued:
        return _phon_word(rescued, lect)
    low_w = _loan_key(w)
    if low_w.endswith("ámos") and len(low_w) > 4:
        # the -ámos past ("chegámos") vs the -amos present ("chegamos" ɐ): the native listener heard the open a as
        # "chegamos" until it was LENGTHENED (A/B 2026-10-25: ʃɨˈɡaːmuʃ the only one right)
        ps = unicodedata.normalize("NFD", _phon_one(w, lect))
        k = ps.rfind("ˈ")
        a = ps.find("a", k)
        if k >= 0 and a > k and ps[a + 1:a + 2] != "ː":
            return ps[:a + 1] + "ː" + ps[a + 1:]
        return ps
    for special in (_phon_enclitic, _phon_plural, _phon_feminine):
        ps = special(w, lect)
        if ps is not None:
            return ps
    ps = _phon_in_prefix(w, lect) if _in_prefix_word(w) else _phon_one(w, lect)
    low = _loan_key(w)
    if low.endswith("em") and len(low) > 4 and low.isalpha() and not _in_dictionary(low) \
            and not any(c in _ACC for c in low):
        ps = _penult_em(low, ps)
    elif low.endswith(("gues", "ques")) and len(low) > 4 and not _in_dictionary(low) and not any(c in _ACC for c in low):
        ps = _penult_es(ps)
    elif _io_word(low):
        t = unicodedata.normalize("NFD", ps)
        if t.endswith("iu") and not t.endswith("ˈiu") and "ˈ" + t[-3:] != t[-4:]:
            placed = _place_stress(t.replace("ˈ", ""), 1)
            ps = placed[0] if placed else ps
    if not _in_dictionary(low) and low.isalpha():
        pre = _learned_prefix(w)
        if pre:
            t = unicodedata.normalize("NFD", ps)
            for reduced in (pre[0] if isinstance(pre[0], tuple) else (pre[0],)):
                if t.startswith(reduced):                 # only when the stress mark is not inside the prefix
                    ps = pre[1] + t[len(reduced):]
                    break
        if _lost_consonant_e(w):
            t = unicodedata.normalize("NFD", ps)
            for reduced, opened in (("ɨˈsɐ̃w̃", "ɛˈsɐ̃w̃"), ("ɨˈsõj̃ʃ", "ɛˈsõj̃ʃ")):
                r = unicodedata.normalize("NFD", reduced)
                if t.endswith(r):
                    ps = t[:-len(r)] + unicodedata.normalize("NFD", opened)
        if "lr" in low:
            ps = unicodedata.normalize("NFD", ps).replace("lɾ", "lʁ")   # r after l is strong: abalroar, chalrar
        if any(c in _ACC for c in low) and low.endswith(("en", "on")):
            # a learned word in -en/-on keeps the consonant: alúmen ɐˈlumɛn, plâncton -ɔn (7/7 and 50/52 accented
            # pt-PT dictionary words; unaccented ones go both ways and are left alone)
            t = unicodedata.normalize("NFD", ps)
            for nasal in (unicodedata.normalize("NFD", n) for n in ("ɐ̃", "ẽ", "ɛ̃", "õ")):
                if t.endswith(nasal):
                    ps = t[:-len(nasal)] + ("ɛn" if low.endswith("en") else "ɔn")
                    break
    vv = _verb_vowel(w)
    if vv:
        ps = _apply_verb_vowel(ps, vv)
    else:
        end = _ending_rule(w)
        if end:
            ps = _apply_ending_rule(w, ps, end)
    if _accented_unknown(w):
        low = _loan_key(w)
        if not _stress_on_accent(low, ps):
            ps = _fix_accent_stress(low, ps)
        elif (_nuclei_after_accent(low) or (0, False))[1]:
            ps = _final_glide(unicodedata.normalize("NFD", ps))     # stress already right: "vídeos" ˈvidɨuʃ -> ˈvidjuʃ
        # -vel of a word tugalex lacks came out vɨl ("branqueável" ...ˈavɨl); pt-PT has vɛɫ
        if low.endswith("vel") and ps.endswith("vɨl"):
            ps = ps[:-3] + "vɛl"
    return ps


_SANDHI_VOWELS = set("aɐeɛiɨoɔuəæɒʌɪʊɑɜ")      # incl. the English vowels of loanwords
_SANDHI_VOICED = set("bdɡvzʒmnɲlʎɾʁ")


def _join_with_sandhi(parts: list, english: frozenset = frozenset()) -> str:
    """Words phonemized one by one lose the liaison tugaphone applies across a phrase: a word-final s (ʃ) is z before
    a vowel and ʒ before a voiced consonant ("os itens" uz iˈtẽʃ, "as receitas" ɐʒ ʁɨˈsɐjtɐʃ). Re-applied here, so the
    word-level paths (loanwords, -veis plurals, the in- prefix) keep it (measured on the corpus diff, 2026-10-25)."""
    keep = [(x, i in english) for i, x in enumerate(parts) if x]
    parts = [x for x, _ in keep]
    out = []
    for i, w in enumerate(parts):
        if w.endswith("ʃ") and i + 1 < len(parts) and not keep[i][1]:       # an English loanword keeps its own ending
            nxt = parts[i + 1].lstrip(NUMBER_JOIN + "ˈˌ")
            nxt = unicodedata.normalize("NFD", nxt)[:1]
            if nxt in _SANDHI_VOWELS:
                w = w[:-1] + "z"
            elif nxt in _SANDHI_VOICED:
                w = w[:-1] + "ʒ"
        out.append(w)
    return " ".join(out)


# Quality of a stressed e/o set by the word's ending, for words tugalex lacks (tugaphone's rules close "-ose", "-orme",
# "-oide" and open "-eza", "-esco": acidose ɐsiˈdozɨ, abnorme ɐˈbnoɾmɨ). These are the pt-PT regularities of those endings;
# each was kept only when >= 95% of >= 20 pt-PT dictionary words with it agree (lexicon statistics, 2026-10-25,
# scripts/validate_lexicon.py), so "-eta"/"-ete", which go both ways, are not here. Feminine and plural -oso forms are
# open by the grammar (famosa, famosas, famosos). Applied only where the stress is already on that vowel.
_ENDING_VOWEL = {
    "ostro": "o", "eque": "ɛ", "erma": "ɛ", "erso": "ɛ", "esco": "e", "oico": "ɔ", "oide": "ɔ", "oira": "o",
    "oiro": "o", "olas": "ɔ", "olho": "o", "onha": "o", "onho": "o", "oque": "ɔ", "orme": "ɔ", "orro": "o", "orto": "o",
    "osto": "o", "eca": "ɛ", "ela": "ɛ", "ema": "e", "ena": "e", "eno": "e", "esa": "e", "ese": "ɛ", "eza": "e", "oca": "ɔ",
    "oga": "ɔ", "ojo": "o", "ola": "ɔ", "oma": "o", "ona": "o", "one": "ɔ", "ope": "ɔ", "ose": "ɔ", "oso": "o", "ote": "ɔ",
    "el": "ɛ", "er": "e", "ez": "e", "oa": "o", "ol": "ɔ", "or": "o", "oz": "ɔ",
    "osa": "ɔ", "osas": "ɔ", "osos": "ɔ",
    # mixed endings where one quality still wins clearly for words tugalex lacks: chosen on half of the measured words
    # by their GAIN over tugaphone's rules and confirmed on the other half (25% -> 86% right), 2026-10-25
    "elo": "e", "eta": "e", "ete": "e", "eto": "e", "ota": "ɔ",
}
_ENDINGS_LONGEST_FIRST = sorted(_ENDING_VOWEL, key=len, reverse=True)


def _ending_rule(w: str) -> Optional[str]:
    low = _loan_key(w)
    if len(low) < 4 or not low.isalpha() or _in_dictionary(low) or any(c in _ACC for c in low) \
            or _VERB_VOWEL_OF(low) in ("O", "E", "C", "V") or _feminine_base(low):
        return None
    end = next((e for e in _ENDINGS_LONGEST_FIRST if low.endswith(e)), None)
    if end in ("er", "el", "or") and not _known_word(low) and _verb_lemma(low) is None:
        return None              # -er/-el/-or of an unknown word: often English (user, manager, customer)
    return end


def _apply_ending_rule(w: str, ps: str, ending: str) -> str:
    want = _ENDING_VOWEL[ending]
    k = sum(1 for i, c in enumerate(ending[1:], 1) if c in _OV and ending[i - 1] not in _OV)   # vowel groups after
    s = unicodedata.normalize("NFD", ps)
    m = s.rfind("ˈ")
    if m < 0:
        return ps
    i = next((j for j in range(m + 1, len(s)) if s[j] in _IV), None)
    if i is None:
        return ps
    after = sum(1 for j in range(i + 1, len(s)) if s[j] in _IV and s[j - 1] not in _IV)
    if not (after == k or (after == k - 1 and _loan_key(w).endswith("e"))):   # final e may be dropped (ˈpõt)
        return ps
    cls = {"e": "eɛɨ", "ɛ": "eɛɨ", "o": "oɔu", "ɔ": "oɔu"}[want]
    nxt = s[i + 1:i + 2]
    if s[i] not in cls or nxt == "\u0303" or (nxt in "jw" and ending[:2] not in ("oi", "ei")):
        return ps
    return s[:i] + want + s[i + 1:]


# Number words whose final ɨ must survive even before a vowel: without it "12 e 13" was heard "2 e 3" (2026-10-25)
_KEEP_FINAL_VOWEL = frozenset({"doze", "onze", "treze", "catorze", "quinze", "sete", "nove", "vinte", "dezassete",
                               "dezanove"})


def _needs_word_level(w: str) -> bool:
    """A word one of the word-level fixes handles (see _phon_word)."""
    low = _loan_key(w)
    if low in _KEEP_FINAL_VOWEL or low in _LETTER_NAME_WORDS or (low.endswith("ámos") and len(low) > 4) or low == "fim":
        return True              # read alone, so tugaphone's phrase elision cannot take the ɨ back ("doze e" ˈdoz i)
    return bool(_in_prefix_word(w) or _veis_plural(w) or _accented_unknown(w) or _plural_base(w) or _enclitic_split(w)
                or _verb_vowel(w) or _em_word(w) or _io_word(w) or _ending_rule(w) or _feminine_base(w)
                or _accent_rescue(w) or _learned_prefix(w) or _lost_consonant_e(w)
                or ("lr" in low and low.isalpha() and not _in_dictionary(low)))


# A learned prefix keeps its own vowels in a word tugalex lacks: "biometria" bjɔmɨˈtɾiɐ, "geoespacial", "neurocirurgia",
# "fotossíntese", "telemóvel" -> the rules reduced them (biu-, ʒɨu-, futu-, tɨlɨ-), as in an ordinary word. Each row: the
# spelling, the reduced reading our rules gave, the reading kept. Measured on the words of a pt-PT dictionary that tugalex
# lacks (2026-10-30): the kept reading in 82-100% of each prefix's words (bio- 288 words 94%, auto- already right).
_LEARNED_PREFIXES = (
    ("neuro", "newɾu", "newɾɔ"), ("psico", "psiku", "psikɔ"), ("socio", "susiu", "sɔsjɔ"), ("micro", "mikɾu", "mikɾɔ"),
    ("macro", "mɐkɾu", "makɾɔ"), ("hidro", "idɾu", "idɾɔ"), ("video", "vidɨu", "vidjɔ"), ("foto", "futu", "fɔtɔ"),
    ("tele", "tɨlɨ", "tɛlɛ"), ("bio", "biu", "biɔ"), ("geo", "ʒɨu", "ʒɛɔ"), ("eco", "eku", "ɛkɔ"),
    ("otimi", ("uti", "oti"), "ɔti"),                     # optim- (Wiktionary "otimizar" /ɔ.ti.miˈzaɾ/)
)


_REDUCING_STEMS = ("log", "lóg", "ním", "nim")         # the 15 words the prefix rule made worse, 2026-10-30


def _learned_prefix(w: str) -> Optional[tuple]:
    low = _loan_key(w)
    if not low.isalpha() or _in_dictionary(low):
        return None
    for spelling, reduced, kept in _LEARNED_PREFIXES:
        if low.startswith(spelling) and len(low) >= len(spelling) + 3:
            if low[len(spelling):].startswith(_REDUCING_STEMS):
                return None                               # "hidrologia", "macrológico": reduced, as "biologia" in tugalex
            return reduced, kept
    return None


def _lost_consonant_e(w: str) -> bool:
    """-eção / -eções in a word tugalex lacks (deteção, perceção, conceção): the e is open, where the 1990 spelling
    reform dropped a silent c or p (deteção < detecção). Our rules reduced it (dɨtɨˈsɐ̃w̃); open in 30 of 33 such
    dictionary words (2026-10-30)."""
    low = _loan_key(w)
    return low.endswith(("eção", "eções")) and low.isalpha() and not _in_dictionary(low)


# A number of several words is said as ONE unit: "mil novecentos e oitenta e quatro" with the stress on its last word
# only and no gap inside. Read with a stress on every word and the model's gaps it was heard as slow, word by word (the
# native listener's A/B, 2026-10-25: this over the number as one word, the gaps alone or the stress alone). Which words
# form one number follows the grammar, so "doze e treze" ("12 e 13") stays two numbers: a scale multiplies what comes
# before it (dois mil), "e" adds a smaller part after a scale, hundreds or tens (mil e vinte, cento e dez, vinte e
# três), "vinte" + 5-9 without "e" (the elided twenties), and a clock time adds its minutes ("às nove e trinta").
NUMBER_JOIN = "\u2040"     # marks a gap inside a number for the model (kokoro/model.py); not in the vocab, never spoken
# marks the final ɨ of a number word (_KEEP_FINAL_VOWEL) for the model, which then gives it at least 2 frames: at the
# rate 1.08 that ɨ was 1 frame and "treze estilos" / "treze aspetos" were heard "três" (regression set, Whisper 2-3 of 3;
# with 2 frames 3 of 3 "13", 2026-10-25)
KEEP_VOWEL = "\u2041"
# marks a consonant the model must hold at least 4 frames: the z of "treze" was 1-2 frames and heard as the s of "três";
# held 100 ms, the native listener's choice over 150 ms (Whisper: "13" in 12 of 12 runs, against 4 of 12), 2026-10-25
HOLD = "\u2042"
_HOLD_AFTER = {"treze": "ˌz"}
# marks a word-final vowel the model keeps at least 2 frames and follows with a gap of at least 2 frames: the final ɨ of
# "treze" dragged into the next vowel ("treze aspetos"). The native listener preferred it 1 frame long, but then "São
# treze aspetos diferentes." alone was heard "três" in 12 of 12 runs (Whisper; 8 of 12 "13" with 2 frames): the gap
# alone was chosen (2026-10-25). A glottal onset on the next word was heard "treze de aspetos".
END_GAP = "\u2043"
# marks the vowel of an enclitic -o/-a/-os/-as, which the model holds at least 3 frames: "corrige-o" got 1 frame for its
# "o" and it was barely heard; 75 ms was the native listener's choice over reading it as a separate word (2026-10-25)
CLITIC_VOWEL = "\u2044"
MARKS = frozenset({NUMBER_JOIN, KEEP_VOWEL, HOLD, END_GAP, CLITIC_VOWEL})     # every mark for the model; none is a token
_END_GAP_WORDS = frozenset({"treze"})
_APART_WORDS = frozenset({"iban"})            # a gap after the word whatever its last sound (END_GAP)
_NUM_WORDS = {
    **{w: (v, "unit") for v, ws in enumerate((("um", "uma"), ("dois", "duas"), ("três",), ("quatro",), ("cinco",),
                                              ("seis",), ("sete",), ("oito",), ("nove",)), 1) for w in ws},
    **{w: (v, "teen") for v, w in enumerate(("dez", "onze", "doze", "treze", "catorze", "quinze", "dezasseis",
                                             "dezassete", "dezoito", "dezanove"), 10)},
    **{w: (v * 10, "tens") for v, w in enumerate(("vinte", "trinta", "quarenta", "cinquenta", "sessenta", "setenta",
                                                  "oitenta", "noventa"), 2)},
    "cem": (100, "hund"), "cento": (100, "hund"),
    **{w: (v * 100, "hund") for v, ws in enumerate((("duzentos", "duzentas"), ("trezentos", "trezentas"),
                                                    ("quatrocentos", "quatrocentas"), ("quinhentos", "quinhentas"),
                                                    ("seiscentos", "seiscentas"), ("setecentos", "setecentas"),
                                                    ("oitocentos", "oitocentas"), ("novecentos", "novecentas")), 2)
       for w in ws},
    "zero": (0, "unit"),
    "mil": (10 ** 3, "scale"), "milhão": (10 ** 6, "scale"), "milhões": (10 ** 6, "scale"),
    "bilião": (10 ** 12, "scale"), "biliões": (10 ** 12, "scale"),
}
_TIME_BEFORE = frozenset({"às", "as", "das", "pelas", "à", "da", "pela"})


def _number_runs(words: list, clock_times: bool = True) -> list:
    """(first, last) word index of every number written in two or more words. With `clock_times` False, the hour and
    the minutes of a clock time are two numbers (each keeps its own stress)."""
    runs, i, n = [], 0, len(words)
    while i < n:
        first = _NUM_WORDS.get(_loan_key(words[i]))
        if first is None:
            i += 1
            continue
        kind, end = first[1], i
        top = first[0] if kind == "scale" else float("inf")          # the smallest scale so far
        clock = clock_times and i > 0 and _loan_key(words[i - 1]) in _TIME_BEFORE and first[0] <= 24
        j = i + 1
        while j < n:
            has_e = _loan_key(words[j]) == "e"
            k = j + 1 if has_e else j
            nxt = _NUM_WORDS.get(_loan_key(words[k])) if k < n else None
            if nxt is None and clock and has_e and k < n and _loan_key(words[k]) == "meia":
                nxt = (30, "tens")                                      # "às nove e meia": the minutes (2026-10-27)
            if nxt is None:
                break
            val, nk = nxt
            if nk == "scale":
                ok = not has_e and kind != "scale" and val < top
            elif kind == "scale":
                ok = True
            elif kind == "hund":
                ok = has_e and nk in ("tens", "teen", "unit")
            elif kind == "tens":
                ok = nk == "unit" and (has_e or (_loan_key(words[end]) == "vinte" and val >= 5))
            else:
                ok = False
            if not ok and clock and has_e and top == float("inf") and nk in ("tens", "teen", "unit"):
                ok, clock = True, False                                 # the minutes of a clock time, once
            if not ok:
                break
            kind, end = nk, k
            if nk == "scale":
                top = val
            j = k + 1
        runs.append((i, end))
        i = end + 1
    # a decimal is one number too: "zero vírgula vinte cinco" was heard with a pause after "vírgula" (the native
    # listener, 2026-10-25)
    merged = []
    for a, b in runs:
        if merged and a == merged[-1][1] + 2 and _loan_key(words[a - 1]) == "vírgula" \
                and "vírgula" not in [_loan_key(w) for w in words[merged[-1][0]:merged[-1][1] + 1]]:   # one comma: "1,2,3" is not
            merged[-1] = (merged[-1][0], b)
        else:
            merged.append((a, b))
    return [(a, b) for a, b in merged if b > a]


def _letter_runs(words: list) -> list:
    """(first, last) word index of every spelled acronym: two or more letter names in a row ("cê gê dê"). Read letter by
    letter, each stressed and apart, the native listener heard pauses; an acronym is said as one word (2026-10-25)."""
    names = set(_LETTER_NAMES.values())
    runs, i = [], 0
    while i < len(words):
        j = i
        while j < len(words) and _loan_key(words[j]) in names:
            j += 1
        if j > i and j < len(words) and _loan_key(words[j])[:-1] in names and _loan_key(words[j])[-1:] == "s":
            j += 1                                            # a plural acronym ends in the letter + s ("pê éme és")
        keys = {_loan_key(w) for w in words[i:j]}
        if j - i >= 2 and not keys <= _LETTER_NAME_LOOKALIKES:   # "É dê ver": words, not letters
            runs.append((i, j - 1))
        i = max(j, i + 1)
    return runs


_LETTER_NAME_LOOKALIKES = frozenset({"é", "dê", "quê", "ó", "capa", "jota", "és"})


# A clock time is said as one unit, but its hour keeps its own stress: "às dezoito e trinta" with dezoito unstressed
# was not "18" (the native listener, A/B "B", 2026-10-27). The gap BEFORE the hour is marked too: the model left 93 ms
# between "às" / "São" and "dezoito" (23 ms before "nove"), heard as a pause before the hour. An hour ending in u or ɨ
# is said as one word with its "e" and the minutes' first word, as "vinte e quatro" (3c): dɨˈzɔjtwiˈtɾĩtɐ. The end of
# "dezoito" and its "e" were almost silent (265 ms below -30 dB, against 115 ms in "nove e trinta"), heard as a pause
# between 18 and 30; the joined reading was preferred in every A/B pair (2026-10-27). "treze" is never joined: its
# final ɨ and held z keep it from being heard "três".
_HOUR_NOUNS = frozenset({"hora", "horas"})
_HOUR_BEFORE = frozenset({"às", "à", "pelas", "pela"})       # "as"/"das"/"da" are also articles: "as duas casas"


def _join_numbers(words: list, parts: list, marks: bool) -> None:
    """One stress per number or spelled acronym, on its last word (the hour of a clock time keeps its own); with
    `marks`, each gap inside it, and the gap before an hour, is marked for the model."""
    full = _number_runs(words)
    for a, b in _number_runs(words, clock_times=False) + _letter_runs(words):
        idx = [k for k in range(a, b + 1) if parts[k]]
        for k in idx[:-1]:
            parts[k] = parts[k].replace("ˈ", "")
    for a, b in _clock_hours(words, full):
        h = max(k for k in range(a, b + 1) if parts[k])                   # the hour's last spoken part
        m = b + 2                                                         # "e", then the minutes' first word
        if h != b or {_loan_key(words[b]), _loan_key(words[m])} & (_END_GAP_WORDS | set(_HOLD_AFTER)) or not parts[m]:
            continue
        head = unicodedata.normalize("NFD", parts[h])
        if head.endswith("u"):
            head = head[:-1] + "w"
        elif head.endswith("ɨ"):
            head = head[:-1]
        else:
            continue
        tail = parts[m]
        last = max(fb for fa, fb in full if fa == a)
        if marks and m == last and _loan_key(words[m]) in _KEEP_FINAL_VOWEL and tail.endswith("ɨ"):
            tail += KEEP_VOWEL                        # the minutes' word kept its final-vowel mark ("às nove e quinze")
        parts[h], parts[b + 1], parts[m] = head + "i" + tail, "", ""
    if not marks:
        return
    for a, b in full + _letter_runs(words):
        for k in [k for k in range(a, b + 1) if parts[k]][1:]:
            parts[k] = NUMBER_JOIN + parts[k]
    inner = {k for a, b in full for k in range(a + 1, b + 1)}
    for a, b in full + [(i, i) for i, w in enumerate(words) if _NUM_WORDS.get(_loan_key(w)) and parts[i]]:
        if a == 0 or a in inner or not parts[a] or parts[a].startswith(NUMBER_JOIN):
            continue
        after = _loan_key(words[b + 1]) if b + 1 < len(words) else ""
        before = _loan_key(words[a - 1])
        if after in _HOUR_NOUNS or before in _HOUR_BEFORE or (before in _TIME_BEFORE and (a, b) in full
                                                                and any(ca == a for ca, _ in _clock_hours(words, full))):
            parts[a] = NUMBER_JOIN + parts[a]


def _clock_hours(words: list, full: list) -> list:
    """(first, last) word index of the hour of every clock time with minutes ("às dezoito e trinta" -> dezoito)."""
    out = []
    for a, b in _number_runs(words, clock_times=False):
        if a > 0 and _loan_key(words[a - 1]) in _TIME_BEFORE and b + 2 < len(words) \
                and _loan_key(words[b + 1]) == "e" and any(fa == a and fb >= b + 2 for fa, fb in full):
            out.append((a, b))
    for i, w in enumerate(words):                                         # a one-word hour: "às nove e trinta"
        if i > 0 and _loan_key(words[i - 1]) in _TIME_BEFORE and i + 2 < len(words) \
                and _loan_key(words[i + 1]) == "e" and any(fa == i and fb >= i + 2 for fa, fb in full) \
                and not any(a == i for a, _ in out):
            out.append((i, i))
    return out


def _raw_phonemize(text: str, lect: str, marks: bool = False) -> str:
    """The span is read by tugaphone as a PHRASE (its homograph choice uses the context), then only the words a fix
    applies to are replaced by their word-level reading, and the liaison is re-applied. When the phrase output does not
    line up word for word with the input (a hyphenated word split in two), every word is read on its own instead."""
    lw = _loanwords()
    # numbers spelled HERE (as _phon_one would), so a number word is a word the fixes can see ("12" -> "doze")
    text = normalize_numbers(text)
    words = text.split()
    fixed = {**lw, **_OVERRIDES}               # an inline override reads exactly as given, like a loanword
    special = [i for i, w in enumerate(words) if _loan_key(w) in fixed or _needs_word_level(w) or _loan_key(w) in _APART_WORDS]

    if not special and not _number_runs(words) and not _letter_runs(words):
        return _phon_one(text, lect)
    # number words and spelled letters are special (in _needs_word_level), so the boundary rule below always runs
    english = frozenset(i for i, w in enumerate(words) if _loan_key(w) in fixed)
    phrase = _phon_one(text, lect).split()
    if len(phrase) == len(words):
        parts = list(phrase)
        for i in special:
            parts[i] = fixed[_loan_key(words[i])] if i in english else _phon_word(words[i], lect)
    else:
        parts = [fixed[_loan_key(w)] if i in english else _phon_word(w, lect) for i, w in enumerate(words)]
    _keep_word_boundaries(words, parts)
    _join_numbers(words, parts, marks)
    # "treze" before a vowel ("treze aspetos"): plain ˈtɾezɨ, no secondary stress and none of its hold / gap marks -- the
    # native listener's A/B "C" (2026-11-01) over today's ˈtɾeˌzɨ with marks (heard "trezi") and the dropped e joined
    # ("trezaspetos"). Before a consonant it keeps the reading chosen on 2026-10-25.
    plain = set()
    for i in range(len(parts) - 1):
        if _loan_key(words[i]) == "treze" and parts[i] and parts[i + 1] \
                and unicodedata.normalize("NFD", parts[i + 1]).lstrip("ˈˌ")[:1] in _IV:
            parts[i] = unicodedata.normalize("NFC", "ˈtɾezɨ"); plain.add(i)
    if marks:
        for i, w in enumerate(words):
            if i in plain:
                continue
            if parts[i] and _loan_key(w) in _APART_WORDS:
                parts[i] += END_GAP           # "íban": its n not run into the next word (the listener, 2026-11-01)
            if parts[i] and _loan_key(w) in _END_GAP_WORDS and parts[i].endswith("ɨ"):
                parts[i] += END_GAP
            elif parts[i] and _loan_key(w) in _KEEP_FINAL_VOWEL and parts[i].endswith("ɨ"):
                parts[i] += KEEP_VOWEL
            split = _enclitic_split(w)
            if split and split[1] in ("o", "a", "os", "as") and parts[i]:
                n = unicodedata.normalize("NFD", parts[i])
                k = len(n) - (2 if split[1].endswith("s") else 1)       # the clitic's vowel (before its s, if any)
                if k > 0 and n[k] in "uɐ":
                    parts[i] = n[:k + 1] + CLITIC_VOWEL + n[k + 1:]
            hold = _HOLD_AFTER.get(_loan_key(w))
            if hold and parts[i]:
                n = unicodedata.normalize("NFD", parts[i])
                parts[i] = n.replace(hold, hold + HOLD, 1)
    return _join_with_sandhi(parts, english)


# multi-letter names only: "á", "é", "i", "ó", "u" are also words ("é" the verb) and must keep their phrase reading
_LETTER_NAME_WORDS = frozenset(n for n in _LETTER_NAMES.values() if len(n) > 1)


def _keep_word_boundaries(words: list, parts: list) -> None:
    """After a number word or a spelled letter, keep the next word apart (measured 2026-10-25, Whisper, no prompt):
    * (a final ɨ -> i before a vowel was tried and REMOVED: Whisper preferred it, the native listener heard it as
      Brazilian -- the ear decides vowel quality, not the ASR);
    * an "es-" word whose e Lisbon drops (estilos ˈʃtiluʃ) gets it back after them: "treze estilos" ˈtɾezi iʃˈtiluʃ
      (13 in 3/3; "três" in 3/3 without), "3D estilizado" dê iʃtiliˈzadu (was heard "destilizado")."""
    for i in range(len(parts) - 1):
        cur, nxt = parts[i], parts[i + 1]
        if not cur or not nxt:
            continue
        key = _loan_key(words[i])
        if key not in _KEEP_FINAL_VOWEL and key not in _LETTER_NAME_WORDS:
            continue
        n = unicodedata.normalize("NFD", nxt)
        body = n.lstrip("ˈ")
        restore = _loan_key(words[i + 1])[:1] == "e" and body[:1] in ("ʃ", "ʒ") and key in _LETTER_NAME_WORDS
        if restore:                    # after a spelled letter only ("3D estilizado"); a number keeps ˈtɾezɨ ˈʃtiluʃ
            parts[i + 1] = ("i" + body[0] + "ˈ" + body[1:]) if n.startswith("ˈ") else ("i" + n)
        # before a vowel a number keeps its short ɨ (ˈtɾezɨ ɐʃˈpɛtuʃ, ˈdozɨ ˈo): the native listener's A/B (2026-10-25)
        # rejected the dropped vowel ("trêse aspetos", "dos") and the glide / i ("trezi", "dozi")
    # "ao fim de/da/do...": "fim" is unstressed inside the set phrase (the native listener heard a stressed one dragged,
    # "ao fiim da tarde"; A/B 2026-10-25); "chegámos ao fim." keeps it
    for i in range(len(parts) - 1):
        if _loan_key(words[i]) == "fim" and _loan_key(words[i + 1]) in ("de", "da", "do", "das", "dos") and parts[i]:
            parts[i] = parts[i].replace("ˈ", "")
    # "vinte e quatro": one word ˈvĩtiˈkwatɾu; read apart (ˈvĩt i ˈkwatɾu) the native listener heard a comma,
    # "vinte, e quatro" (A/B, 2026-10-25)
    for i in range(len(parts) - 2):
        if _loan_key(words[i]) == "vinte" and _loan_key(words[i + 1]) == "e" and words[i + 2][:1].isalpha() \
                and parts[i + 2]:
            # one word, as said (ˈvĩtiˈkwatɾu): the A/B the native listener chose (3c) over ˈvĩti ˈkwatɾu
            c = unicodedata.normalize("NFD", parts[i]).rstrip("ɨ")
            parts[i], parts[i + 1], parts[i + 2] = c + "i" + parts[i + 2], "", ""
        # NOT ɨ -> i: the native listener heard ˈtɾezi as the Brazilian reading (2026-10-25); pt-PT keeps ɨ


# Punctuation Kokoro can actually represent (verified against config.json vocab).
KEEP_PUNCT = {c for c in ';:,.!?—…"()“”' if c in VOCAB}


def phonemize(text: str, lect: str = LECT, keep_punct: bool = True, number_marks: bool = False) -> str:
    """Text -> European Portuguese IPA, ready for Kokoro's vocab.

    PUNCTUATION: phonemizers drop it, but Kokoro's vocab contains 13 punctuation tokens
    and the model uses them for prosody -- sentence-final pauses, comma breaths,
    intonation resets. Training without them produces flat, run-on delivery.

    So the text is split at punctuation, each span phonemized separately, and the marks
    re-inserted between the spans as real tokens.

    `number_marks` adds NUMBER_JOIN inside multi-word numbers, for tts_eu_pt's own model call (not a vocab symbol).
    """
    # Normalise first (acronyms -> "i á,", D. -> Dom, Afonso I -> Afonso Primeiro). This
    # may inject punctuation (the "IA" comma), so the split below treats it as a pause.
    text = normalize_text(text)
    if not keep_punct:
        return _raw_phonemize(text, lect, number_marks)

    out, buf = [], []
    for ch in text:
        if ch in KEEP_PUNCT:
            span = "".join(buf).strip()
            buf = []
            if span:
                ps = _raw_phonemize(span, lect, number_marks)
                if ps:
                    out.append(ps)
            out.append(ch)          # the punctuation token itself
        else:
            buf.append(ch)
    span = "".join(buf).strip()
    if span:
        ps = _raw_phonemize(span, lect, number_marks)
        if ps:
            out.append(ps)

    # join so punctuation hugs the preceding phonemes and a space follows, e.g. "dˈiɐ. ʃˈɐ̃mʊ"
    s = ""
    for tok in out:
        if tok in KEEP_PUNCT:
            s = s.rstrip() + tok
        else:
            s = (s + " " + tok) if s else tok
    return _join_liaison(_article_after_a(" ".join(s.split()), number_marks), number_marks)


def _join_liaison(ps: str, marks: bool = False) -> str:
    """A word ending in the linking z ("os humanos" uz uˈmɐnuʃ) is written as one word with the vowel-initial word after
    it (uzuˈmɐnuʃ), as it is said. Apart, the female voice held the z and the gap after it 3-4x longer than the male one's
    (z 8 + gap 7 frames against 2 + 2), heard "uzee…romanos"; joined, the native listener heard it right (A/B "C",
    2026-10-28). With `marks`, the vowel after the z keeps at least 3 frames (CLITIC_VOWEL's hold): joined, João's u
    got 1 frame and "os humanos" was heard "os manos"; 2 frames still "manos", 3 "humanos" (Whisper, 2026-10-28)."""
    toks = ps.split(" ")
    out = toks[:1]
    for t in toks[1:]:
        body = unicodedata.normalize("NFD", t).lstrip("".join(MARKS) + "ˈˌ")
        if unicodedata.normalize("NFD", out[-1]).endswith("z") and body[:1] in _SANDHI_VOWELS:
            t = t.lstrip(NUMBER_JOIN)                     # no gap left to mark: "às oito" azˈojtu
            if marks:
                n = unicodedata.normalize("NFD", t); k = len(n) - len(n.lstrip("ˈˌ"))
                if n[k + 1:k + 2] not in MARKS:
                    t = n[:k + 1] + CLITIC_VOWEL + n[k + 1:]
            out[-1] += t
        else:
            out.append(t)
    return " ".join(out)


def _article_after_a(ps: str, marks: bool = False) -> str:
    """"escolha a voz", "passa a fazer": a word ending in ɐ and the article/preposition "a" (ɐ) after it fuse into one
    open a, said as one word with the next ("escolhávoz", "passáfazer"). Written ə apart (the 2026-10-25 choice), the
    model left a 100 ms gap after "escolha", heard as a pause; fused, the native listener heard both right (A/B "C",
    2026-10-28). With `marks` the fused a is held at least 4 frames (HOLD): João's was 48-71 ms against Ana's 69-93 ms,
    heard "passafazer"; held, both ~95 ms (the listener's choice, 2026-10-28)."""
    toks = ps.split(" ")
    out = []
    i = 0
    while i < len(toks):
        t = toks[i]
        if t == "ɐ" and out and unicodedata.normalize("NFD", out[-1]).endswith("ɐ"):
            out[-1] = unicodedata.normalize("NFD", out[-1])[:-1] + "a" + (HOLD if marks else "")
            if i + 1 < len(toks):                                  # one word with the next: no gap left to mark
                out[-1] += toks[i + 1].lstrip(NUMBER_JOIN)
                i += 1
        else:
            out.append(t)
        i += 1
    return " ".join(out)


def phonemes_to_input_ids(ps: str) -> list[int]:
    """Reproduce kokoro/model.py tokenization exactly, but RAISE on unmapped symbols."""
    ids, dropped = [], []
    for s in ps:
        i = VOCAB.get(s)
        if i is None:
            dropped.append(s)
        else:
            ids.append(i)
    if dropped:
        detail = ", ".join(
            f"{d!r} (U+{ord(d):04X} {unicodedata.name(d, '?')})" for d in sorted(set(dropped)))
        raise UnmappedSymbol(f"symbols absent from Kokoro vocab: {detail}")
    return [BOUNDARY_ID, *ids, BOUNDARY_ID]


def text_to_input_ids(text: str) -> tuple[str, list[int]]:
    ps = phonemize(text)
    if len(ps) > MAX_PHONEME_LEN:
        raise ValueError(
            f"phoneme string is {len(ps)} chars, over the {MAX_PHONEME_LEN} cap; chunk upstream")
    return ps, phonemes_to_input_ids(ps)


if __name__ == "__main__":
    assert_lect_support()
    for t in ["Bom dia. Chamo-me Teodoro e vivo em Lisboa.", "Custa 1234 euros."]:
        ps, ids = text_to_input_ids(t)
        print(f"{t}\n  -> {ps}\n  -> {len(ids)} ids\n")
