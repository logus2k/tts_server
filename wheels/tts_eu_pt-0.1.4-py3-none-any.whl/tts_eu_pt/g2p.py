#!/usr/bin/env python3
"""European Portuguese G2P via TugaPhone — the permissive replacement for espeak-ng.

WHY: espeak-ng is GPLv3, which forces copyleft on anyone redistributing a product built
on it. The project's goal is unrestricted commercial reuse, so espeak must go.
TugaPhone is Apache-2.0 and won an objective bake-off against espeak on a neutral
Wiktionary reference (PER 0.0994 vs 0.1147, n=30).

CRITICAL — THE TUGAPHONE VERSION MATTERS:
  Sub-regional lects need tugaphone >= 1.2.0a1 (pinned in pyproject.toml). On the OLDER
  STABLE release, get_dialect_inventory() only branched on pt-BR/AO/MZ/TL and defaulted
  everything else to EuropeanPortuguese(), so "pt-PT-x-lisbon", "pt-PT-x-porto" and even
  nonsense strings all returned generic pt-PT output and LisbonPortuguese was unreachable
  dead code. That fix has since shipped to PyPI, so the dev branch is no longer required:
  measured on 1.2.0a1, "pt-PT-x-lisbon" -> "u ˈviɲu ˈveɾd" vs generic "o ˈviɲu ˈveɾd".
  assert_lect_support() enforces this at run time, whatever release is installed.

  CAVEAT: an UNKNOWN lect string still falls back to generic pt-PT silently rather than
  raising, so a typo in LECT degrades quality without any error.

LECT: pt-PT-x-lisbon. TugaPhone's own scoreboard puts it far ahead of generic pt-PT
(PER 0.1007 vs 0.2294; word accuracy 0.4330 vs 0.1540).

This module mirrors scripts/ptpt_g2p.py so it can be swapped in as the single source of
truth for text -> input_ids. Training and inference MUST use the same one.
"""
import json
import sys
import unicodedata
from pathlib import Path

from . import gender as _gender

_ASSETS = Path(__file__).resolve().parent / "assets"

CFG = json.loads((_ASSETS / "kokoro_config.json").read_text())
VOCAB: dict[str, int] = CFG["vocab"]
N_TOKEN: int = CFG["n_token"]
ID2SYM: dict[int, str] = {i: s for s, i in VOCAB.items()}

MAX_PHONEME_LEN = 510   # kokoro/model.py caps input at 510 chars
BOUNDARY_ID = 0         # input_ids = [0, *ids, 0]
LECT = "pt-PT-x-lisbon"

# TugaPhone emits 4 symbols outside Kokoro's 178-token vocab. Measured over the full
# hard-case corpus; counts were r-uvular 12, dark-l 12, ascii-g 9, apico-alveolar-s 3.
SYMBOL_MAP = {
    "ʀ": "ʁ",   # uvular trill -> uvular fricative (id 128); pt-PT rhotic, same phoneme class
    "ɫ": "l",   # velarised (dark) l -> plain l (id 54); Kokoro has no dark-l token
    "g": "ɡ",   # ASCII g -> IPA script g (U+0261, id 92). Classic IPA trap.
    "̺": "",  # COMBINING INVERTED BRIDGE BELOW (apico-alveolar s). A genuine pt-PT
                   # feature Kokoro's vocab cannot represent -- dropped, not approximated.
}
SYLLABLE_SEP = "·"      # TugaPhone marks syllables; not a phoneme

_phonemizer = None


class UnmappedSymbol(ValueError):
    """Raised at prep time so unmapped symbols fail loudly instead of being silently
    dropped by kokoro's vocab.get(p) at inference time."""


def assert_lect_support() -> None:
    """Fail fast if the installed tugaphone ignores sub-regional lects.

    Probes behaviour rather than the version string, so it stays correct no matter which
    release or branch is installed.
    """
    tp = _get()
    a = tp.phonemize_sentence("o vinho verde", "pt-PT")
    b = tp.phonemize_sentence("o vinho verde", "pt-PT-x-porto")
    if a == b:
        raise RuntimeError(
            "The installed tugaphone ignores sub-regional lects, so "
            f"{LECT} would silently degrade to generic pt-PT. Upgrade:\n"
            '  pip install "tugaphone>=1.2.0a1"'
        )


# Former name, kept so existing callers keep working. The check is no longer about a
# branch -- the lect fix shipped to PyPI in 1.2.0a1.
assert_dev_branch = assert_lect_support


def _get():
    global _phonemizer
    if _phonemizer is None:
        from tugaphone import TugaPhonemizer
        _phonemizer = TugaPhonemizer()
    return _phonemizer


# European-Portuguese speech drops the connector "e" only INSIDE the twenties, and only
# before units 5-9:  25-29 -> "vinte cinco" ... "vinte nove", BUT 21/22/23/24 KEEP it ->
# "vinte e um/dois/três/quatro". Holds at any scale (124 -> "cento e vinte e quatro",
# 126 -> "cento e vinte seis", 2026 -> "dois mil e vinte seis"). Every other tens keeps it
# too (39 -> "trinta e nove"). Confirmed by the native speaker. num2words/tugaphone always
# insert the "e", so we strip it only for vinte + {cinco..nove}.
_ELIDE_E_AFTER = {"vinte"}
_ELIDE_UNITS = {"cinco", "seis", "sete", "oito", "nove"}


def _drop_tens_units_e(text: str) -> str:
    words = text.split()
    out, i = [], 0
    n = len(words)
    while i < n:
        if (i + 2 < n and words[i].lower() in _ELIDE_E_AFTER
                and words[i + 1].lower() == "e" and words[i + 2].lower() in _ELIDE_UNITS):
            out.append(words[i])         # keep "vinte"
            out.append(words[i + 2])     # keep the unit (4-9), drop the "e" between
            i += 3
        else:
            out.append(words[i])
            i += 1
    return " ".join(out)


_DASHES = {"-", "–", "—", "−"}


def _split_number_ranges(text: str) -> str:
    """A dash BETWEEN two digits is a numeric range: "1139-1185" -> "1139 a 1185", read
    "mil ... a mil ...". Without this the glued token "1139-1185" reaches num2words as one
    unparseable string, stays as raw digits, and gets DROPPED (digits aren't in the vocab).
    Char-scan (no regex): only a dash flanked by digits is touched, so word hyphens
    ("chamo-me", "guarda-chuva") stay intact."""
    n = len(text)
    out = []
    for i, ch in enumerate(text):
        if ch in _DASHES and 0 < i < n - 1 and text[i - 1].isdigit() and text[i + 1].isdigit():
            out.append(" a ")
        else:
            out.append(ch)
    return "".join(out)


_OPENING_MARKS = set('([{“‘«')
_CLOSING_MARKS = set(',;:!?.)]}”’»…')


def _detach_marks(text: str) -> str:
    """Put a space between a word and the punctuation glued to it, so tugaphone's number expander sees bare tokens.

    It splits on whitespace only, and measured on 1.2.0a1 it (a) leaves a number with a glued mark as raw digits, which
    the tokenizer then DROPS ("1185)" / "1185," / "«1185"), (b) swallows the '.' after a number, so a sentence end
    vanishes ("Nasceu em 1185. Depois" became one run-on chunk), and (c) misses gender agreement when the noun carries
    a mark ("2 casas," read "dois casas"). A mark BETWEEN two digits (a decimal or thousands separator) is left alone.
    _reattach_marks undoes the spacing afterwards. Char-scan (no regex)."""
    n = len(text)
    out = []
    for i, ch in enumerate(text):
        between_digits = 0 < i < n - 1 and text[i - 1].isdigit() and text[i + 1].isdigit()
        word_internal = i + 1 < n and text[i + 1].isalnum()   # "d’água", "n.º": the mark is inside the word
        if ch in _CLOSING_MARKS and not between_digits and not word_internal and i > 0 and text[i - 1].isalnum():
            out.append(" ")
        out.append(ch)
        if ch in _OPENING_MARKS and i + 1 < n and text[i + 1].isalnum():
            out.append(" ")
        elif ch == '"':                      # straight quote: opening before a word, closing after one
            if i + 1 < n and text[i + 1].isalnum() and (i == 0 or text[i - 1].isspace()):
                out.append(" ")
            elif i > 0 and text[i - 1].isalnum():
                out.insert(len(out) - 1, " ")
    return "".join(out)


def _reattach_marks(text: str) -> str:
    """Inverse of _detach_marks: a closing mark hugs the word before it, an opening mark the word after it."""
    words = text.split()
    out: list[str] = []
    glue_next = False
    open_quote = False
    for w in words:
        if w == '"':                          # straight quotes alternate: the 1st opens, the 2nd closes
            if open_quote and out:
                out[-1] += w
                glue_next = False
            else:
                out.append(w)
                glue_next = True
            open_quote = not open_quote
            continue
        if out and all(c in _CLOSING_MARKS for c in w):
            out[-1] += w
        elif glue_next:
            out[-1] += w
        else:
            out.append(w)
        glue_next = all(c in _OPENING_MARKS for c in w)
    return " ".join(out)


_ORDINAL_MARKS = {"º": False, "ª": True}      # masculine / feminine ordinal indicator -> is_feminine


def _ordinal_words(n: int, feminine: bool) -> str:
    from num2words import num2words
    words = num2words(n, lang="pt", to="ordinal").split()
    if feminine:                              # "vigésimo primeiro" -> "vigésima primeira": every word agrees
        words = [w[:-1] + "a" if w.endswith("o") else w for w in words]
    return " ".join(words)


def _expand_ordinals(text: str) -> str:
    """"8.º" -> "oitavo", "2.ª" -> "segunda", "3º" -> "terceiro". tugaphone RAISES on these (decimal.InvalidOperation),
    and that exception used to abort the expansion of every OTHER number in the same text, while the '.' of "8.º" was
    then cut by the sentence splitter ("o 8." + "º escalão"). The degree sign '°' is NOT treated as an ordinal.
    Token scan (no regex)."""
    out = []
    for w in text.split():
        lead, core, trail = _split_edges(w)
        head, hyphen, rest = core.partition("-")          # "1.º-ministro": the ordinal heads a compound
        mark = head[-1:] if head else ""
        if mark in _ORDINAL_MARKS:
            digits = head[:-1]
            if digits.endswith("."):
                digits = digits[:-1]
            if digits.isdigit():
                out.append(lead + _ordinal_words(int(digits), _ORDINAL_MARKS[mark]) + hyphen + rest + trail)
                continue
        out.append(w)
    return " ".join(out)


# Words that are never the noun a number counts, although MorphoBr files some as nouns (the letters "a", "o", "e";
# "mais", "cerca", "pela"). The lookahead for agreement stops at them.
_NOT_COUNTED = frozenset("""
a à às as o os ao aos e é de da das do dos em na nas no nos num numa um uma uns umas para pra pelo pela pelos pelas por
com sem até mais menos que ou se há tem têm são foi era eram será ser estar cerca entre sobre após desde apenas só quase
já não sim mesmo mesma todos todas cada quanto quantos quantas também ainda muito muitos muitas pouco poucos
este esta estes estas esse essa esses essas aquele aquela aqueles aquelas outro outra outros outras seu sua seus suas
vírgula mil
""".split())

# Nouns that NAME by number instead of counting: "página 2" is "página dois", "século 21" "século vinte e um". A number
# right after one of them is a masculine cardinal, whatever follows it.
_LABEL_NOUNS = frozenset("""
século séculos capítulo capítulos página páginas artigo artigos número alínea fase parte tomo volume livro ato cena
secção título anexo nível classe série lote bloco piso andar porta quarto sala linha ponto figura tabela quadro gráfico
temporada episódio versão modelo tipo grupo escalão item passo etapa jornada ronda opção cenário caso exemplo exercício
pergunta questão regra lei decreto norma via estrada lugar posição dia hora canal faixa
""".split())

# Before a number with no counted noun, these mean the hours: "às 2" -> "às duas", "das 2 às 3", "à 1 e meia".
_HOUR_WORDS = frozenset({"à", "às", "as", "das", "pelas"})


def _bare(w: str) -> str:
    return _split_edges(w)[1].lower()


_RANGE_WORDS = frozenset({"a", "e", "ou", "até"})


def _is_number(w: str) -> bool:
    from tugaphone.number_utils import NumberParser
    w = _split_edges(w)[1]
    return any(c.isdigit() for c in w) and (NumberParser.is_int(w) or NumberParser.is_float(w))


def _counted_gender(words: list[str], idx: int) -> str:
    """"M" or "F" for the number at words[idx]: agreement with the noun it counts, read off the text."""
    prev = _bare(words[idx - 1]) if idx > 0 else ""
    if prev == "vírgula" or prev in _LABEL_NOUNS:     # decimal digits; a label ("página 2")
        return _gender.MASC
    j = idx + 1
    while j < len(words):
        w = _bare(words[j])
        if w == "vírgula":                                  # "2,5 horas": the integer part agrees with "horas"
            j += 2
        elif w == "mil":                                    # "200 mil pessoas" -> "duzentas mil pessoas"
            j += 1
        elif (w in _RANGE_WORDS or words[j] == ",") and j + 1 < len(words) and _is_number(words[j + 1]):
            j += 2                                          # "2 a 3 semanas", "2, 3 ou 4 casas": the noun after all
        else:
            break
    if j < len(words):
        nxt = _bare(words[j])
        if nxt in ("das", "delas"):                     # "1 das casas" -> "uma das casas"
            return _gender.FEM
        if nxt in ("dos", "deles"):
            return _gender.MASC
        # Walk the noun phrase: the first word with a gender of its own decides, noun or adjective ("2 grandes e
        # bonitas casas": "grandes" has one form for both, "bonitas" is feminine). Words with no gender (common-gender
        # nouns, "grande"-type adjectives) and an "e" between adjectives are passed over; anything that is neither a
        # noun nor an adjective (a verb, a function word, a number) ends the phrase.
        k = j
        while k < len(words) and k - j < 6:
            w = _bare(words[k])
            if k > j and (w == "e" or words[k] == ","):     # "grandes e bonitas", "grandes , novas" (marks detached)
                k += 1
                continue
            if w in _NOT_COUNTED or not w.isalpha():
                break
            ng, ag = _gender.noun_gender(w), _gender.adjective_gender(w)
            for g in (ng, ag):
                if g in (_gender.MASC, _gender.FEM):
                    return g
            if ng is None and ag is None:
                break
            k += 1
    if prev in _HOUR_WORDS:
        return _gender.FEM
    return _gender.MASC


def _spell_number(word: str, gender: str) -> str:
    from tugaphone.number_utils import NumberParser
    return NumberParser.pronounce_number_word(word, gender="feminine" if gender == _gender.FEM else "masculine",
                                              is_brazilian=False)


def _spell_numbers(text: str) -> str:
    """Every number token -> pt-PT words, with the gender the counted noun asks for (see gender.py). This replaces
    tugaphone.number_utils.normalize_numbers, whose suffix-guess read "2 vezes" as "dois vezes" and, after "a"/"da",
    "a 2 quilómetros" as "a duas quilómetros"; its spelling engine is still the one used."""
    words = text.split()
    out = []
    for i, w in enumerate(words):
        if not _is_number(w):
            out.append(w)
            continue
        try:
            out.append(_spell_number(w, _counted_gender(words, i)))
        except Exception:
            out.append(w)
    return " ".join(out)


def _agree_with_acronyms(text: str) -> str:
    """A number before an acronym takes the acronym's gender: "2 SMS" -> "duas SMS", "21 PMEs" -> "vinte e uma PMEs".
    Runs at the TEXT level, before _spell_acronyms turns the acronym into letter names whose gender means nothing."""
    words = text.split()
    out = []
    for i, w in enumerate(words):
        lead, core, trail = _split_edges(w)
        if not trail and core.lstrip("-").isdigit() and i + 1 < len(words):
            g = _gender.acronym_gender(_split_edges(words[i + 1])[1])
            if g is not None:
                out.append(lead + _drop_tens_units_e(_spell_number(core, g)))
                continue
        out.append(w)
    return " ".join(out)


def normalize_numbers(text: str) -> str:
    """Expand digits to words. TugaPhone does NOT do this inside phonemize_sentence --
    raw digits pass straight through and would reach the tokenizer. Uses long scale for
    pt-PT and gender agreement from a noun lexicon. Expands ordinals (8.º -> oitavo), numeric
    ranges (1139-1185 -> "... a ...") and drops the tens+units "e" for natural pt-PT (25 -> "vinte cinco")."""
    text = _expand_ordinals(text)
    return _reattach_marks(_drop_tens_units_e(_spell_numbers(_detach_marks(_split_number_ranges(text)))))


# tugaphone sometimes puts the stress mark INSIDE a falling diphthong: "reinou" -> ʁɐˈjno, "deixou" -> dɐˈjʃo,
# "coisinha" -> koˈjziɲɐ, where pt-PT syllabifies ʁɐj.ˈno. A syllable cannot begin with glide + consonant, so the
# mark belongs after the glide. OFF by default: the voice was trained on tugaphone's placement (the misplaced form
# outnumbers the correct one in the training transcripts), and a Whisper A/B heard no difference, so whether the
# correction sounds better is for a native listener to decide. See documentation/open-issues-tts_eu_pt.md.
FIX_GLIDE_STRESS = False
_STRESS = "ˈ"
_GLIDES = set("jw")
_VOWELS = set("aɐeɛiɨoɔuəæ") | {"\u0303"}      # \u0303: the combining nasal tilde, part of the vowel before it


def _fix_glide_stress(ps: str) -> str:
    """Move a stress mark from before a glide to after it, when the glide is followed by a consonant and preceded by a
    vowel: ʁɐˈjno -> ʁɐjˈno. Char scan (no regex)."""
    out = list(ps)
    for i in range(1, len(out) - 2):
        if out[i] == _STRESS and out[i + 1] in _GLIDES and out[i - 1] in _VOWELS:
            after = out[i + 2]
            if after not in _VOWELS and after not in _GLIDES and not after.isspace() and after != _STRESS \
                    and after.isalpha():
                out[i], out[i + 1] = out[i + 1], out[i]
    return "".join(out)


# tugaphone writes a NASAL SCHWA (ɨ̃) for pretonic "en/em" in many words - pensou pɨ̃ˈso, sentindo sɨ̃ˈtĩdu,
# lembrou, mendigos, aventuras, compreendi - where pt-PT has ẽ (pẽˈso). Standard pt-PT has no nasal schwa; all 110
# distinct tokens carrying it in the training transcripts are this error. A native listener heard "pensou" as
# "pzou" (2026-10-24): the reduced vowel is dropped. Mapped to ẽ, which the voice knows from thousands of
# correctly transcribed words.
FIX_NASAL_SCHWA = True    # approved by the native listener, 2026-10-24
_NASAL_SCHWA = "ɨ\u0303"
_NASAL_E = "e\u0303"


def _clean(ps: str) -> str:
    """Strip syllable separators, decompose precomposed nasals, apply the symbol map."""
    ps = ps.replace(SYLLABLE_SEP, "")
    # TugaPhone emits BOTH precomposed (ẽ) and decomposed (ɐ + U+0303) nasals.
    # NFD makes it uniform, and the combining tilde is vocab id 17.
    ps = unicodedata.normalize("NFD", ps)
    for src, dst in SYMBOL_MAP.items():
        ps = ps.replace(src, dst)
    if FIX_NASAL_SCHWA:
        ps = ps.replace(_NASAL_SCHWA, _NASAL_E)          # after NFD, so the tilde is the separate U+0303
    if FIX_GLIDE_STRESS:
        ps = _fix_glide_stress(ps)
    return " ".join(ps.split())


def _strip_ordinal_marks(text: str) -> str:
    """Remove masculine/feminine ordinal indicators (3.º, 2.ª).

    TugaPhone's number parser raises decimal.InvalidOperation on these, so they are
    stripped as a fallback. Plain string replacement, no pattern matching.
    """
    for mark in ("º", "ª", "°"):
        text = text.replace("." + mark, "").replace(mark, "")
    return text


# Loanword override: English-pronounced borrowings ("online", "site", "email") that
# TugaPhone would lusophonize. Phonemes generated OFFLINE with espeak (GPL at prep time);
# only the phoneme dict ships. Curated to lowercase common nouns -- proper nouns and
# acronyms are excluded (Portuguese does not use their English pronunciation).
_LOANWORDS = None


def _loanwords() -> dict:
    global _LOANWORDS
    if _LOANWORDS is None:
        try:
            _LOANWORDS = json.loads((_ASSETS / "loanwords.json").read_text())
        except Exception:
            _LOANWORDS = {}
    return _LOANWORDS


def _loan_key(w: str) -> str:
    return w.strip(".,!?;:—…\"'()“”").lower()


def _phon_one(text: str, lect: str) -> str:
    try:
        return _clean(_get().phonemize_sentence(normalize_numbers(text), lect))
    except Exception:
        # ordinals (3.º) crash tugaphone's number parser; retry without the markers
        t = _strip_ordinal_marks(text)
        return _clean(_get().phonemize_sentence(normalize_numbers(t), lect))


# Acronyms spoken as Portuguese LETTER NAMES, not read as a syllable. "IA" (inteligência
# artificial) must sound "i á", not "ia"; "LLM" must sound "éle-éle-éme", not "lãm".
# The letter names are written with accents so TugaPhone gives the open-e spelling form
# (L = ˈɛlɨ, not the pronoun "ele" ˈel). The trailing comma injects a pause so the last
# letter does not merge into the next word. Expanded at the TEXT level (see phonemize) so
# the comma becomes a real KEEP_PUNCT pause token.
_ACRONYMS = {
    "IA": "i á,", "LLM": "éle éle éme,", "UTC": "u tê cê,",
    # The project's own name. Left raw, TugaPhone returns vowel-less clusters that
    # Portuguese phonotactics cannot realise -- "tts" -> ˈttʃ and "pt" -> ˈpt -- and the
    # decoder emits noise rather than speech. Confirmed by ear on 0.1.0.
    "tts_eu_pt": "tê tê ésse eu pê tê,",
    "tts-eu-pt": "tê tê ésse eu pê tê,",
    "TTS": "tê tê ésse,", "tts": "tê tê ésse,",
    "PT": "pê tê,",
    # NOTE: keys are matched case-SENSITIVELY on purpose. Lowercase "eu" is the pronoun
    # ("eu vou") and lowercase "ia" is a verb form ("ele ia"); mapping those to letter
    # names would corrupt ordinary text. Only add a lowercase key when the token is not
    # also a real Portuguese word -- "tts" qualifies, "eu" does not.
}

# Abbreviations expanded to full words at the TEXT level (before punctuation splitting,
# so the trailing "." is consumed here instead of becoming a sentence pause and the letter
# is not read on its own). "D." is the Portuguese honorific: "D. Afonso Henriques" ->
# "Dom Afonso Henriques", "D. Maria" -> "Dona Maria": _expand_acronyms picks the form from the given name
# (gender.name_gender); "Dom" is only the fallback when no name follows.
_ABBREVIATIONS = {"D.": "Dom", "n.º": "número", "N.º": "Número", "nº": "número", "Nº": "Número"}


_LEAD_PUNCT = '(“"‘¿¡'
_TRAIL_PUNCT = '.,;:!?)"”…'


def _split_edges(w: str) -> tuple[str, str, str]:
    """Return (leading punctuation, core, trailing punctuation) of a token."""
    i, j = 0, len(w)
    while i < j and w[i] in _LEAD_PUNCT:
        i += 1
    while j > i and w[j - 1] in _TRAIL_PUNCT:
        j -= 1
    return w[:i], w[i:j], w[j:]


def _expand_acronyms(text: str) -> str:
    words = text.split()
    out = []
    for i, w in enumerate(words):
        # Honorific abbreviations key on the EXACT token — the trailing '.' is PART of "D."
        # (it's what distinguishes it from a lone "D"), so it must not be stripped.
        if w == "D.":                          # Dom / Dona, by the given name that follows ("D. Maria" -> "Dona Maria")
            name = _split_edges(words[i + 1])[1] if i + 1 < len(words) else ""
            is_name = name[:1].isupper() and name.isalpha()
            out.append("Dona" if is_name and _gender.name_gender(name) == _gender.FEM else "Dom")
            continue
        if w in _ABBREVIATIONS:
            out.append(_ABBREVIATIONS[w])
            continue
        # Acronyms (IA, LLM, UTC) may carry surrounding punctuation ("UTC.", "(UTC)"):
        # strip it for the lookup and reattach, so they still expand at a sentence end.
        lead, core, trail = _split_edges(w)
        if core in _ABBREVIATIONS and not core.endswith("."):   # "n.º," / "(nº": the mark is not part of the key
            out.append(lead + _ABBREVIATIONS[core] + trail)
            continue
        repl = _ACRONYMS.get(core)
        if repl is not None:
            if trail and repl.endswith(","):
                repl = repl[:-1]   # the real punctuation already supplies the pause
            out.append(lead + repl + trail)
            continue
        out.append(w)
    return " ".join(out)


# Roman numerals, read the pt-PT way:
#   after a monarch's or pope's name: ordinal up to ten, gendered by the name ("D. Afonso I" -> "Primeiro",
#     "D. Maria II" -> "Segunda"), cardinal above ten ("Luís XIV" -> "catorze", "João XXIII" -> "vinte e três");
#   after a naming noun (século, capítulo, ...): cardinal ("século XIX" -> "dezanove");
#   before a noun: an ordinal that agrees with it ("II Guerra Mundial" -> "segunda Guerra Mundial").
# Only I, V and X (1-39) are read as numerals, so CD, CV, LX, MD and XL stay acronyms.
_ROMAN = {"I": 1, "V": 5, "X": 10}


def _roman_value(s: str) -> int | None:
    if not s or any(c not in _ROMAN for c in s):
        return None
    total = 0
    for k, c in enumerate(s):
        v = _ROMAN[c]
        total += -v if k + 1 < len(s) and _ROMAN[s[k + 1]] > v else v
    canon = "X" * (total // 10) + ["", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX"][total % 10]
    return total if 0 < total < 40 and canon == s else None      # only canonical forms ("IIII" is not 4)


def _split_trailing_punct(w: str) -> tuple[str, str]:
    """Split a token into (core, trailing punctuation), e.g. 'I.' -> ('I', '.')."""
    i = len(w)
    while i > 0 and w[i - 1] in '.,;:!?)"“”':
        i -= 1
    return w[:i], w[i:]


def _cardinal(n: int, gender: str = "M") -> str:
    return _drop_tens_units_e(_spell_number(str(n), gender))


def _expand_regnal_numerals(text: str) -> str:
    words = text.split()
    out = []
    for i, w in enumerate(words):
        core, trail = _split_trailing_punct(w)
        n = _roman_value(core)
        if n is None:
            out.append(w)
            continue
        prev, prev_trail = _split_trailing_punct(words[i - 1]) if i > 0 else ("", "")
        nxt = _split_edges(words[i + 1])[1] if i + 1 < len(words) else ""
        if prev.lower() in _LABEL_NOUNS:                                        # "século XIX", "capítulo V"
            out.append(_cardinal(n) + trail)
            continue
        # A monarch's name: capitalised, right before the numeral (no punctuation between: "Luís XIV, II Guerra"),
        # and not itself a numeral.
        if prev.isalpha() and prev[:1].isupper() and len(prev) > 1 and not prev_trail \
                and prev.lower() not in _NOT_COUNTED and _roman_value(prev) is None:
            if n <= 10:                                                         # "D. Maria II" -> "Segunda"
                words_ = _ordinal_words(n, _gender.name_gender(prev) == _gender.FEM)
                out.append(words_[:1].upper() + words_[1:] + trail)
            else:                                                               # "Luís XIV" -> "catorze"
                out.append(_cardinal(n) + trail)
            continue
        # The next token must be a real word: a single letter ("A X N", "H O S P I T A L") means letters are being spelled.
        g = _gender.noun_gender(nxt) if len(nxt) > 1 and nxt.lower() not in _NOT_COUNTED else None
        if g is not None and (len(core) >= 2 or nxt[:1].isupper()):            # "II Guerra Mundial"
            out.append(_ordinal_words(n, g == _gender.FEM) + trail)
            continue
        out.append((_cardinal(n) if len(core) >= 2 else core) + trail)          # a lone "I"/"V"/"X" stays a letter
    return " ".join(out)


# Clock times: whole hours ("16:00") are read "<hora> horas", NOT "... e zero"; others "<hora> e <minutos>". "hora"
# is feminine, so 1/2 (and 21/22) take feminine forms; every other hour has no gender issue and is left as digits
# for the number expander. Hours are 0-23.
_FEM_HOURS = {1: "uma", 2: "duas", 21: "vinte e uma", 22: "vinte e duas"}


def _expand_clock_times(text: str) -> str:
    """"16:00" -> "16 horas", "1:00" -> "uma hora", "1:30" -> "uma e 30", "16:54" -> "16 e 54". A token the scan
    cannot read as HH:MM (e.g. "(16:54") is left for _split_time_colons. Token scan (no regex), so it must run BEFORE
    _split_time_colons turns the colon into " e "."""
    out = []
    for tok in text.split():
        core, trail = _split_trailing_punct(tok)
        hh_s, sep, mm_s = core.partition(":")
        if sep and hh_s.isdigit() and mm_s.isdigit() and len(mm_s) == 2 and 0 <= int(hh_s) <= 23 \
                and int(mm_s) <= 59:
            hh = int(hh_s)
            hour = _FEM_HOURS.get(hh, hh_s)   # feminine word ("hora"), else digits (expanded later)
            if mm_s == "00":
                out.append(f"{hour} {'hora' if hh == 1 else 'horas'}{trail}")
            else:                             # "1:30" -> "uma e 30", not "um e trinta"
                out.append(f"{hour} e {int(mm_s)}{trail}")
        else:
            out.append(tok)
    return " ".join(out)


def _split_time_colons(text: str) -> str:
    """A colon BETWEEN two digits is a clock time, read with "e": "16:54" ->
    "dezasseis e cinquenta e quatro". The colon is a KEEP_PUNCT token, so left alone it
    splits into a pause; this runs at the TEXT level before that split. Char-scan (no
    regex): only a colon flanked by digits is touched, so "Nota:", "são:" keep their pause."""
    n = len(text)
    out = []
    for i, ch in enumerate(text):
        if ch == ":" and 0 < i < n - 1 and text[i - 1].isdigit() and text[i + 1].isdigit():
            out.append(" e ")
        else:
            out.append(ch)
    return "".join(out)


def _normalize_separator_dashes(text: str) -> str:
    """A SPACED en/em-dash or hyphen used as a separator (" – ", " — ", " - ") becomes a
    comma pause, so "Henriques – Primeiro rei" doesn't run together (and isn't misheard as
    a regnal "Henriques Primeiro"). Number ranges ("1139-1185") have no surrounding spaces
    and are left for _split_number_ranges. Literal string replace, no regex."""
    for d in (" – ", " — ", " - "):
        text = text.replace(d, ", ")
    return text


def _normalize_number_separators(text: str) -> str:
    """European number formatting, handled BEFORE the '.'/',' splitter would break it:
    "." groups thousands and is dropped (92.073 -> 92073 -> "noventa e dois mil e setenta e
    três"); "," is the decimal mark, spoken "vírgula" (10,4 -> "dez vírgula quatro").
    Char-scan (no regex): only a separator BETWEEN two digits is touched, so sentence-final
    periods and list commas keep their pause."""
    n = len(text)
    out = []
    for i, ch in enumerate(text):
        between = 0 < i < n - 1 and text[i - 1].isdigit() and text[i + 1].isdigit()
        if between and ch == ".":
            continue                       # thousands separator -> drop
        if between and ch == ",":
            out.append(" vírgula ")        # decimal mark -> spoken word
            continue
        out.append(ch)
    return "".join(out)


# Any other acronym - a token of 2 to 6 capital letters (IMT, IRS, LTV, HPP, TAEG, CRC) - is SPELLED with the letter
# names below: Portuguese readers spell such tokens, and read raw they came out as a syllable ("IMT" -> ĩt) or as an
# unpronounceable cluster ("LTV" -> ltv, which the decoder renders as noise). Measured in the movies' narration,
# 2026-10-24. Runs after the regnal numerals (so "D. João VI" stays "Sexto"); _ACRONYMS above keeps its special forms.
_LETTER_NAMES = {"A": "á", "B": "bê", "C": "cê", "D": "dê", "E": "é", "F": "éfe", "G": "gê", "H": "agá", "I": "i",
                 "J": "jota", "K": "capa", "L": "éle", "M": "éme", "N": "éne", "O": "ó", "P": "pê", "Q": "quê", "R": "érre",
                 "S": "ésse", "T": "tê", "U": "u", "V": "vê", "W": "dâblio", "X": "xis", "Y": "ípsilon", "Z": "zê"}
# Capital-letter words that are read as words, not spelled (extend when one comes up: ONU, NATO, ...).
_READ_AS_WORDS = frozenset({"ONU", "NATO", "UNESCO", "OTAN", "SIDA"})


def _spell_acronyms(text: str) -> str:
    out = []
    for w in text.split():
        lead, core, trail = _split_edges(w)
        if len(core) >= 3 and core.endswith("s") and core[:-1].isupper() and core[:-1].isalpha() \
                and core[:-1] not in _READ_AS_WORDS and all(c in _LETTER_NAMES for c in core[:-1]):
            # A plural acronym ("PMEs", "ONGs"): the letters, with the plural s on the last one ("pê éme és").
            spelled = " ".join(_LETTER_NAMES[c] for c in core[:-1]) + "s"
            out.append(lead + spelled + (trail if trail else ","))
            continue
        if 2 <= len(core) <= 6 and core.isalpha() and core.isupper() and core not in _READ_AS_WORDS \
                and all(c in _LETTER_NAMES for c in core):
            spelled = " ".join(_LETTER_NAMES[c] for c in core)
            out.append(lead + spelled + (trail if trail else ","))   # the comma: the last letter does not merge into the next word
            continue
        out.append(w)
    return " ".join(out)


def _expand_percent(text: str) -> str:
    """"3,5%" / "12 %" -> "3,5 por cento": a percent sign glued to its number kept the number from being expanded (its
    digits were dropped: "a taxa é de 3,5%" was read "três vírgula", measured 2026-10-24). Char-level: every '%' becomes
    " por cento" (and '‰' " por mil"); the number before it is then a plain number token."""
    return text.replace("%", " por cento").replace("‰", " por mil").replace("  por", " por")


# Unit symbols after a number, read as pt-PT words (singular, plural). Left raw, "kg" phonemized as the vowel-less
# cluster ˈkɡ and "€" was dropped by the tokenizer, so "Custa 5 €." was read "Custa cinco." (measured 2026-10-24).
_UNITS = {
    "km": ("quilómetro", "quilómetros"), "m": ("metro", "metros"), "cm": ("centímetro", "centímetros"),
    "mm": ("milímetro", "milímetros"), "km/h": ("quilómetro por hora", "quilómetros por hora"),
    "m²": ("metro quadrado", "metros quadrados"), "km²": ("quilómetro quadrado", "quilómetros quadrados"),
    "m³": ("metro cúbico", "metros cúbicos"), "ha": ("hectare", "hectares"),
    "kg": ("quilo", "quilos"), "g": ("grama", "gramas"), "mg": ("miligrama", "miligramas"),
    "t": ("tonelada", "toneladas"), "l": ("litro", "litros"), "L": ("litro", "litros"),
    "ml": ("mililitro", "mililitros"), "cl": ("centilitro", "centilitros"), "dl": ("decilitro", "decilitros"),
    "h": ("hora", "horas"), "min": ("minuto", "minutos"), "s": ("segundo", "segundos"),
}
_CURRENCIES = {"€": ("euro", "euros"), "$": ("dólar", "dólares"), "£": ("libra", "libras")}
_SCALE_WORDS = frozenset({"mil", "milhão", "milhões", "bilião", "biliões"})


def _is_raw_number(s: str) -> bool:
    """"5", "2,50", "1.234,5", "-3": digits with European separators, before _normalize_number_separators runs."""
    s = s[1:] if s[:1] in "-+" else s
    return bool(s) and s[0].isdigit() and s[-1].isdigit() and all(c.isdigit() or c in ".," for c in s)


def _amount(num: str, unit: str) -> str:
    """'2,50' + '€' -> '2 euros e 50 cêntimos'; '1' + 'km' -> '1 quilómetro'; '2,5' + 'km' -> '2,5 quilómetros'."""
    if unit in _CURRENCIES:
        sing, plur = _CURRENCIES[unit]
        whole, comma, cents = num.rpartition(",")
        if comma and len(cents) == 2 and whole:
            units_n = int(whole.lstrip("-+").replace(".", "") or 0)
            cents_n = int(cents)
            parts = []
            if units_n:
                parts.append(f"{whole} {sing if units_n == 1 else plur}")
            if cents_n or not units_n:
                parts.append(f"{cents_n} {'cêntimo' if cents_n == 1 else 'cêntimos'}")
            return " e ".join(parts)
    else:
        sing, plur = _UNITS[unit]
    return f"{num} {sing if num.lstrip('-+') == '1' else plur}"


def _split_number_prefix(core: str) -> tuple[str, str]:
    """'5km' -> ('5', 'km'); '2,50€' -> ('2,50', '€'). ('', core) when core does not start with a number."""
    i = 1 if core[:1] in "-+" else 0
    j = i
    while j < len(core) and (core[j].isdigit() or core[j] in ".,"):
        j += 1
    while j > i and core[j - 1] in ".,":
        j -= 1
    num = core[:j]
    return (num, core[j:]) if _is_raw_number(num) else ("", core)


def _expand_units(text: str) -> str:
    """Units and currencies after (or, for currencies, before) a number: "2 kg" -> "2 quilos", "5€" -> "5 euros",
    "€ 2,50" -> "2 euros e 50 cêntimos", "100 km/h" -> "100 quilómetros por hora". Also the pt-PT clock form
    "16h30" -> "16 e 30" and "9h" -> "9 horas". Only next to a number, so a lone "m" or "g" is untouched.
    Token scan (no regex). Runs before _normalize_number_separators, which still has to see "2,50"."""
    words = text.split()
    out: list[str] = []
    i = 0
    while i < len(words):
        lead, core, trail = _split_edges(words[i])
        num, rest = _split_number_prefix(core)
        if num and (rest in _UNITS or rest in _CURRENCIES):                         # "5km", "5€"
            out.append(lead + _amount(num, rest) + trail)
        elif num and rest[:1] == "h" and (rest == "h" or (len(rest) == 3 and rest[1:].isdigit())) \
                and num.isdigit() and int(num) <= 23:                                 # "16h30", "9h"
            hour = _FEM_HOURS.get(int(num), num)
            whole = rest in ("h", "h00")                                               # "15h00" -> "15 horas"
            out.append(lead + (f"{hour} {'hora' if num == '1' else 'horas'}" if whole
                               else f"{hour} e {int(rest[1:])}") + trail)
        elif core[:1] in _CURRENCIES and _is_raw_number(core[1:]):                    # "€5"
            out.append(lead + _amount(core[1:], core[0]) + trail)
        elif core in _CURRENCIES and not trail and i + 1 < len(words) and not _split_edges(words[i + 1])[0] \
                and _is_raw_number(_split_edges(words[i + 1])[1]):                      # "€ 5"
            _, ncore, ntrail = _split_edges(words[i + 1])
            out.append(lead + _amount(ncore, core) + ntrail)
            i += 2
            continue
        elif (core in _UNITS or core in _CURRENCIES) and not lead and out:           # "5 km", "2,50 €", "300 mil €"
            plead, pcore, ptrail = _split_edges(out[-1])
            if _is_raw_number(pcore) and not ptrail:
                out[-1] = plead + _amount(pcore, core) + trail
            elif core in _CURRENCIES and not ptrail and pcore in _SCALE_WORDS and len(out) >= 2 \
                    and _is_raw_number(_split_edges(out[-2])[1]):
                # "300 mil €" -> "300 mil euros"; "2 milhões €" -> "2 milhões de euros"
                plural = _CURRENCIES[core][1]
                out.append(("de " if pcore != "mil" else "") + plural + trail)
            elif core in _CURRENCIES:                                             # a lone sign: "o €" -> "o euro"
                out.append(_CURRENCIES[core][0] + trail)
            else:
                out.append(words[i])
        elif core in _CURRENCIES:
            out.append(lead + _CURRENCIES[core][0] + trail)
        else:
            out.append(words[i])
        i += 1
    return " ".join(out)


_DEGREE_SCALES = {"C": "Celsius", "F": "Fahrenheit"}


def _expand_degrees(text: str) -> str:
    """"20°" -> "20 graus", "-3 °C" -> "-3 graus Celsius", "1°" -> "1 grau". The degree sign is not in the vocab and,
    glued to its number, kept the number from being expanded, so "Temperatura de 20°." was read "Temperatura de"
    (measured 2026-10-24). Token scan (no regex); a '°' not preceded by a number is left alone."""
    toks = text.split()
    out = []
    for i, w in enumerate(toks):
        lead, core, trail = _split_edges(w)
        num, deg, scale = core.partition("°")
        if deg and not num and out:                     # "20 °C": the sign is its own token, the number before it
            prev = _split_edges(out[-1])[1]
            num_ok = prev.replace(",", "").replace(".", "").lstrip("-").isdigit()
            if num_ok and scale in ("", *_DEGREE_SCALES):
                unit = "grau" if prev == "1" else "graus"
                out.append(lead + " ".join(x for x in (unit, _DEGREE_SCALES.get(scale, "")) if x) + trail)
                continue
        if deg and num.replace(",", "").replace(".", "").lstrip("-").isdigit() and scale in ("", *_DEGREE_SCALES):
            unit = "grau" if num == "1" else "graus"
            out.append(lead + " ".join(x for x in (num, unit, _DEGREE_SCALES.get(scale, "")) if x) + trail)
            continue
        out.append(w)
    return " ".join(out)


def normalize_text(text: str) -> str:
    """Text-level normalisation applied BEFORE phonemization or any '.'-based sentence
    splitting: number separators (92.073 / 10,4), separator dashes (" – " -> ", "), acronyms
    (IA -> 'i á'), honorific abbreviations (D. -> Dom / Dona) and Roman numerals (Afonso I ->
    Afonso Primeiro, D. Maria II -> Dona Maria Segunda, século XIX -> século dezanove).
    Idempotent, so it is safe to call more than once (the TTS server calls it before its
    streaming split; phonemize() calls it too)."""
    return _spell_acronyms(_expand_regnal_numerals(_expand_acronyms(_normalize_separator_dashes(
        _agree_with_acronyms(_split_time_colons(_expand_clock_times(_normalize_number_separators(_expand_units(_expand_degrees(_expand_percent(_expand_ordinals(text))))))))))))


def _raw_phonemize(text: str, lect: str) -> str:
    lw = _loanwords()
    words = text.split()
    # Only drop to word-level when a loanword is actually present, so ordinary text
    # keeps TugaPhone's full-phrase quality.
    if lw and any(_loan_key(w) in lw for w in words):
        parts = []
        for w in words:
            k = _loan_key(w)
            parts.append(lw[k] if k in lw else _phon_one(w, lect))
        return " ".join(p for p in parts if p)
    return _phon_one(text, lect)


# Punctuation Kokoro can actually represent (verified against config.json vocab).
KEEP_PUNCT = {c for c in ';:,.!?—…"()“”' if c in VOCAB}


def phonemize(text: str, lect: str = LECT, keep_punct: bool = True) -> str:
    """Text -> European Portuguese IPA, ready for Kokoro's vocab.

    PUNCTUATION: phonemizers drop it, but Kokoro's vocab contains 13 punctuation tokens
    and the model uses them for prosody -- sentence-final pauses, comma breaths,
    intonation resets. Training without them produces flat, run-on delivery.

    So the text is split at punctuation, each span phonemized separately, and the marks
    re-inserted between the spans as real tokens.
    """
    # Normalise first (acronyms -> "i á,", D. -> Dom, Afonso I -> Afonso Primeiro). This
    # may inject punctuation (the "IA" comma), so the split below treats it as a pause.
    text = normalize_text(text)
    if not keep_punct:
        return _raw_phonemize(text, lect)

    out, buf = [], []
    for ch in text:
        if ch in KEEP_PUNCT:
            span = "".join(buf).strip()
            buf = []
            if span:
                ps = _raw_phonemize(span, lect)
                if ps:
                    out.append(ps)
            out.append(ch)          # the punctuation token itself
        else:
            buf.append(ch)
    span = "".join(buf).strip()
    if span:
        ps = _raw_phonemize(span, lect)
        if ps:
            out.append(ps)

    # join so punctuation hugs the preceding phonemes and a space follows, e.g. "dˈiɐ. ʃˈɐ̃mʊ"
    s = ""
    for tok in out:
        if tok in KEEP_PUNCT:
            s = s.rstrip() + tok
        else:
            s = (s + " " + tok) if s else tok
    return " ".join(s.split())


def phonemes_to_input_ids(ps: str) -> list[int]:
    """Reproduce kokoro/model.py tokenization exactly, but RAISE on unmapped symbols."""
    ids, dropped = [], []
    for s in ps:
        i = VOCAB.get(s)
        if i is None:
            dropped.append(s)
        else:
            ids.append(i)
    if dropped:
        detail = ", ".join(
            f"{d!r} (U+{ord(d):04X} {unicodedata.name(d, '?')})" for d in sorted(set(dropped)))
        raise UnmappedSymbol(f"symbols absent from Kokoro vocab: {detail}")
    return [BOUNDARY_ID, *ids, BOUNDARY_ID]


def text_to_input_ids(text: str) -> tuple[str, list[int]]:
    ps = phonemize(text)
    if len(ps) > MAX_PHONEME_LEN:
        raise ValueError(
            f"phoneme string is {len(ps)} chars, over the {MAX_PHONEME_LEN} cap; chunk upstream")
    return ps, phonemes_to_input_ids(ps)


if __name__ == "__main__":
    assert_lect_support()
    for t in ["Bom dia. Chamo-me Teodoro e vivo em Lisboa.", "Custa 1234 euros."]:
        ps, ids = text_to_input_ids(t)
        print(f"{t}\n  -> {ps}\n  -> {len(ids)} ids\n")
