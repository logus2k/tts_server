"""Question intonation, shaped on the model's predicted pitch and energy curves.

The model ends a question as it ends a statement: the predicted pitch of the last word falls 4-10 semitones below the
voice's median for all four voices, "?" or "." (measured 2026-11-01) -- its training audio, audiobooks and Parliament
speeches, holds almost no questions. Here every question -- with an interrogative word too: "Onde fica a agência
mais próxima?" rises for the listener (2026-11-01) -- falls to a low on the last stressed syllable and rises at the end.
The contour is drawn over the last word before each "?", in semitones from the voice's own median pitch, and the
decoder renders it (KModel.f0_hook, KModel.dur_hook). Variant C of the A/B page (+7 st) was the listener's choice.
A question is marked from its first word on: "with the question mark the intonation starts at 'Onde', the whole
sentence is affected", and the same for every sentence that ends in "?" (the listener, 2026-11-01). The first word
(the first two after a short lead word: "O que", "De onde") is raised start_st above the model's own pitch, and the
raise fades out over the sentence, down to the last word's low; in a one-word question ("Porquê?") it covers the
syllables before the stress ("even the short ones", the listener).

Exclamations are left as the model reads them. A drawn surprise contour (opening +3/+5 st, peak +5/+8 st on the
lengthened last stressed vowel, steep fall) lost to the model's own reading on sentences, and on one-word exclamations it
was "not the best pattern": an exclamation may be surprise, joy, a warning or sarcasm, and the "!" does not say which
(the listener, 2026-11-01). One contour per mark fits questions, not exclamations.

Measured on the rendered audio (pitch-tracked, 2026-11-01), three things decide whether the rise is heard:
- the vowel that carries it must sound: the model fades the last vowel out (its energy falls from ~7 to ~3 over the
  vowel), so the energy is held through the rise;
- after the stress, weak vowels only (u, ɨ, i: "débito" ˈdɛbitu, "pagamento"): the model nearly devoices them, so the
  first one carries the rise, voiced, lengthened a little and nearly as loud as the stressed vowel ("débi-to",
  "pagamentu"); the rise once put inside the stressed vowel was heard "dé-ébito" (the listener, 2026-11-01). After a
  t the model predicted the final u of "pagamento" with no pitch at all, so the rise was silent until it was voiced;
- the carrying vowel needs time: the last word is capped at 4 frames per sound, so it is lengthened.
"""
import unicodedata
from typing import List, Optional

import numpy as np

_VOWELS = set("aɐeɛiɨoɔuəɪʊ")
_WEAK = set("uɨiʊɪə")                    # post-tonic vowels pt-PT nearly devoices at the end of a word
_BREAKS = set(".!?…")
_TILDE = "̃"
# short words the raise does not stop at: "O que", "De onde", "A que horas", "Com quem", "Para quê", "Em que"
LEAD_WORDS = ("de", "a", "o", "os", "as", "com", "por", "para", "em", "até", "desde", "e")
_LEAD: Optional[frozenset] = None


def _plain(ps: str) -> str:
    """Phonemes without stress marks, NFC: the model's tokens split a nasal vowel from its tilde."""
    return unicodedata.normalize("NFC", ps.replace("ˈ", "").replace("ˌ", "")).strip(" ,")


def _lead_forms() -> frozenset:
    global _LEAD
    if _LEAD is None:
        from . import g2p
        _LEAD = frozenset(_plain(g2p.phonemize(w).strip(" .")) for w in LEAD_WORDS)
    return _LEAD


class QuestionContour:
    """KModel hooks: the last stressed vowel of a question falls low_st below the voice's median pitch, then the pitch
    rises to rise_st above it; the carrying vowel lasts at least final_min frames (25 ms each), weak_min if weak."""

    def __init__(self, rise_st: float = 7.0, low_st: float = 2.0, final_min: int = 7, weak_min: int = 5,
                 start_st: float = 4.0):
        self.rise_st, self.low_st, self.final_min, self.weak_min = float(rise_st), float(low_st), int(final_min), \
            int(weak_min)
        self.start_st = float(start_st)

    @staticmethod
    def _opening(toks: List[str], start: int, q: int):
        """(first, last token) of the question's first word (with the next one after a lead word), or None."""
        words, i = [], start
        for j in range(start, q + 1):
            if j == q or toks[j] == " ":
                if j > i:
                    words.append((i, j - 1))
                i = j + 1
        if not words:
            return None
        if len(words) > 1 and _plain("".join(toks[words[0][0]:words[0][1] + 1])) in _lead_forms():
            return words[0][0], words[1][1]
        return words[0]

    @staticmethod
    def _questions(toks: List[str]):
        """(start, index of "?") of each question in the tokens."""
        start = 1
        for q, t in enumerate(toks):
            if t in _BREAKS:
                if t == "?":
                    yield start, q
                start = q + 1

    @staticmethod
    def _nucleus_and_carrier(toks: List[str], start: int, q: int):
        """(stressed vowel, vowel that carries the rise) of the last word before q, or None. The carrier is the last
        vowel, unless every vowel after the stress is weak: then the first of them (the stressed one when none)."""
        st = max([i + 1 for i in range(start, q) if toks[i] == " "] or [start])
        vow = [i for i in range(st, q) if toks[i] in _VOWELS]
        if not vow:
            return None
        marks = [i for i in range(st, q) if toks[i] == "ˈ"]
        nuc = next((i for i in range(marks[-1], q) if toks[i] in _VOWELS), vow[-1]) if marks else vow[0]
        post = [i for i in vow if i > nuc]
        if not post:
            carrier = nuc
        elif any(toks[i] not in _WEAK for i in post):
            carrier = post[-1]
        else:
            carrier = post[0]
        return nuc, carrier

    def lengthen(self, dur, toks: List[str]):
        """dur_hook: the vowel that carries the rise lasts at least final_min frames (weak_min for a weak one)."""
        for start, q in self._questions(toks):
            nc = self._nucleus_and_carrier(toks, start, q)
            if nc:
                weak = nc[1] != nc[0] and toks[nc[1]] in _WEAK
                dur[nc[1]] = max(int(dur[nc[1]]), self.weak_min if weak else self.final_min)
        return dur

    def __call__(self, F0, N, dur, toks: List[str]):
        """f0_hook: the contour and the held energy."""
        if "?" not in toks:
            return F0, N
        import torch
        f0 = F0[0].detach().cpu().numpy().astype(np.float64)
        en = N[0].detach().cpu().numpy().astype(np.float64)
        edges = np.concatenate([[0], np.cumsum(dur.cpu().numpy())]) * 2          # 2 frames per duration frame
        voiced = f0[f0 > 50]
        if len(f0) != edges[-1] or not len(voiced):
            return F0, N
        med = float(np.median(voiced))
        for start, q in self._questions(toks):
            nc = self._nucleus_and_carrier(toks, start, q)
            if not nc:
                continue
            head = self._opening(toks, start, q) if self.start_st else None
            if head:                                 # short ones too: "Porquê?" raises its "por"
                self._raise_from(f0, edges, head, int(edges[start]), int(edges[nc[0]]), med)
            self._shape(f0, en, edges, toks, nc[0], nc[1], q, med)
        back = lambda x, ref: torch.as_tensor(x, dtype=ref.dtype, device=ref.device).unsqueeze(0)
        return back(f0, F0), back(en, N)

    def _raise_from(self, f0, edges, head, s0, a, med):
        """start_st semitones on the model's own pitch from the sentence start to the end of its opening word, then
        fading linearly to none at the last word's stressed vowel (a): its contour (_shape) starts from there. In a
        one-word question ("Porquê?") the raise covers what comes before the stressed vowel."""
        e = min(int(edges[head[1] + 1]), a)
        for x in range(s0, a):
            if f0[x] <= 0.35 * med:
                continue                     # unvoiced frames keep their value
            st = self.start_st if x < e else self.start_st * (a - x) / max(1, a - e)
            f0[x] *= 2 ** (st / 12)

    def _shape(self, f0, en, edges, toks, nuc, carrier, q, med):
        a = int(edges[nuc])
        if carrier == nuc:                       # low in the first half of the stressed vowel, rise in the second
            b = a + max(1, (int(edges[nuc + 1]) - a) // 2)
        else:                                    # low on the stressed vowel, rise up to the end of the last one
            b = int(edges[nuc + 1])
        c = int(edges[carrier + 1])              # the rise is complete at the end of the carrying vowel (and its tilde)
        if carrier + 1 < q and toks[carrier + 1] == _TILDE:
            c = int(edges[carrier + 2])
        z = int(edges[q])                        # then the pitch stays high to the end of the voicing, into the "?"
        while z < len(f0) and f0[z] > 0.35 * med:
            z += 1
        hz = lambda s: med * 2 ** (s / 12)
        lo, hi = hz(-self.low_st), hz(self.rise_st)
        # glide from where the pitch is just before the vowel (raised by _raise_from in "Porquê?"), with no step
        cur = f0[a - 1] if a > 0 and f0[a - 1] > 0.35 * med else (f0[a] if f0[a] > 50 else lo)
        target = np.empty(z - a)
        for j in range(z - a):
            x = a + j
            if x < b:
                w = min(1.0, 2 * (x - a + 1) / max(1, b - a))
                target[j] = np.exp(np.log(cur) + (np.log(lo) - np.log(cur)) * w)
            elif x < c:
                w = (x - b + 1) / max(1, c - b)
                target[j] = np.exp(np.log(lo) + (np.log(hi) - np.log(lo)) * (0.5 - 0.5 * np.cos(np.pi * w)))
            else:
                target[j] = hi
        seg = f0[a:z]
        on = seg > 0.35 * med                    # voiced frames; unvoiced ones (s, ʃ, the pause) keep their value
        v0 = int(edges[carrier])
        on[v0 - a:c - a] = True                  # the carrying vowel is voiced even where the model devoiced it
        seg[on] = target[on]
        f0[a:z] = seg
        # the carrying vowel keeps its energy until its last 3 frames, which fade to the model's own; a weak one after
        # the stress is raised to just under the stressed vowel (the model left "débi-" 17 dB quieter than "dé")
        ref = float(en[v0:v0 + 2].max())
        if carrier != nuc and toks[carrier] in _WEAK:
            n0 = int(edges[nuc])
            ref = max(ref, float(en[n0:int(edges[nuc + 1])].max()) - 1.5)
        for x in range(v0, c):
            hold = ref if x < c - 3 else ref + (en[x] - ref) * (x - (c - 4)) / 3
            en[x] = max(en[x], hold)
