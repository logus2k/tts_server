"""tts_eu_pt — a permissively-licensed European Portuguese (pt-PT) text-to-speech voice.

Fine-tuned from Kokoro-82M, driven by a pt-PT G2P front-end (TugaPhone, Apache-2.0) with
European-Portuguese text normalisation: numbers, clock times, dates, honorifics
("D. Afonso I" -> "Dom Afonso Primeiro"), acronyms and English loanwords.

Quick start
-----------
    from tts_eu_pt import TTS

    tts = TTS()                              # downloads weights on first run
    wav = tts.say("Olá! São dezasseis horas.")   # numpy float32 @ 24 kHz
    tts.save("ola.wav", "Bem-vindo ao tts_eu_pt.")
"""
from __future__ import annotations

from pathlib import Path
from typing import List, Optional

import numpy as np

from . import g2p
from .download import ensure_weights

try:                                    # a library stays quiet: the vendored model logs every phoneme string and
    from loguru import logger as _log   # duration tensor at DEBUG, which loguru's default sink printed into the host
    _log.disable("tts_eu_pt")           # app (tts_server). Re-enable with logger.enable("tts_eu_pt").
except ImportError:
    pass

SAMPLE_RATE = 24000
_MAX_PHONEMES = 510          # Kokoro caps input at 510 tokens (kokoro/model.py)
# Consecutive sentences are read together, up to this many phonemes per model call. One call per sentence (up to
# 0.1.3) started every sentence with ~0.4 s of silence and stretched short ones: "Bom dia a todos!" took 1.75 s alone
# and 1.12 s in context, and a test paragraph went from 40.5 s to 30.3 s with clean transcription (2026-10-24).
_CHUNK_PHONEMES = 300
# Minimum pause after each punctuation mark, in ms, enforced on the model's predicted durations. pt-PT read speech
# pauses roughly 150-300 ms at a comma and 300-600 ms at a sentence end; the model alone gave 25-100 ms / 75-400 ms.
# The voice's natural rate, multiplied into every requested speed: speed=1.0 is read at 1.03x of the model's own
# pace. 0.9 was the native listener's choice for the expressive Stage-2 epoch 13 voice; the Parliament epochs read
# slower (Cortex text 75 -> 77 s from epoch 16 to 18): 1.03 was chosen on epoch 18, then 1.08 on epoch 19 over 1.03
# with 20% shorter pauses and over both together (2026-10-25). TTS(rate=1.0) disables it.
DEFAULT_RATE = 1.08
MAX_FRAMES = {"\u0303": 1, "ˈ": 2}   # per-token duration caps (25 ms frames): the nasal tilde and the stress mark; see TTS.__init__
LAST_WORD_MAX = 4                      # frames per phoneme of the last word of a sentence; see TTS.__init__
STRESSED_VOWEL_MIN = 4                 # frames for the vowel of a stressed syllable; see TTS.__init__
UNSTRESSED_END_MAX = 3                 # frames for a word's unstressed final vowel with no punctuation after; see TTS.__init__
DEFAULT_PAUSES_MS = {",": 250, ";": 300, ":": 300, ".": 550, "!": 550, "?": 550, "…": 600}
_END_MARKS = ".!?;:,…"
__version__ = "0.1.19"
__all__ = ["TTS", "SAMPLE_RATE"]


def _prepare(text: str) -> str:
    """The text normalised BEFORE it is split into sentences: the split cuts at every '.', so a thousands dot
    ("330.539" -> "330." + "539", the "mil" never spoken) or an ordinal ("8.º escalão" -> "o 8." + "º escalão", read
    "oito") must be words first. Measured 2026-10-24 by transcribing the voice: "330. 539 euros", "450. Zero euros"."""
    return g2p.normalize_numbers(g2p.normalize_text(text))


def _sentences(text: str) -> List[str]:
    """Split into sentence-sized chunks on . ! ? and newlines, so no chunk exceeds the
    510-token cap. Honorifics/times are already expanded by g2p.normalize_text upstream,
    so a bare '.' here is a real sentence end."""
    out, buf = [], []
    for ch in text:
        if ch == "|":                      # a list's separator ("Title | item | item"): a sentence break, never read
            s = "".join(buf).strip()
            if s:
                out.append(s if s[-1] in ".!?;:," else s + ".")   # an item without a final mark ends like a sentence
            buf = []
            continue
        buf.append(ch)
        if ch in ".!?\n":
            s = "".join(buf).strip()
            if s:
                out.append(s)
            buf = []
    tail = "".join(buf).strip()
    if tail:
        out.append(tail)
    return out or ([text.strip()] if text.strip() else [])


def _fit(ps: str) -> List[str]:
    """Phonemes of one sentence in pieces of at most _MAX_PHONEMES: cut at the last , ; : before the cap, else at the
    last space. Up to 0.1.3 a longer sentence was truncated at the cap and its end silently never spoken."""
    pieces = []
    while len(ps) > _MAX_PHONEMES:
        window = ps[:_MAX_PHONEMES]
        cut = max(window.rfind(m) for m in ",;:")
        if cut <= 0:
            cut = window.rfind(" ")
        if cut <= 0:
            cut = _MAX_PHONEMES - 1
        pieces.append(ps[:cut + 1].strip())
        ps = ps[cut + 1:].strip()
    if ps:
        pieces.append(ps)
    return pieces


def _chunks(text: str, budget: int = _CHUNK_PHONEMES) -> List[str]:
    """The phoneme strings to synthesise, one model call each: consecutive sentences of a paragraph joined up to
    `budget` phonemes, a paragraph (a line of the text) always starting a new chunk. Paragraphs are split BEFORE
    normalisation, which joins all whitespace: up to 0.1.3 a heading or list line with no final mark ran into the next
    line as one sentence. Such a line now ends with a full stop, so it is read as a sentence."""
    out: List[str] = []
    for line in text.splitlines():
        if not line.strip():
            continue
        pieces = [ps for sentence in _sentences(_prepare(line)) for ps in _fit(g2p.phonemize(sentence, number_marks=True)) if ps.strip()]
        # as many calls as filling each up to the budget needs, but EVEN in length: filled greedily, a paragraph's last
        # sentence could be left alone in a call, and a sentence read alone is read slower ("É simples, seguro e,
        # sobretudo, verificável!" 46 frames for "É simples" alone vs 40 after the sentence before it, 2026-10-25)
        n = _count_calls(pieces, budget)
        target = (sum(len(ps) for ps in pieces) + len(pieces)) / n
        cur = ""
        for ps in pieces:
            if cur and (len(cur) + 1 + len(ps) > budget or len(cur) + 1 + len(ps) / 2 > target):
                out.append(cur)
                cur = ps
            else:
                cur = f"{cur} {ps}" if cur else ps
        if cur:
            out.append(cur if cur[-1] in _END_MARKS else cur + ".")
    return out


def _count_calls(pieces: List[str], budget: int) -> int:
    n, cur = 0, 0
    for ps in pieces:
        if cur and cur + 1 + len(ps) > budget:
            n, cur = n + 1, len(ps)
        else:
            cur = cur + 1 + len(ps) if cur else len(ps)
    return n + (1 if cur else 0) or 1


class TTS:
    """European Portuguese speech synthesiser.

    Parameters
    ----------
    device:
        "cuda", "cpu", or None to auto-select CUDA when available.
    model_path, voicepack_path:
        Optional local overrides. When omitted, the weights are downloaded once from the
        Hugging Face repo (see tts_eu_pt.download) and cached.
    """

    def __init__(
        self,
        device: Optional[str] = None,
        model_path: Optional[str] = None,
        voicepack_path: Optional[str] = None,
        repo_id: Optional[str] = None,
        pauses_ms: Optional[dict] = None,
        rate: Optional[float] = None,
    ) -> None:
        import torch
        from .kokoro import KModel

        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        model_path, voicepack_path = ensure_weights(model_path, voicepack_path, repo_id)
        cfg = str(Path(__file__).resolve().parent / "assets" / "kokoro_config.json")

        self._torch = torch
        self.km = KModel(config=cfg, model=str(model_path)).to(self.device).eval()
        self.rate = DEFAULT_RATE if rate is None else float(rate)
        pauses = DEFAULT_PAUSES_MS if pauses_ms is None else pauses_ms
        self.km.min_pause_frames = {self.km.vocab[m]: ms / 25 for m, ms in pauses.items() if m in self.km.vocab}
        # a nasal vowel is the vowel plus its own U+0303 token; the model gave that token 2-9 frames of its own, heard
        # as a drag ("ao fiim da tarde"): capped at 1 frame. The stress mark is a token too (4-5 frames at the start of
        # a sentence: "É simples" heard "Éé"): capped at 2. Both the native listener's A/B choices (2026-10-25).
        self.km.max_frames = {self.km.vocab[m]: n for m, n in MAX_FRAMES.items() if m in self.km.vocab}
        # the model drags the last word of a sentence (4-8 frames per phoneme: "verificável!" heard slowed down, "quê."
        # heard "quêé"): capped at 4, the native listener's choice over 3 and none (2026-10-25)
        self.km.last_word_max = LAST_WORD_MAX
        # before that last word the model sped up instead (stressed vowels of 1-2 frames: "a decidir quem lê o quê"
        # heard rushed): a stressed vowel lasts at least 4 frames, the native listener's choice over 3 and none
        self.km.stressed_vowel_min = STRESSED_VOWEL_MIN
        # little pauses inside a sentence ("plataforma", "indica" with their last vowel stretched to 125-175 ms):
        # capped at 75 ms when no punctuation follows, the native listener's choice "B" (2026-10-25)
        self.km.unstressed_end_max = UNSTRESSED_END_MAX
        self.pack = torch.load(str(voicepack_path), map_location=self.device, weights_only=True)

    # -- public API -------------------------------------------------------------
    def say(self, text: str, speed: float = 1.0) -> np.ndarray:
        """Synthesise ``text`` to a float32 waveform at 24 kHz. ``speed`` > 1 is faster."""
        torch = self._torch
        chunks: List[np.ndarray] = []
        for ps in _chunks(text):
            ref = self.pack[len(ps.replace(g2p.NUMBER_JOIN, "").replace(g2p.KEEP_VOWEL, "")) - 1].to(self.device)   # marks are not tokens
            with torch.no_grad():
                audio = self.km(ps, ref, float(speed) * self.rate, return_output=True).audio
            a = audio.detach().cpu().numpy() if hasattr(audio, "detach") else np.asarray(audio)
            chunks.append(a.astype(np.float32))

        if not chunks:
            return np.zeros(0, dtype=np.float32)
        return np.concatenate(chunks) if len(chunks) > 1 else chunks[0]

    def save(self, path: str, text: str, speed: float = 1.0) -> str:
        """Synthesise ``text`` and write a 24 kHz mono WAV to ``path``. Returns the path."""
        import soundfile as sf

        wav = self.say(text, speed=speed)
        sf.write(path, wav, SAMPLE_RATE, subtype="PCM_16")
        return path
