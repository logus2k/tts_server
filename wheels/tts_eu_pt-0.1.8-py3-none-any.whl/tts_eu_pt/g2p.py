#!/usr/bin/env python3
"""European Portuguese G2P via TugaPhone — the permissive replacement for espeak-ng.

WHY: espeak-ng is GPLv3, which forces copyleft on anyone redistributing a product built
on it. The project's goal is unrestricted commercial reuse, so espeak must go.
TugaPhone is Apache-2.0 and won an objective bake-off against espeak on a neutral
Wiktionary reference (PER 0.0994 vs 0.1147, n=30).

CRITICAL — THE TUGAPHONE VERSION MATTERS:
  Sub-regional lects need tugaphone >= 1.2.0a1 (pinned in pyproject.toml). On the OLDER
  STABLE release, get_dialect_inventory() only branched on pt-BR/AO/MZ/TL and defaulted
  everything else to EuropeanPortuguese(), so "pt-PT-x-lisbon", "pt-PT-x-porto" and even
  nonsense strings all returned generic pt-PT output and LisbonPortuguese was unreachable
  dead code. That fix has since shipped to PyPI, so the dev branch is no longer required:
  measured on 1.2.0a1, "pt-PT-x-lisbon" -> "u ˈviɲu ˈveɾd" vs generic "o ˈviɲu ˈveɾd".
  assert_lect_support() enforces this at run time, whatever release is installed.

  CAVEAT: an UNKNOWN lect string still falls back to generic pt-PT silently rather than
  raising, so a typo in LECT degrades quality without any error.

LECT: pt-PT-x-lisbon. TugaPhone's own scoreboard puts it far ahead of generic pt-PT
(PER 0.1007 vs 0.2294; word accuracy 0.4330 vs 0.1540).

This module mirrors scripts/ptpt_g2p.py so it can be swapped in as the single source of
truth for text -> input_ids. Training and inference MUST use the same one.
"""
import json
import sys
import unicodedata
from typing import Optional
from pathlib import Path

from . import gender as _gender

_ASSETS = Path(__file__).resolve().parent / "assets"

CFG = json.loads((_ASSETS / "kokoro_config.json").read_text())
VOCAB: dict[str, int] = CFG["vocab"]
N_TOKEN: int = CFG["n_token"]
ID2SYM: dict[int, str] = {i: s for s, i in VOCAB.items()}

MAX_PHONEME_LEN = 510   # kokoro/model.py caps input at 510 chars
BOUNDARY_ID = 0         # input_ids = [0, *ids, 0]
LECT = "pt-PT-x-lisbon"

# TugaPhone emits 4 symbols outside Kokoro's 178-token vocab. Measured over the full
# hard-case corpus; counts were r-uvular 12, dark-l 12, ascii-g 9, apico-alveolar-s 3.
SYMBOL_MAP = {
    "ʀ": "ʁ",   # uvular trill -> uvular fricative (id 128); pt-PT rhotic, same phoneme class
    "ɫ": "l",   # velarised (dark) l -> plain l (id 54); Kokoro has no dark-l token
    "g": "ɡ",   # ASCII g -> IPA script g (U+0261, id 92). Classic IPA trap.
    "̺": "",  # COMBINING INVERTED BRIDGE BELOW (apico-alveolar s). A genuine pt-PT
                   # feature Kokoro's vocab cannot represent -- dropped, not approximated.
}
SYLLABLE_SEP = "·"      # TugaPhone marks syllables; not a phoneme

_phonemizer = None


class UnmappedSymbol(ValueError):
    """Raised at prep time so unmapped symbols fail loudly instead of being silently
    dropped by kokoro's vocab.get(p) at inference time."""


def assert_lect_support() -> None:
    """Fail fast if the installed tugaphone ignores sub-regional lects.

    Probes behaviour rather than the version string, so it stays correct no matter which
    release or branch is installed.
    """
    tp = _get()
    a = tp.phonemize_sentence("o vinho verde", "pt-PT")
    b = tp.phonemize_sentence("o vinho verde", "pt-PT-x-porto")
    if a == b:
        raise RuntimeError(
            "The installed tugaphone ignores sub-regional lects, so "
            f"{LECT} would silently degrade to generic pt-PT. Upgrade:\n"
            '  pip install "tugaphone>=1.2.0a1"'
        )


# Former name, kept so existing callers keep working. The check is no longer about a
# branch -- the lect fix shipped to PyPI in 1.2.0a1.
assert_dev_branch = assert_lect_support


def _get():
    global _phonemizer
    if _phonemizer is None:
        from tugaphone import TugaPhonemizer
        _phonemizer = TugaPhonemizer()
        _phonemizer.phonemize_sentence("a", LECT)          # registers the tugalex overlay
        _restress_unmarked_entries()
    return _phonemizer


def _restress_unmarked_entries() -> None:
    """tugalex has ~147 Lisbon entries with syllables but NO stress mark (paciente pɐ·sjẽt,
    experiência ɐjʃ·pɨ·ɾjẽ·sjɐ); the engine then stresses the FIRST syllable (ˈpɐsjẽt). In all of
    them that carry an "ie" glide syllable (-ente/-ência/-ense/-ento/-ieta/-ieza...), that syllable
    is the stressed one (Wiktionary pt-PT: experiente (i)ʃ.pɨˈɾjẽ.tɨ). Entries cut short by the
    lexicon (microfarad "mi·kɾɔ·") are dropped so the rules read the whole word. Patched in the
    in-memory overlay orthography2ipa reads on every lookup."""
    try:
        import orthography2ipa.lexicon as o2l
        from tugalex import TugaLexicon
    except ImportError:
        return
    overlay = o2l.get_lexicon(LECT)
    if not overlay:
        return
    lex = TugaLexicon()
    for word in lex.get_wordlist():
        ipa = lex.get_phonemes(word)
        if not ipa or "·" not in ipa or "ˈ" in ipa or "ˌ" in ipa or word not in overlay:
            continue
        if ipa.endswith("·"):
            overlay.pop(word, None)
            continue
        syl = ipa.split("·")
        glide = [i for i, x in enumerate(syl) if any(g in unicodedata.normalize("NFD", x)
                                                    for g in ("je", "jɛ"))]
        if glide:
            k = glide[-1]
            overlay[word] = "".join(("ˈ" if i == k else "") + x for i, x in enumerate(syl))


# European-Portuguese speech drops the connector "e" only INSIDE the twenties, and only
# before units 5-9:  25-29 -> "vinte cinco" ... "vinte nove", BUT 21/22/23/24 KEEP it ->
# "vinte e um/dois/três/quatro". Holds at any scale (124 -> "cento e vinte e quatro",
# 126 -> "cento e vinte seis", 2026 -> "dois mil e vinte seis"). Every other tens keeps it
# too (39 -> "trinta e nove"). Confirmed by the native speaker. num2words/tugaphone always
# insert the "e", so we strip it only for vinte + {cinco..nove}.
_ELIDE_E_AFTER = {"vinte"}
_ELIDE_UNITS = {"cinco", "seis", "sete", "oito", "nove"}


def _drop_tens_units_e(text: str) -> str:
    words = text.split()
    out, i = [], 0
    n = len(words)
    while i < n:
        if (i + 2 < n and words[i].lower() in _ELIDE_E_AFTER
                and words[i + 1].lower() == "e" and words[i + 2].lower() in _ELIDE_UNITS):
            out.append(words[i])         # keep "vinte"
            out.append(words[i + 2])     # keep the unit (4-9), drop the "e" between
            i += 3
        else:
            out.append(words[i])
            i += 1
    return " ".join(out)


_DASHES = {"-", "–", "—", "−"}


def _split_number_ranges(text: str) -> str:
    """A dash BETWEEN two digits is a numeric range: "1139-1185" -> "1139 a 1185", read
    "mil ... a mil ...". Without this the glued token "1139-1185" reaches num2words as one
    unparseable string, stays as raw digits, and gets DROPPED (digits aren't in the vocab).
    Char-scan (no regex): only a dash flanked by digits is touched, so word hyphens
    ("chamo-me", "guarda-chuva") stay intact."""
    n = len(text)
    out = []
    for i, ch in enumerate(text):
        if ch in _DASHES and 0 < i < n - 1 and text[i - 1].isdigit() and text[i + 1].isdigit():
            out.append(" a ")
        else:
            out.append(ch)
    return "".join(out)


_OPENING_MARKS = set('([{“‘«')
_CLOSING_MARKS = set(',;:!?.)]}”’»…')


def _detach_marks(text: str) -> str:
    """Put a space between a word and the punctuation glued to it, so tugaphone's number expander sees bare tokens.

    It splits on whitespace only, and measured on 1.2.0a1 it (a) leaves a number with a glued mark as raw digits, which
    the tokenizer then DROPS ("1185)" / "1185," / "«1185"), (b) swallows the '.' after a number, so a sentence end
    vanishes ("Nasceu em 1185. Depois" became one run-on chunk), and (c) misses gender agreement when the noun carries
    a mark ("2 casas," read "dois casas"). A mark BETWEEN two digits (a decimal or thousands separator) is left alone.
    _reattach_marks undoes the spacing afterwards. Char-scan (no regex)."""
    n = len(text)
    out = []
    for i, ch in enumerate(text):
        between_digits = 0 < i < n - 1 and text[i - 1].isdigit() and text[i + 1].isdigit()
        word_internal = i + 1 < n and text[i + 1].isalnum()   # "d’água", "n.º": the mark is inside the word
        if ch in _CLOSING_MARKS and not between_digits and not word_internal and i > 0 and text[i - 1].isalnum():
            out.append(" ")
        out.append(ch)
        if ch in _OPENING_MARKS and i + 1 < n and text[i + 1].isalnum():
            out.append(" ")
        elif ch == '"':                      # straight quote: opening before a word, closing after one
            if i + 1 < n and text[i + 1].isalnum() and (i == 0 or text[i - 1].isspace()):
                out.append(" ")
            elif i > 0 and text[i - 1].isalnum():
                out.insert(len(out) - 1, " ")
    return "".join(out)


def _reattach_marks(text: str) -> str:
    """Inverse of _detach_marks: a closing mark hugs the word before it, an opening mark the word after it."""
    words = text.split()
    out: list[str] = []
    glue_next = False
    open_quote = False
    for w in words:
        if w == '"':                          # straight quotes alternate: the 1st opens, the 2nd closes
            if open_quote and out:
                out[-1] += w
                glue_next = False
            else:
                out.append(w)
                glue_next = True
            open_quote = not open_quote
            continue
        if out and all(c in _CLOSING_MARKS for c in w):
            out[-1] += w
        elif glue_next:
            out[-1] += w
        else:
            out.append(w)
        glue_next = all(c in _OPENING_MARKS for c in w)
    return " ".join(out)


_ORDINAL_MARKS = {"º": False, "ª": True}      # masculine / feminine ordinal indicator -> is_feminine


def _ordinal_words(n: int, feminine: bool) -> str:
    from num2words import num2words
    words = num2words(n, lang="pt", to="ordinal").split()
    if feminine:                              # "vigésimo primeiro" -> "vigésima primeira": every word agrees
        words = [w[:-1] + "a" if w.endswith("o") else w for w in words]
    return " ".join(words)


def _expand_ordinals(text: str) -> str:
    """"8.º" -> "oitavo", "2.ª" -> "segunda", "3º" -> "terceiro". tugaphone RAISES on these (decimal.InvalidOperation),
    and that exception used to abort the expansion of every OTHER number in the same text, while the '.' of "8.º" was
    then cut by the sentence splitter ("o 8." + "º escalão"). The degree sign '°' is NOT treated as an ordinal.
    Token scan (no regex)."""
    out = []
    for w in text.split():
        lead, core, trail = _split_edges(w)
        head, hyphen, rest = core.partition("-")          # "1.º-ministro": the ordinal heads a compound
        mark = head[-1:] if head else ""
        if mark in _ORDINAL_MARKS:
            digits = head[:-1]
            if digits.endswith("."):
                digits = digits[:-1]
            if digits.isdigit():
                out.append(lead + _ordinal_words(int(digits), _ORDINAL_MARKS[mark]) + hyphen + rest + trail)
                continue
        out.append(w)
    return " ".join(out)


# Words that are never the noun a number counts, although MorphoBr files some as nouns (the letters "a", "o", "e";
# "mais", "cerca", "pela"). The lookahead for agreement stops at them.
_NOT_COUNTED = frozenset("""
a à às as o os ao aos e é de da das do dos em na nas no nos num numa um uma uns umas para pra pelo pela pelos pelas por
com sem até mais menos que ou se há tem têm são foi era eram será ser estar cerca entre sobre após desde apenas só quase
já não sim mesmo mesma todos todas cada quanto quantos quantas também ainda muito muitos muitas pouco poucos
este esta estes estas esse essa esses essas aquele aquela aqueles aquelas outro outra outros outras seu sua seus suas
vírgula mil
""".split())

# Nouns that NAME by number instead of counting: "página 2" is "página dois", "século 21" "século vinte e um". A number
# right after one of them is a masculine cardinal, whatever follows it.
_LABEL_NOUNS = frozenset("""
século séculos capítulo capítulos página páginas artigo artigos número alínea fase parte tomo volume livro ato cena
secção título anexo nível classe série lote bloco piso andar porta quarto sala linha ponto figura tabela quadro gráfico
temporada episódio versão modelo tipo grupo escalão item passo etapa jornada ronda opção cenário caso exemplo exercício
pergunta questão regra lei decreto norma via estrada lugar posição dia hora canal faixa
""".split())

# Before a number with no counted noun, these mean the hours: "às 2" -> "às duas", "das 2 às 3", "à 1 e meia".
_HOUR_WORDS = frozenset({"à", "às", "as", "das", "pelas"})


def _bare(w: str) -> str:
    return _split_edges(w)[1].lower()


_RANGE_WORDS = frozenset({"a", "e", "ou", "até"})


def _is_number(w: str) -> bool:
    from tugaphone.number_utils import NumberParser
    w = _split_edges(w)[1]
    return any(c.isdigit() for c in w) and (NumberParser.is_int(w) or NumberParser.is_float(w))


def _counted_gender(words: list[str], idx: int) -> str:
    """"M" or "F" for the number at words[idx]: agreement with the noun it counts, read off the text."""
    prev = _bare(words[idx - 1]) if idx > 0 else ""
    if prev == "vírgula" or prev in _LABEL_NOUNS:     # decimal digits; a label ("página 2")
        return _gender.MASC
    j = idx + 1
    while j < len(words):
        w = _bare(words[j])
        if w == "vírgula":                                  # "2,5 horas": the integer part agrees with "horas"
            j += 2
        elif w == "mil":                                    # "200 mil pessoas" -> "duzentas mil pessoas"
            j += 1
        elif (w in _RANGE_WORDS or words[j] == ",") and j + 1 < len(words) and _is_number(words[j + 1]):
            j += 2                                          # "2 a 3 semanas", "2, 3 ou 4 casas": the noun after all
        else:
            break
    if j < len(words):
        nxt = _bare(words[j])
        if nxt in ("das", "delas"):                     # "1 das casas" -> "uma das casas"
            return _gender.FEM
        if nxt in ("dos", "deles"):
            return _gender.MASC
        # Walk the noun phrase: the first word with a gender of its own decides, noun or adjective ("2 grandes e
        # bonitas casas": "grandes" has one form for both, "bonitas" is feminine). Words with no gender (common-gender
        # nouns, "grande"-type adjectives) and an "e" between adjectives are passed over; anything that is neither a
        # noun nor an adjective (a verb, a function word, a number) ends the phrase.
        k = j
        while k < len(words) and k - j < 6:
            w = _bare(words[k])
            if k > j and (w == "e" or words[k] == ","):     # "grandes e bonitas", "grandes , novas" (marks detached)
                k += 1
                continue
            if w in _NOT_COUNTED or not w.isalpha():
                break
            ng, ag = _gender.noun_gender(w), _gender.adjective_gender(w)
            for g in (ng, ag):
                if g in (_gender.MASC, _gender.FEM):
                    return g
            if ng is None and ag is None:
                break
            k += 1
    if prev in _HOUR_WORDS:
        return _gender.FEM
    return _gender.MASC


def _spell_number(word: str, gender: str) -> str:
    from tugaphone.number_utils import NumberParser
    return NumberParser.pronounce_number_word(word, gender="feminine" if gender == _gender.FEM else "masculine",
                                              is_brazilian=False)


def _spell_numbers(text: str) -> str:
    """Every number token -> pt-PT words, with the gender the counted noun asks for (see gender.py). This replaces
    tugaphone.number_utils.normalize_numbers, whose suffix-guess read "2 vezes" as "dois vezes" and, after "a"/"da",
    "a 2 quilómetros" as "a duas quilómetros"; its spelling engine is still the one used."""
    words = text.split()
    out = []
    for i, w in enumerate(words):
        if not _is_number(w):
            out.append(w)
            continue
        try:
            out.append(_spell_number(w, _counted_gender(words, i)))
        except Exception:
            out.append(w)
    return " ".join(out)


def _agree_with_acronyms(text: str) -> str:
    """A number before an acronym takes the acronym's gender: "2 SMS" -> "duas SMS", "21 PMEs" -> "vinte e uma PMEs".
    Runs at the TEXT level, before _spell_acronyms turns the acronym into letter names whose gender means nothing."""
    words = text.split()
    out = []
    for i, w in enumerate(words):
        lead, core, trail = _split_edges(w)
        if not trail and core.lstrip("-").isdigit() and i + 1 < len(words):
            g = _gender.acronym_gender(_split_edges(words[i + 1])[1])
            if g is not None:
                out.append(lead + _drop_tens_units_e(_spell_number(core, g)))
                continue
        out.append(w)
    return " ".join(out)


def normalize_numbers(text: str) -> str:
    """Expand digits to words. TugaPhone does NOT do this inside phonemize_sentence --
    raw digits pass straight through and would reach the tokenizer. Uses long scale for
    pt-PT and gender agreement from a noun lexicon. Expands ordinals (8.º -> oitavo), numeric
    ranges (1139-1185 -> "... a ...") and drops the tens+units "e" for natural pt-PT (25 -> "vinte cinco")."""
    text = _expand_ordinals(text)
    return _reattach_marks(_drop_tens_units_e(_spell_numbers(_detach_marks(_split_number_ranges(text)))))


# tugaphone writes a NASAL SCHWA (ɨ̃) for pretonic "en/em" in many words - pensou pɨ̃ˈso, sentindo sɨ̃ˈtĩdu,
# lembrou, mendigos, aventuras, compreendi - where pt-PT has ẽ (pẽˈso). Standard pt-PT has no nasal schwa; all 110
# distinct tokens carrying it in the training transcripts are this error. A native listener heard "pensou" as
# "pzou" (2026-10-24): the reduced vowel is dropped. Mapped to ẽ, which the voice knows from thousands of
# correctly transcribed words.
FIX_NASAL_SCHWA = True    # approved by the native listener, 2026-10-24
_NASAL_SCHWA = "ɨ\u0303"
_NASAL_E = "e\u0303"


# Two pt-PT phonological rules tugaphone applies in its dictionary words but not in its rule fallback (found by
# scripts/validate_frontend.py, 2026-10-25: the lemma is right, the inflected form wrong):
#   * a syllable-final s before a voiced consonant is voiced: "desmaiava" dɨʒmɐˈjavɐ, "transmitida", "rosnando";
#   * after a nasal vowel (written n/m + r) r is the strong ʁ: "honras" ˈõʁɐʃ, "enrolando" ẽʁuˈlɐ̃du.
_VOICED_CONSONANTS = set("bdɡvzʒmnɲlʎɾʁ")
_NASAL_TILDE = "\u0303"


_STRESS = "ˈ"


def _voicing_and_strong_r(ps: str) -> str:
    out = list(ps)
    for i, c in enumerate(out):
        j = i + 1
        while j < len(out) and out[j] in ("ˈ", "ˌ"):
            j += 1
        nxt = out[j] if j < len(out) else ""
        if c == "ʃ" and nxt in _VOICED_CONSONANTS:
            out[i] = "ʒ"
        elif c == "ɾ" and i > 0 and (out[i - 1] == _NASAL_TILDE or (i > 1 and out[i - 1] in "ˈˌ" and out[i - 2] == _NASAL_TILDE)):
            out[i] = "ʁ"
    return "".join(out)


def _penult_stress_emos(ps: str) -> str:
    """tugaphone put the stress of some of these paroxytones on the LAST syllable: "queremos" kɨɾeˈmuʃ, "esquecemos",
    "pequenos" pɨkeˈnuʃ. In the closed e / closed a endings (-emos, -enos, -ena, -amos, -ano...) the stress is on that
    vowel: move the mark before the consonant that opens its syllable (kɨˈɾemuʃ, pɨˈkenuʃ). Only when the word's only
    stress mark sits between that vowel and the final syllable."""
    words = []
    for w in ps.split(" "):
        core = w.rstrip(".,;:!?…\"()“”—")
        tail = w[len(core):]
        for fin in ("uʃ", "ɐʃ", "uz", "ɐz", "uʒ", "ɐʒ", "u", "ɐ"):
            if not core.endswith(fin):
                continue
            head = core[:-len(fin)]                         # ...V ˈ C
            if len(head) >= 4 and head[-1] in "mnɲ" and head[-2] == "ˈ" and head[-3] in "eɐ" \
                    and head.count("ˈ") == 1 and head[-4] not in "aɐeɛiɨoɔuˈ":
                core = head[:-4] + "ˈ" + head[-4] + head[-3] + head[-1] + fin
            break
        words.append(core + tail)
    return " ".join(words)


def _clean(ps: str) -> str:
    """Strip syllable separators, decompose precomposed nasals, apply the symbol map."""
    ps = ps.replace(SYLLABLE_SEP, "")
    # TugaPhone emits BOTH precomposed (ẽ) and decomposed (ɐ + U+0303) nasals.
    # NFD makes it uniform, and the combining tilde is vocab id 17.
    ps = unicodedata.normalize("NFD", ps)
    for src, dst in SYMBOL_MAP.items():
        ps = ps.replace(src, dst)
    if "$$" in ps:                                         # a dictionary entry with two pronunciations: keep one
        words = []
        for w in ps.split(" "):
            if "$$" in w:
                w = w.split("$$")[0]
                first = w.find(_STRESS)
                w = w[:first + 1] + w[first + 1:].replace(_STRESS, "") if first >= 0 else w
            words.append(w)
        ps = " ".join(words)
    if FIX_NASAL_SCHWA:
        ps = ps.replace(_NASAL_SCHWA, _NASAL_E)
    ps = _voicing_and_strong_r(_penult_stress_emos(ps))          # after NFD, so the tilde is the separate U+0303
    return " ".join(ps.split())


def _strip_ordinal_marks(text: str) -> str:
    """Remove masculine/feminine ordinal indicators (3.º, 2.ª).

    TugaPhone's number parser raises decimal.InvalidOperation on these, so they are
    stripped as a fallback. Plain string replacement, no pattern matching.
    """
    for mark in ("º", "ª", "°"):
        text = text.replace("." + mark, "").replace(mark, "")
    return text


# Loanword override: English-pronounced borrowings ("online", "site", "email") that
# TugaPhone would lusophonize. Phonemes generated OFFLINE with espeak (GPL at prep time);
# only the phoneme dict ships. Curated to lowercase common nouns -- proper nouns and
# acronyms are excluded (Portuguese does not use their English pronunciation).
_LOANWORDS = None


def _loanwords() -> dict:
    global _LOANWORDS
    if _LOANWORDS is None:
        try:
            _LOANWORDS = json.loads((_ASSETS / "loanwords.json").read_text())
        except Exception:
            _LOANWORDS = {}
    return _LOANWORDS


def _loan_key(w: str) -> str:
    return w.strip(".,!?;:—…\"'()“”").lower()


# The letter x has four sounds in Portuguese (ʃ, ks, z, s) and tugaphone gets it right for the words it knows but
# falls back to ʃ for inflected forms (measured 2026-10-24): "existe" ɐˈʃiʃtɨ (heard "AX..."), "fixas" ˈfiʃɐʃ (heard
# "fichas"), "máximos" ˈmaʃimuʃ, while "existir", "fixa", "máximo" are right. Fixed by RESPELLING the word before
# tugaphone sees it, so its phrase-level processing is untouched:
#   * word-initial ex + vowel is always z in Portuguese: "existe" -> "iziste" (unstressed e is i), "êxito" keeps ê;
#   * a plural sounds like its singular: try x -> ks / ss / z / ch on the singular, keep the spelling that reproduces
#     the singular's own phonemes, apply it to the plural ("fixas" -> "fiksas", "máximos" -> "mássimos");
#   * forms of fixar/fixo take ks ("fixou", "fixam"), except the slang "fixe" (ˈfiʃ).
_VOWEL_LETTERS = set("aeiouáéíóúâêôãõà")
_X_SPELLINGS = ("ch", "ks", "ss", "z")    # ch first: if ʃ reproduces the singular the word is left alone ("peixe")
_x_cache: dict = {}


def _x_respelling_for(singular: str, lect: str) -> Optional[str]:
    if singular.count("x") != 1:
        return None
    key = (singular, lect)
    if key not in _x_cache:
        target = _clean(_get().phonemize_sentence(singular, lect))
        _x_cache[key] = next((r for r in _X_SPELLINGS
                              if _clean(_get().phonemize_sentence(singular.replace("x", r), lect)) == target), None)
    return _x_cache[key]


# A stressed a before m / n / nh is CLOSED (ɐ) in pt-PT unless written á: "vamos" ˈvɐmuʃ, "chegamos" (present)
# ʃɨˈɡɐmuʃ, but "chegámos" (past) ʃɨˈɡamuʃ. tugaphone gets it right in its dictionary ("cama") and gives open a in
# forms it lacks ("vamos", "estamos", "chamo", "ramos"), so present and past of every -ar verb sounded the same
# (found 2026-10-25, user report on "Chegámos"). Respelled with â, which tugaphone reads as ɐ, on words stressed on
# that a (no written accent, so stress is on the penultimate syllable).
_CLOSED_A_ENDINGS = ("amos", "amo", "amas", "ama", "anos", "ano", "anas", "ana", "anhos", "anho", "anhas", "anha")
_ACCENTED = set("áéíóúâêôãõàÁÉÍÓÚÂÊÔÃÕÀ")
# The same for e: stressed e before m / n is closed (e) unless written é; tugaphone gave open ɛ in forms it lacks
# ("comemos" kuˈmɛmuʃ, "temos", "podemos", "fazemos"). Not -enho: Lisbon "tenho" is ˈtɐɲu.
_CLOSED_E_ENDINGS = ("emos", "emo", "emas", "ema", "enos", "eno", "enas", "ena")


_DICTIONARY: Optional[set] = None


def _in_dictionary(word: str) -> bool:
    """Is the word in tugalex, tugaphone's pronunciation dictionary? Its entries are right; only words it lacks go
    through tugaphone's rule fallback, which is where these vowel errors come from. Respelling a dictionary word would
    push it into that fallback ("oceano" ɔˈsjɐnu -> usɨˈɐnu, measured 2026-10-25), so dictionary words are left alone."""
    global _DICTIONARY
    if _DICTIONARY is None:
        from tugalex import TugaLexicon
        _DICTIONARY = set(TugaLexicon().get_wordlist())
    return word.lower() in _DICTIONARY


def _respell_closed_a(w: str) -> str:
    low = w.lower()
    if any(c in _ACCENTED for c in w) or len(low) < 3 or _in_dictionary(low):
        return w
    for end in _CLOSED_A_ENDINGS:
        if low.endswith(end):
            k = len(w) - len(end)
            return w[:k] + ("â" if w[k] == "a" else "Â") + w[k + 1:]
    for end in _CLOSED_E_ENDINGS:
        if low.endswith(end):
            k = len(w) - len(end)
            return w[:k] + ("ê" if w[k] == "e" else "Ê") + w[k + 1:]
    return w


def _respell_x_word(w: str, lect: str) -> str:
    w = _respell_closed_a(w)
    low = w.lower()
    if low.startswith("trans") and len(low) > 5 and low[5] in _VOWEL_LETTERS:
        w, low = w[:4] + "z" + w[5:], low[:4] + "z" + low[5:]   # "transitarmos": s between n and a vowel is z
    if "x" not in low:
        return w
    if low[:2] == "ex" and len(low) > 2 and low[2] in _VOWEL_LETTERS:
        return ("iz" if w[0].islower() else "Iz") + w[2:]
    for prefix in ("coex", "reex", "preex"):                  # "coexistir", "reexaminar": ex+vowel after a prefix
        if low.startswith(prefix) and len(low) > len(prefix) and low[len(prefix)] in _VOWEL_LETTERS:
            k = len(prefix) - 2
            return w[:k] + "ez" + w[k + 2:]

    if low[:2] in ("êx", "éx") and len(low) > 2 and low[2] in _VOWEL_LETTERS:
        return w[0] + "z" + w[2:]
    if low.startswith("fix") and low not in ("fixe", "fixes"):
        return w[:2] + "ks" + w[3:]
    if low.endswith("s") and len(low) > 3:
        # the singular: drop the s ("fixas" -> "fixa"); only for -es plurals whose -s singular fails, drop "es"
        # ("fluxes"). Stop at the first singular that resolves: a final z sounds ʃ, so "tax" would falsely match "taz".
        candidates = [low[:-1]] + ([low[:-2]] if low.endswith("es") else [])
        for singular in candidates:
            r = _x_respelling_for(singular, lect)
            if r is not None:
                return w if r == "ch" else w.replace("x", r, 1).replace("X", r.upper(), 1)
    return w


# tugalex (tugaphone's dictionary) stores two pronunciations for three homographs, joined by its internal "$$", and
# tugaphone passes both through: "a bordo" -> ɐ ˈbɔɾˈdu$$boɾdu, so the voice said "bordo" TWICE (the $ are dropped by
# the tokenizer). All 318,888 entries were scanned (2026-10-24); these are the only three. Respelled with an accent to
# pick one: the noun "a bordo" (closed o), the verb "desbordo" (open o).
_HOMOGRAPH_RESPELLINGS = {"bordo": "bôrdo", "bordos": "bôrdos", "contrabordo": "contrabôrdo", "desbordo": "desbórdo"}


def _respell_x(text: str, lect: str) -> str:
    out = []
    for tok in text.split():
        lead, core, trail = _split_edges(tok)
        if not core.isalpha():
            out.append(tok)
            continue
        homograph = _HOMOGRAPH_RESPELLINGS.get(core.lower())
        if homograph:
            core = homograph if core.islower() else homograph.capitalize()
        out.append(lead + _respell_x_word(core, lect) + trail)
    return " ".join(out)


def _phon_one(text: str, lect: str) -> str:
    text = _respell_x(text, lect)
    try:
        return _clean(_get().phonemize_sentence(normalize_numbers(text), lect))
    except Exception:
        # ordinals (3.º) crash tugaphone's number parser; retry without the markers
        t = _strip_ordinal_marks(text)
        return _clean(_get().phonemize_sentence(normalize_numbers(t), lect))


# Acronyms spoken as Portuguese LETTER NAMES, not read as a syllable. "IA" (inteligência
# artificial) must sound "i á", not "ia"; "LLM" must sound "éle-éle-éme", not "lãm".
# The letter names are written with accents so TugaPhone gives the open-e spelling form
# (L = ˈɛlɨ, not the pronoun "ele" ˈel). The trailing comma injects a pause so the last
# letter does not merge into the next word. Expanded at the TEXT level (see phonemize) so
# the comma becomes a real KEEP_PUNCT pause token.
_ACRONYMS = {
    "IA": "i á,", "LLM": "éle éle éme,", "UTC": "u tê cê,",
    # The project's own name. Left raw, TugaPhone returns vowel-less clusters that
    # Portuguese phonotactics cannot realise -- "tts" -> ˈttʃ and "pt" -> ˈpt -- and the
    # decoder emits noise rather than speech. Confirmed by ear on 0.1.0.
    "tts_eu_pt": "tê tê ésse eu pê tê,",
    "tts-eu-pt": "tê tê ésse eu pê tê,",
    "TTS": "tê tê ésse,", "tts": "tê tê ésse,",
    "PT": "pê tê,",
    # NOTE: keys are matched case-SENSITIVELY on purpose. Lowercase "eu" is the pronoun
    # ("eu vou") and lowercase "ia" is a verb form ("ele ia"); mapping those to letter
    # names would corrupt ordinary text. Only add a lowercase key when the token is not
    # also a real Portuguese word -- "tts" qualifies, "eu" does not.
}

# Abbreviations expanded to full words at the TEXT level (before punctuation splitting,
# so the trailing "." is consumed here instead of becoming a sentence pause and the letter
# is not read on its own). "D." is the Portuguese honorific: "D. Afonso Henriques" ->
# "Dom Afonso Henriques", "D. Maria" -> "Dona Maria": _expand_acronyms picks the form from the given name
# (gender.name_gender); "Dom" is only the fallback when no name follows.
_ABBREVIATIONS = {"D.": "Dom", "n.º": "número", "N.º": "Número", "nº": "número", "Nº": "Número",
                  # titles (found by the corpus diff, 2026-10-25: "o Celeste Sr. Teodoro" was read "ésse érre")
                  "Sr.": "Senhor", "Sra.": "Senhora", "Srs.": "Senhores", "Sras.": "Senhoras", "Dr.": "Doutor",
                  "Dra.": "Doutora", "Eng.": "Engenheiro", "Eng.ª": "Engenheira", "Prof.": "Professor",
                  "Prof.ª": "Professora", "Exmo.": "Excelentíssimo", "Exma.": "Excelentíssima", "Sr.ª": "Senhora"}


_LEAD_PUNCT = '(“"‘¿¡\''
_TRAIL_PUNCT = '.,;:!?)"”…\''


def _split_edges(w: str) -> tuple[str, str, str]:
    """Return (leading punctuation, core, trailing punctuation) of a token."""
    i, j = 0, len(w)
    while i < j and w[i] in _LEAD_PUNCT:
        i += 1
    while j > i and w[j - 1] in _TRAIL_PUNCT:
        j -= 1
    return w[:i], w[i:j], w[j:]


def _expand_acronyms(text: str) -> str:
    words = text.split()
    out = []
    for i, w in enumerate(words):
        # Honorific abbreviations key on the EXACT token — the trailing '.' is PART of "D."
        # (it's what distinguishes it from a lone "D"), so it must not be stripped.
        if w == "D.":                          # Dom / Dona, by the given name that follows ("D. Maria" -> "Dona Maria")
            name = _split_edges(words[i + 1])[1] if i + 1 < len(words) else ""
            is_name = name[:1].isupper() and name.isalpha()
            out.append("Dona" if is_name and _gender.name_gender(name) == _gender.FEM else "Dom")
            continue
        if w in _ABBREVIATIONS:
            out.append(_ABBREVIATIONS[w])
            continue
        # Acronyms (IA, LLM, UTC) may carry surrounding punctuation ("UTC.", "(UTC)"):
        # strip it for the lookup and reattach, so they still expand at a sentence end.
        lead, core, trail = _split_edges(w)
        if core in _ABBREVIATIONS and not core.endswith("."):   # "n.º," / "(nº": the mark is not part of the key
            out.append(lead + _ABBREVIATIONS[core] + trail)
            continue
        repl = _ACRONYMS.get(core)
        if repl is not None:
            if trail and repl.endswith(","):
                repl = repl[:-1]   # the real punctuation already supplies the pause
            out.append(lead + repl + trail)
            continue
        out.append(w)
    return " ".join(out)


# Roman numerals, read the pt-PT way:
#   after a monarch's or pope's name: ordinal up to ten, gendered by the name ("D. Afonso I" -> "Primeiro",
#     "D. Maria II" -> "Segunda"), cardinal above ten ("Luís XIV" -> "catorze", "João XXIII" -> "vinte e três");
#   after a naming noun (século, capítulo, ...): cardinal ("século XIX" -> "dezanove");
#   before a noun: an ordinal that agrees with it ("II Guerra Mundial" -> "segunda Guerra Mundial").
# Only I, V and X (1-39) are read as numerals, so CD, CV, LX, MD and XL stay acronyms.
_ROMAN = {"I": 1, "V": 5, "X": 10}


def _roman_value(s: str) -> int | None:
    if not s or any(c not in _ROMAN for c in s):
        return None
    total = 0
    for k, c in enumerate(s):
        v = _ROMAN[c]
        total += -v if k + 1 < len(s) and _ROMAN[s[k + 1]] > v else v
    canon = "X" * (total // 10) + ["", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX"][total % 10]
    return total if 0 < total < 40 and canon == s else None      # only canonical forms ("IIII" is not 4)


def _split_trailing_punct(w: str) -> tuple[str, str]:
    """Split a token into (core, trailing punctuation), e.g. 'I.' -> ('I', '.')."""
    i = len(w)
    while i > 0 and w[i - 1] in '.,;:!?)"“”':
        i -= 1
    return w[:i], w[i:]


def _cardinal(n: int, gender: str = "M") -> str:
    return _drop_tens_units_e(_spell_number(str(n), gender))


def _expand_regnal_numerals(text: str) -> str:
    words = text.split()
    out = []
    for i, w in enumerate(words):
        core, trail = _split_trailing_punct(w)
        n = _roman_value(core)
        if n is None:
            out.append(w)
            continue
        prev, prev_trail = _split_trailing_punct(words[i - 1]) if i > 0 else ("", "")
        nxt = _split_edges(words[i + 1])[1] if i + 1 < len(words) else ""
        if prev.lower() in _LABEL_NOUNS:                                        # "século XIX", "capítulo V"
            out.append(_cardinal(n) + trail)
            continue
        # A monarch's name: capitalised, right before the numeral (no punctuation between: "Luís XIV, II Guerra"),
        # and not itself a numeral.
        if prev.isalpha() and prev[:1].isupper() and len(prev) > 1 and not prev_trail \
                and prev.lower() not in _NOT_COUNTED and _roman_value(prev) is None:
            if n <= 10:                                                         # "D. Maria II" -> "Segunda"
                words_ = _ordinal_words(n, _gender.name_gender(prev) == _gender.FEM)
                out.append(words_[:1].upper() + words_[1:] + trail)
            else:                                                               # "Luís XIV" -> "catorze"
                out.append(_cardinal(n) + trail)
            continue
        # The next token must be a real word: a single letter ("A X N", "H O S P I T A L") means letters are being spelled.
        g = _gender.noun_gender(nxt) if len(nxt) > 1 and nxt.lower() not in _NOT_COUNTED else None
        if g is not None and (len(core) >= 2 or nxt[:1].isupper()):            # "II Guerra Mundial"
            out.append(_ordinal_words(n, g == _gender.FEM) + trail)
            continue
        out.append((_cardinal(n) if len(core) >= 2 else core) + trail)          # a lone "I"/"V"/"X" stays a letter
    return " ".join(out)


# Clock times: whole hours ("16:00") are read "<hora> horas", NOT "... e zero"; others "<hora> e <minutos>". "hora"
# is feminine, so 1/2 (and 21/22) take feminine forms; every other hour has no gender issue and is left as digits
# for the number expander. Hours are 0-23.
_FEM_HOURS = {1: "uma", 2: "duas", 21: "vinte e uma", 22: "vinte e duas"}


def _expand_clock_times(text: str) -> str:
    """"16:00" -> "16 horas", "1:00" -> "uma hora", "1:30" -> "uma e 30", "16:54" -> "16 e 54". A token the scan
    cannot read as HH:MM (e.g. "(16:54") is left for _split_time_colons. Token scan (no regex), so it must run BEFORE
    _split_time_colons turns the colon into " e "."""
    out = []
    for tok in text.split():
        core, trail = _split_trailing_punct(tok)
        if core.endswith("h") and ":" in core and core[:-1].replace(":", "").isdigit():
            core = core[:-1]                   # "06:00h", "17:30h": the h repeats what the colon says
        hh_s, sep, mm_s = core.partition(":")
        if sep and hh_s.isdigit() and mm_s.isdigit() and len(mm_s) == 2 and 0 <= int(hh_s) <= 23 \
                and int(mm_s) <= 59:
            hh = int(hh_s)
            hour = _FEM_HOURS.get(hh, hh_s)   # feminine word ("hora"), else digits (expanded later)
            if mm_s == "00":
                out.append(f"{hour} {'hora' if hh == 1 else 'horas'}{trail}")
            else:                             # "1:30" -> "uma e 30", not "um e trinta"
                out.append(f"{hour} e {int(mm_s)}{trail}")
        else:
            out.append(tok)
    return " ".join(out)


def _split_time_colons(text: str) -> str:
    """A colon BETWEEN two digits is a clock time, read with "e": "16:54" ->
    "dezasseis e cinquenta e quatro". The colon is a KEEP_PUNCT token, so left alone it
    splits into a pause; this runs at the TEXT level before that split. Char-scan (no
    regex): only a colon flanked by digits is touched, so "Nota:", "são:" keep their pause."""
    n = len(text)
    out = []
    for i, ch in enumerate(text):
        if ch == ":" and 0 < i < n - 1 and text[i - 1].isdigit() and text[i + 1].isdigit():
            out.append(" e ")
        else:
            out.append(ch)
    return "".join(out)


def _normalize_separator_dashes(text: str) -> str:
    """A SPACED en/em-dash or hyphen used as a separator (" – ", " — ", " - ") becomes a
    comma pause, so "Henriques – Primeiro rei" doesn't run together (and isn't misheard as
    a regnal "Henriques Primeiro"). Number ranges ("1139-1185") have no surrounding spaces
    and are left for _split_number_ranges. Literal string replace, no regex."""
    for d in (" – ", " — ", " - "):
        text = text.replace(d, ", ")
    return text


def _normalize_number_separators(text: str) -> str:
    """European number formatting, handled BEFORE the '.'/',' splitter would break it:
    "." groups thousands and is dropped (92.073 -> 92073 -> "noventa e dois mil e setenta e
    três"); "," is the decimal mark, spoken "vírgula" (10,4 -> "dez vírgula quatro").
    Char-scan (no regex): only a separator BETWEEN two digits is touched, so sentence-final
    periods and list commas keep their pause."""
    n = len(text)
    out = []
    for i, ch in enumerate(text):
        between = 0 < i < n - 1 and text[i - 1].isdigit() and text[i + 1].isdigit()
        if between and ch == ".":
            # thousands only when EXACTLY three digits follow ("92.073", "1.234.567"); otherwise a version or an
            # English decimal, read "ponto": "2.0" was dropped to "20" ("DC2.0" -> "DC20"), found by the validator
            k = i + 1
            while k < n and text[k].isdigit():
                k += 1
            if k - (i + 1) == 3:
                continue                   # thousands separator -> drop
            out.append(" ponto ")
            continue
        if between and ch == ",":
            out.append(" vírgula ")        # decimal mark -> spoken word
            continue
        out.append(ch)
    return "".join(out)


# Any other acronym - a token of 2 to 6 capital letters (IMT, IRS, LTV, HPP, TAEG, CRC) - is SPELLED with the letter
# names below: Portuguese readers spell such tokens, and read raw they came out as a syllable ("IMT" -> ĩt) or as an
# unpronounceable cluster ("LTV" -> ltv, which the decoder renders as noise). Measured in the movies' narration,
# 2026-10-24. Runs after the regnal numerals (so "D. João VI" stays "Sexto"); _ACRONYMS above keeps its special forms.
_LETTER_NAMES = {"A": "á", "B": "bê", "C": "cê", "D": "dê", "E": "é", "F": "éfe", "G": "gê", "H": "agá", "I": "i",
                 "J": "jota", "K": "capa", "L": "éle", "M": "éme", "N": "éne", "O": "ó", "P": "pê", "Q": "quê", "R": "érre",
                 "S": "ésse", "T": "tê", "U": "u", "V": "vê", "W": "dâblio", "X": "xis", "Y": "ípsilon", "Z": "zê"}
# Capital-letter words that are read as words, not spelled (extend when one comes up: ONU, NATO, ...).
_READ_AS_WORDS = frozenset({"ONU", "NATO", "UNESCO", "OTAN", "SIDA"})


def _letter_run(words: list, i: int) -> bool:
    """Is words[i] a single capital letter inside a run of >= 2 of them ("A X N", "H O S P I T A L", "P S P")?"""
    def single(k):
        return 0 <= k < len(words) and len(_split_edges(words[k])[1]) == 1 and _split_edges(words[k])[1] in _LETTER_NAMES
    return single(i) and (single(i - 1) or single(i + 1))


def _spell_acronyms(text: str) -> str:
    out = []
    words = text.split()
    for i, w in enumerate(words):
        lead, core, trail = _split_edges(w)
        if "-" in core and not core.startswith("-") and all(core.split("-")):
            # a hyphenated identifier ("cj-transfers-be"): spell its vowel-less or all-capital parts
            parts = core.split("-")
            fixed = [" ".join(_LETTER_NAMES[c.upper()] for c in x)
                     if x.isalpha() and len(x) <= 6 and all(c.upper() in _LETTER_NAMES for c in x)
                     and (not any(c in "aeiouyáéíóúâêôãõàAEIOUY" for c in x) or (x.isupper() and len(x) > 1))
                     and x not in _READ_AS_WORDS else x for x in parts]
            if fixed != parts:
                out.append(lead + " ".join(fixed) + trail)
                continue
        if _letter_run(words, i):                       # spelled letters: every letter by name, vowels too
            out.append(lead + _LETTER_NAMES[core] + trail)
            continue
        for apostrophe in ("'s", "’s"):                 # "FIN's": an acronym with an English possessive/plural 's
            if core.endswith(apostrophe) and len(core) > 3 and core[:-2].isupper():
                core = core[:-2] + "s"
        if len(core) >= 3 and core.endswith("s") and core[:-1].isupper() and core[:-1].isalpha() \
                and core[:-1] not in _READ_AS_WORDS and all(c in _LETTER_NAMES for c in core[:-1]):
            # A plural acronym ("PMEs", "ONGs"): the letters, with the plural s on the last one ("pê éme és").
            spelled = " ".join(_LETTER_NAMES[c] for c in core[:-1]) + "s"
            out.append(lead + spelled + (trail if trail else ","))
            continue
        no_vowel = core.isalpha() and 2 <= len(core) <= 6 and not any(c in "aeiouyáéíóúâêôãõàAEIOUY" for c in core)
        if len(core) == 1 and core in _LETTER_NAMES and core not in "AEOÉ" and core.isupper():
            out.append(lead + _LETTER_NAMES[core] + trail)     # a lone capital consonant ("P S P", "participant C")
            continue
        if no_vowel and all(c.upper() in _LETTER_NAMES for c in core):
            core = core.upper()                                # "npm", "cj", "csv", "sql": no Portuguese word lacks a vowel
        if 2 <= len(core) <= 6 and core.isalpha() and core.isupper() and core not in _READ_AS_WORDS \
                and all(c in _LETTER_NAMES for c in core):
            spelled = " ".join(_LETTER_NAMES[c] for c in core)
            out.append(lead + spelled + (trail if trail else ","))   # the comma: the last letter does not merge into the next word
            continue
        out.append(w)
    return " ".join(out)


def _expand_percent(text: str) -> str:
    """"3,5%" / "12 %" -> "3,5 por cento": a percent sign glued to its number kept the number from being expanded (its
    digits were dropped: "a taxa é de 3,5%" was read "três vírgula", measured 2026-10-24). Char-level: every '%' becomes
    " por cento" (and '‰' " por mil"); the number before it is then a plain number token."""
    return text.replace("%", " por cento").replace("‰", " por mil").replace("  por", " por")


# Unit symbols after a number, read as pt-PT words (singular, plural). Left raw, "kg" phonemized as the vowel-less
# cluster ˈkɡ and "€" was dropped by the tokenizer, so "Custa 5 €." was read "Custa cinco." (measured 2026-10-24).
_UNITS = {
    "km": ("quilómetro", "quilómetros"), "m": ("metro", "metros"), "cm": ("centímetro", "centímetros"),
    "mm": ("milímetro", "milímetros"), "km/h": ("quilómetro por hora", "quilómetros por hora"),
    "m²": ("metro quadrado", "metros quadrados"), "km²": ("quilómetro quadrado", "quilómetros quadrados"),
    "m³": ("metro cúbico", "metros cúbicos"), "ha": ("hectare", "hectares"),
    "kg": ("quilo", "quilos"), "g": ("grama", "gramas"), "mg": ("miligrama", "miligramas"),
    "t": ("tonelada", "toneladas"), "l": ("litro", "litros"), "L": ("litro", "litros"),
    "ml": ("mililitro", "mililitros"), "cl": ("centilitro", "centilitros"), "dl": ("decilitro", "decilitros"),
    "h": ("hora", "horas"), "min": ("minuto", "minutos"), "s": ("segundo", "segundos"),
}
_CURRENCIES = {"€": ("euro", "euros"), "$": ("dólar", "dólares"), "£": ("libra", "libras")}
_SCALE_WORDS = frozenset({"mil", "milhão", "milhões", "bilião", "biliões"})


def _is_raw_number(s: str) -> bool:
    """"5", "2,50", "1.234,5", "-3": digits with European separators, before _normalize_number_separators runs."""
    s = s[1:] if s[:1] in "-+" else s
    return bool(s) and s[0].isdigit() and s[-1].isdigit() and all(c.isdigit() or c in ".," for c in s)


def _amount(num: str, unit: str) -> str:
    """'2,50' + '€' -> '2 euros e 50 cêntimos'; '1' + 'km' -> '1 quilómetro'; '2,5' + 'km' -> '2,5 quilómetros'."""
    if unit in _CURRENCIES:
        sing, plur = _CURRENCIES[unit]
        whole, comma, cents = num.rpartition(",")
        if comma and len(cents) == 2 and whole:
            units_n = int(whole.lstrip("-+").replace(".", "") or 0)
            cents_n = int(cents)
            parts = []
            if units_n:
                parts.append(f"{whole} {sing if units_n == 1 else plur}")
            if cents_n or not units_n:
                parts.append(f"{cents_n} {'cêntimo' if cents_n == 1 else 'cêntimos'}")
            return " e ".join(parts)
    else:
        sing, plur = _UNITS[unit]
        # a half is said as such: "3,5 kg" -> "3 quilos e meio", "0,5 l" -> "meio litro", "1,5 h" -> "1 hora e meia"
        # (native listener, 2026-10-25). ".5" too: one digit after a dot cannot be a thousands group.
        whole, sep, frac = num.rpartition("," if "," in num else ".")
        if sep and frac == "5" and whole.lstrip("-+").isdigit() and " por " not in sing:
            half = "meia" if sing in _FEM_UNITS else "meio"
            if int(whole.lstrip("-+")) == 0:
                return f"{half} {sing}"
            return f"{whole} {sing if whole.lstrip('-+') == '1' else plur} e {half}"
    return f"{num} {sing if num.lstrip('-+') == '1' else plur}"


_FEM_UNITS = frozenset({"hora", "tonelada"})


def _split_number_prefix(core: str) -> tuple[str, str]:
    """'5km' -> ('5', 'km'); '2,50€' -> ('2,50', '€'). ('', core) when core does not start with a number."""
    i = 1 if core[:1] in "-+" else 0
    j = i
    while j < len(core) and (core[j].isdigit() or core[j] in ".,"):
        j += 1
    while j > i and core[j - 1] in ".,":
        j -= 1
    num = core[:j]
    return (num, core[j:]) if _is_raw_number(num) else ("", core)


def _expand_units(text: str) -> str:
    """Units and currencies after (or, for currencies, before) a number: "2 kg" -> "2 quilos", "5€" -> "5 euros",
    "€ 2,50" -> "2 euros e 50 cêntimos", "100 km/h" -> "100 quilómetros por hora". Also the pt-PT clock form
    "16h30" -> "16 e 30" and "9h" -> "9 horas". Only next to a number, so a lone "m" or "g" is untouched.
    Token scan (no regex). Runs before _normalize_number_separators, which still has to see "2,50"."""
    words = text.split()
    out: list[str] = []
    i = 0
    while i < len(words):
        lead, core, trail = _split_edges(words[i])
        num, rest = _split_number_prefix(core)
        if num and (rest in _UNITS or rest in _CURRENCIES):                         # "5km", "5€"
            out.append(lead + _amount(num, rest) + trail)
        elif num and rest[:1] == "h" and (rest == "h" or (len(rest) == 3 and rest[1:].isdigit())) \
                and num.isdigit() and int(num) <= 23:                                 # "16h30", "9h"
            hour = _FEM_HOURS.get(int(num), num)
            whole = rest in ("h", "h00")                                               # "15h00" -> "15 horas"
            out.append(lead + (f"{hour} {'hora' if num == '1' else 'horas'}" if whole
                               else f"{hour} e {int(rest[1:])}") + trail)
        elif core[:1] in _CURRENCIES and _is_raw_number(core[1:]):                    # "€5"
            out.append(lead + _amount(core[1:], core[0]) + trail)
        elif core in _CURRENCIES and not trail and i + 1 < len(words) and not _split_edges(words[i + 1])[0] \
                and _is_raw_number(_split_edges(words[i + 1])[1]):                      # "€ 5"
            _, ncore, ntrail = _split_edges(words[i + 1])
            out.append(lead + _amount(ncore, core) + ntrail)
            i += 2
            continue
        elif (core in _UNITS or core in _CURRENCIES) and not lead and out:           # "5 km", "2,50 €", "300 mil €"
            plead, pcore, ptrail = _split_edges(out[-1])
            if _is_raw_number(pcore) and not ptrail:
                out[-1] = plead + _amount(pcore, core) + trail
            elif core in _CURRENCIES and not ptrail and pcore in _SCALE_WORDS and len(out) >= 2 \
                    and _is_raw_number(_split_edges(out[-2])[1]):
                # "300 mil €" -> "300 mil euros"; "2 milhões €" -> "2 milhões de euros"
                plural = _CURRENCIES[core][1]
                out.append(("de " if pcore != "mil" else "") + plural + trail)
            elif core in _CURRENCIES:                                             # a lone sign: "o €" -> "o euro"
                out.append(_CURRENCIES[core][0] + trail)
            else:
                out.append(words[i])
        elif core in _CURRENCIES:
            out.append(lead + _CURRENCIES[core][0] + trail)
        else:
            out.append(words[i])
        i += 1
    return " ".join(out)


_DEGREE_SCALES = {"C": "Celsius", "F": "Fahrenheit"}


def _expand_degrees(text: str) -> str:
    """"20°" -> "20 graus", "-3 °C" -> "-3 graus Celsius", "1°" -> "1 grau". The degree sign is not in the vocab and,
    glued to its number, kept the number from being expanded, so "Temperatura de 20°." was read "Temperatura de"
    (measured 2026-10-24). Token scan (no regex); a '°' not preceded by a number is left alone."""
    toks = text.split()
    out = []
    for i, w in enumerate(toks):
        lead, core, trail = _split_edges(w)
        num, deg, scale = core.partition("°")
        if deg and not num and out:                     # "20 °C": the sign is its own token, the number before it
            prev = _split_edges(out[-1])[1]
            num_ok = prev.replace(",", "").replace(".", "").lstrip("-").isdigit()
            if num_ok and scale in ("", *_DEGREE_SCALES):
                unit = "grau" if prev == "1" else "graus"
                out.append(lead + " ".join(x for x in (unit, _DEGREE_SCALES.get(scale, "")) if x) + trail)
                continue
        if deg and num.replace(",", "").replace(".", "").lstrip("-").isdigit() and scale in ("", *_DEGREE_SCALES):
            unit = "grau" if num == "1" else "graus"
            out.append(lead + " ".join(x for x in (num, unit, _DEGREE_SCALES.get(scale, "")) if x) + trail)
            continue
        out.append(w)
    return " ".join(out)


_DIGIT_NAMES = ["zero", "um", "dois", "três", "quatro", "cinco", "seis", "sete", "oito", "nove"]
_PHONE_PREFIXES = {"+351": "mais três cinco um,", "00351": "zero zero três cinco um,"}


def _is_phone_start(digits: str) -> bool:
    return len(digits) == 9 and digits[0] in "2389"     # pt-PT: 2 landline, 9 mobile, 3 nomadic, 8 free/shared-cost


def _read_digits(digits: str) -> str:
    """'912345678' -> 'nove um dois, três quatro cinco, seis sete oito' (digit by digit, a pause per group of 3)."""
    return ", ".join(" ".join(_DIGIT_NAMES[int(c)] for c in digits[k:k + 3]) for k in range(0, len(digits), 3))


def _expand_phone_numbers(text: str) -> str:
    """Portuguese phone numbers, read digit by digit in groups: "912 345 678", "912345678", "+351 912 345 678".
    Up to 0.1.4 they were read as amounts ("novecentos e doze milhões...") or as three run-together hundreds.
    A 9-digit number starting with 2, 3, 8 or 9, written whole or as 3+3+3. Token scan (no regex)."""
    words = text.split()
    out, i = [], 0
    while i < len(words):
        lead, core, trail = _split_edges(words[i])
        prefix = ""
        j = i
        if core in _PHONE_PREFIXES and not trail and i + 1 < len(words):
            prefix, j = _PHONE_PREFIXES[core] + " ", i + 1
            lead2, core, trail = _split_edges(words[j])
        digits, last = None, j
        if core.isdigit() and _is_phone_start(core):
            digits = core
        elif core.isdigit() and len(core) == 3 and not trail and j + 2 < len(words):
            c2, c3 = _split_edges(words[j + 1]), _split_edges(words[j + 2])
            if not c2[0] and not c2[2] and not c3[0] and c2[1].isdigit() and c3[1].isdigit() \
                    and len(c2[1]) == 3 and len(c3[1]) == 3 and _is_phone_start(core + c2[1] + c3[1]):
                digits, last, trail = core + c2[1] + c3[1], j + 2, c3[2]
        if digits:
            out.append(lead + prefix + _read_digits(digits) + trail)
            i = last + 1
            continue
        out.append(words[i])
        i += 1
    return " ".join(out)


def _join_spaced_thousands(text: str) -> str:
    """pt-PT's official thousands separator is a space: "1 000", "2 300 000". Up to 0.1.4 the groups were read as
    separate numbers ("um zero"). A 1-3 digit group followed by groups of exactly 3 digits, with no punctuation
    between, is one number. Runs after _expand_phone_numbers, which claims 3+3+3 phone numbers first. Token scan."""
    words = text.split()
    out, i = [], 0
    while i < len(words):
        lead, core, trail = _split_edges(words[i])
        j, joined = i, core
        while (not trail and core.isdigit() and 1 <= len(core) <= 3 and j + 1 < len(words)):
            l2, c2, t2 = _split_edges(words[j + 1])
            if l2 or not (c2.isdigit() and len(c2) == 3):
                break
            joined += c2; trail = t2; j += 1
        if j > i:
            out.append(lead + joined + trail); i = j + 1
            continue
        out.append(words[i]); i += 1
    return " ".join(out)


_MONTHS = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro",
           "novembro", "dezembro"]
_FRACTIONS = {2: ("meio", "meios"), 3: ("terço", "terços"), 4: ("quarto", "quartos"), 5: ("quinto", "quintos"),
              6: ("sexto", "sextos"), 7: ("sétimo", "sétimos"), 8: ("oitavo", "oitavos"), 9: ("nono", "nonos"),
              10: ("décimo", "décimos"), 100: ("centésimo", "centésimos"), 1000: ("milésimo", "milésimos")}
_REFERENCE_NOUNS = frozenset({"lei", "decreto", "decreto-lei", "portaria", "despacho", "processo", "acórdão",
                              "regulamento", "resolução", "diretiva", "circular", "aviso", "norma", "número", "n.º"})


def _fraction(a: int, b: int, next_word: str) -> tuple[str, bool]:
    """'1/2' + 'chávena' -> ('meia', False); '3/4' + 'h' -> ('3 quartos de hora', True: the unit was consumed)."""
    unit = _UNITS.get(next_word)
    noun = unit[0] if unit else next_word.lower()
    g = _gender.noun_gender(noun)
    fem = g == _gender.FEM
    if b == 2 and a == 1:
        word = "meia" if fem else "meio"
        return (f"{word} {unit[0]}", True) if unit else (word, False)
    if b in _FRACTIONS:
        sing, plur = _FRACTIONS[b]
        frac = f"{a} {sing if a == 1 else plur}"
    else:
        frac = f"{a} {b} {'avo' if a == 1 else 'avos'}"
    return (f"{frac} de {unit[0]}", True) if unit else (frac, False)


def _expand_slashes(text: str) -> str:
    """Numbers with slashes, which the model cannot read (no '/' token: up to 0.1.4 the whole token was DROPPED, so
    "a reunião é a 24/10/2026" was read "a reunião é a"). Token scan (no regex):
      24/10/2026 -> "24 de outubro de 2026"; 5/3 -> "5 de março" (a valid day/month, not before a noun);
      1/2 chávena -> "meia chávena"; 3/4 h -> "3 quartos de hora"; 2/3 -> "2 terços" (before a noun or a unit, or not
      a valid date); Lei 2/2020 -> "Lei 2 barra 2020" (after a reference noun). Words with a slash ("e/ou") are left."""
    words = text.split()
    out, i = [], 0
    while i < len(words):
        lead, core, trail = _split_edges(words[i])
        parts = core.split("/")
        if len(parts) not in (2, 3) or not all(x.isdigit() for x in parts):
            out.append(words[i]); i += 1
            continue
        n = [int(x) for x in parts]
        prev = _split_edges(words[i - 1])[1].lower() if i > 0 else ""
        nxt = _split_edges(words[i + 1])[1] if i + 1 < len(words) and not trail else ""
        valid_date = 1 <= n[0] <= 31 and 1 <= n[1] <= 12
        after = _split_edges(words[i + 2])[1] if i + 2 < len(words) else ""
        # a fraction is typically followed by its noun or "do/da" ("2/3 do leite"); a date by nothing or "de <year>"
        before_noun = bool(nxt) and (nxt in _UNITS or nxt.lower() in ("do", "da", "dos", "das")
                                     or (nxt.lower() == "de" and not (after.isdigit() and len(after) == 4))
                                     or (nxt.lower() not in _NOT_COUNTED and _gender.noun_gender(nxt) is not None))
        consumed = False
        if prev in _REFERENCE_NOUNS:
            spoken = " barra ".join(parts)
        elif len(parts) == 3:
            spoken = f"{parts[0]} de {_MONTHS[n[1] - 1]} de {parts[2]}" if valid_date else " barra ".join(parts)
        elif valid_date and not before_noun:
            spoken = f"{parts[0]} de {_MONTHS[n[1] - 1]}"
        elif n[1] >= 2:
            spoken, consumed = _fraction(n[0], n[1], nxt)
        else:
            spoken = " barra ".join(parts)
        if consumed:
            trail = _split_edges(words[i + 1])[2]
            i += 1
        out.append(lead + spoken + trail)
        i += 1
    return " ".join(out)


def _spell_dotted_abbreviations(text: str) -> str:
    """"D.O." / "S.A." / "E.U.A." -> letter names ("dê ó"). Up to 0.1.4 "D.O." hit the honorific rule and was read
    "Dom O.". The final '.' ends the sentence only before a capitalised word or at the end. Token scan (no regex)."""
    words = text.split()
    out = []
    for i, w in enumerate(words):
        lead, rest = "", w
        while rest[:1] in _LEAD_PUNCT and rest:
            lead, rest = lead + rest[0], rest[1:]
        tail = ""
        while rest and rest[-1] in ",;:!?)\"”…":
            tail, rest = rest[-1] + tail, rest[:-1]
        letters = rest[0::2]
        is_abbr = (len(rest) >= 4 and len(rest) % 2 == 0 and rest[1::2] == "." * (len(rest) // 2)
                   and letters.isupper() and all(c in _LETTER_NAMES for c in letters))
        if not is_abbr:
            out.append(w)
            continue
        nxt = words[i + 1] if i + 1 < len(words) else ""
        end = "." if (not nxt or _split_edges(nxt)[1][:1].isupper()) and not tail else ""
        out.append(lead + " ".join(_LETTER_NAMES[c] for c in letters) + (tail or end or ","))
    return " ".join(out)


def _expand_numeric_dates(text: str) -> str:
    """Numeric dates with dots or dashes: "2026.05.07", "2026-05-07", "07-05-2026", "07.05.2026" -> "7 de maio de
    2026". Up to 0.1.6 a dotted date became one 8-digit number and a dashed one a range ("2026 a 05 a 07"). Only three
    numeric parts forming a valid date, with the year (4 digits) first or last. Token scan (no regex)."""
    out = []
    for tok in text.split():
        lead, core, trail = _split_edges(tok)
        for sep in (".", "-"):
            parts = core.split(sep)
            if len(parts) == 3 and all(x.isdigit() for x in parts):
                if len(parts[0]) == 4:
                    y, m, d = parts
                elif len(parts[2]) == 4:
                    d, m, y = parts
                else:
                    continue
                if 1 <= int(d) <= 31 and 1 <= int(m) <= 12:
                    tok = f"{lead}{int(d)} de {_MONTHS[int(m) - 1]} de {y}{trail}"
                    break
        out.append(tok)
    return " ".join(out)


_OPTIONAL_SUFFIXES = ("(s)", "(es)", "(a)", "(as)", "(o)", "(os)")


def _drop_optional_suffixes(text: str) -> str:
    """"Executado(s)" -> "Executados", "caro(a)" -> "caro": a written optional ending cannot be spoken; the plural
    reading keeps the most information. Up to 0.1.6 the "(s)" became a stray ʃ. Token scan (no regex)."""
    out = []
    for tok in text.split():
        for suf in _OPTIONAL_SUFFIXES:
            k = tok.find(suf)
            if k > 0 and tok[k - 1].isalpha():
                tok = tok[:k] + ("s" if suf in ("(s)", "(es)") else "") + tok[k + len(suf):]
                break
        out.append(tok)
    return " ".join(out)


def _split_camel_case(text: str) -> str:
    """"DevOps" -> "Dev Ops", "IdP" -> "Id P", "eSign" -> "e Sign", "OAuth" -> "O Auth": an identifier glued from words
    was read as one word. Splits at lower->upper and at the last capital of a capital run before lowercase. ALL-CAPS
    acronyms and ordinary capitalised words are untouched. Token scan (no regex)."""
    out = []
    for tok in text.split():
        lead, core, trail = _split_edges(tok)
        plural_acronym = len(core) > 2 and core.endswith("s") and core[:-1].isupper()         # "ONGs", "PMEs"
        if plural_acronym or not core.isalpha() or core.isupper() or core.islower() or not any(c.isupper() for c in core[1:]):
            out.append(tok)
            continue
        pieces, cur = [], core[0]
        for k in range(1, len(core)):
            c, prev = core[k], core[k - 1]
            nxt = core[k + 1] if k + 1 < len(core) else ""
            if c.isupper() and (prev.islower() or (nxt and nxt.islower() and prev.isupper())):
                pieces.append(cur); cur = c
            else:
                cur += c
        pieces.append(cur)
        out.append(lead + " ".join(pieces) + trail)
    return " ".join(out)


def _split_dotted_words(text: str) -> str:
    """"Node.js" -> "Node ponto js", "exemplo.csv" -> "exemplo ponto csv": a dot between two letters inside a token
    (file names, domains). Dotted abbreviations ("D.O.", "n.º") are handled earlier. Token scan (no regex)."""
    out = []
    for tok in text.split():
        lead, core, trail = _split_edges(tok)
        if "." in core and core.count(".") <= 3 and all(p and p.isalnum() for p in core.split(".")) \
                and any(len(p) > 1 for p in core.split(".")) and not core.replace(".", "").isdigit() \
                and not all(core[k - 1].isdigit() and core[k + 1].isdigit() for k, c in enumerate(core) if c == "."):
            # a dot between two digits is a number's ("3.5kg", "dc2.0"): the unit and separator steps read it
            core = " ponto ".join(core.split("."))
        out.append(lead + core + trail)
    return " ".join(out)


def _split_letter_digit_tokens(text: str) -> str:
    """"PSD2" -> "PSD 2", "B2C" -> "B 2 C", "canais2" -> "canais 2", "D365" -> "D 365": letters and digits glued in one
    token. The letter parts are then spelled or read as words by the steps after. Token scan (no regex)."""
    out = []
    for tok in text.split():
        lead, core, trail = _split_edges(tok)
        # each hyphen part on its own: "ms-devices-be-v1-blue" must split "v1" in the FIRST pass, or the hyphenated-
        # acronym step frees "v1" and the second pass splits it (non-idempotent, found by the corpus check 2026-10-25)
        # A split part is set apart by spaces, and so is a number joined to a word by "-" or "/" ("1.2.0-ci",
        # "2.0/OpenID"): a digit left glued to the mark is dropped by the phonemizer (measured 2026-10-25).
        pieces, seps, cur = [], [], ""
        for c in core:
            if c in "-/" and cur:
                pieces.append(cur); seps.append(c); cur = ""
            else:
                cur += c
        pieces.append(cur)
        done = [_split_letter_digit_part(p) for p in pieces]
        out_core = done[0]
        for k in range(1, len(done)):
            a, b = pieces[k - 1], pieces[k]
            apart = done[k] != b or done[k - 1] != a or (_is_raw_number(a) != _is_raw_number(b)
                                                       and any(ch.isalpha() for ch in a + b)
                                                       and not (seps[k - 1] == "-" and (a + b).replace(".", "").isupper()))
            # (an upper-case acronym and a number across a HYPHEN, "COVID-19", are read by the acronym step)
            out_core += (" " if apart else seps[k - 1]) + done[k]
        core = out_core
        out.append(lead + core + trail)
    return " ".join(out)


def _split_letter_digit_part(core: str) -> str:
    # a "." or "," between digits belongs to the number ("dc2.0" -> "dc" + "2.0"); the separator step reads it later
    plain = core.replace(".", "").replace(",", "")
    if not (plain.isalnum() and any(c.isdigit() for c in core) and any(c.isalpha() for c in core)
            and not (core[-1:] in "ºª") and core[0].isalnum() and core[-1].isalnum()):
        return core
    if any(core[i] in ".," and not (core[i - 1].isdigit() and core[i + 1].isdigit()) for i in range(1, len(core) - 1)):
        return core                                       # a dot between words ("e.g") is not a number's
    parts, cur = [], core[0]
    for c in core[1:]:
        if c in ".,":
            cur += c
        elif c.isdigit() != (cur[-1].isdigit() or cur[-1] in ".,"):
            parts.append(cur); cur = c
        else:
            cur += c
    parts.append(cur)
    # a single letter or a vowel-less letter group is spelled HERE: left bare beside a number, a later pass
    # read it as a unit ("k8s" -> "k 8 s" -> "8 segundos"), measured by the idempotence check
    spelled = []
    for part in parts:
        if part.isalpha() and (len(part) == 1 or not any(c in "aeiouyáéíóúâêôãõàAEIOUY" for c in part)) \
                and all(c.upper() in _LETTER_NAMES for c in part):
            spelled.append(" ".join(_LETTER_NAMES[c.upper()] for c in part))
        else:
            spelled.append(part)
    return " ".join(spelled)


def normalize_text(text: str) -> str:
    """Text-level normalisation applied BEFORE phonemization or any '.'-based sentence
    splitting: number separators (92.073 / 10,4), separator dashes (" – " -> ", "), acronyms
    (IA -> 'i á'), honorific abbreviations (D. -> Dom / Dona) and Roman numerals (Afonso I ->
    Afonso Primeiro, D. Maria II -> Dona Maria Segunda, século XIX -> século dezanove).
    Idempotent, so it is safe to call more than once (the TTS server calls it before its
    streaming split; phonemize() calls it too)."""
    text = _expand_slashes(_join_spaced_thousands(_expand_phone_numbers(_expand_ordinals(_expand_numeric_dates(text)))))
    text = _split_dotted_words(_drop_optional_suffixes(text))
    return _spell_acronyms(_expand_regnal_numerals(_expand_acronyms(_spell_dotted_abbreviations(_normalize_separator_dashes(
        _agree_with_acronyms(_split_time_colons(_expand_clock_times(_normalize_number_separators(_split_camel_case(_split_dotted_words(_expand_units(_split_letter_digit_tokens(_expand_units(_expand_degrees(_expand_percent(text))))))))))))))))


def _in_prefix_word(w: str) -> bool:
    """"inesquecível", "inesperado", "inexplicável": in- + es/ex + consonant."""
    low = _loan_key(w)
    return len(low) > 5 and low[:2] == "in" and low[2:4] in ("es", "ex") and low[4] not in _VOWEL_LETTERS


def _phon_in_prefix(w: str, lect: str) -> str:
    """tugaphone (and tugalex) read the prefix as "ini": "inesquecível" iniʃkɛˈsivɛl, where pt-PT has inɨʃkɛˈsivɛl
    (Wiktionary, Portugal; the user heard it wrong, 2026-10-25). The rest of the word without "in" is read right
    ("esquecível" ʃkɛˈsivɛl, "explicável" ɐjʃpliˈkavɛl), so: "in" + that, restoring the dropped initial e as ɨ."""
    rest = _phon_one(w[2:], lect)
    return "in" + ("ɨ" + rest if rest[:1] in ("ʃ", "ʒ") else rest)


def _veis_plural(w: str) -> bool:
    low = _loan_key(w)
    return len(low) > 5 and low.endswith("veis") and not _in_dictionary(low)


def _phon_word(w: str, lect: str) -> str:
    """One word through the special cases that need the whole word: -veis plurals, then the in- prefix."""
    if _veis_plural(w):
        # "esquecíveis" was stressed on the last syllable (eʃkɨsiˈvɐjʃ); the native listener confirmed the stress on
        # -cí- (2026-10-25). A -veis plural sounds like its -vel singular with -vɐjʃ: read the singular, swap the end.
        core = _loan_key(w)
        sing = _phon_word(core[:-3] + "el", lect)                   # "esquecíveis" -> "esquecível"
        for end in ("vɛl", "vɛɫ", "vel"):
            if sing.endswith(end):
                return sing[:-len(end)] + "vɐjʃ"
    if _in_prefix_word(w):
        return _phon_in_prefix(w, lect)
    return _phon_one(w, lect)


_SANDHI_VOWELS = set("aɐeɛiɨoɔuəæɒʌɪʊɑɜ")      # incl. the English vowels of loanwords
_SANDHI_VOICED = set("bdɡvzʒmnɲlʎɾʁ")


def _join_with_sandhi(parts: list, english: frozenset = frozenset()) -> str:
    """Words phonemized one by one lose the liaison tugaphone applies across a phrase: a word-final s (ʃ) is z before
    a vowel and ʒ before a voiced consonant ("os itens" uz iˈtẽʃ, "as receitas" ɐʒ ʁɨˈsɐjtɐʃ). Re-applied here, so the
    word-level paths (loanwords, -veis plurals, the in- prefix) keep it (measured on the corpus diff, 2026-10-25)."""
    keep = [(x, i in english) for i, x in enumerate(parts) if x]
    parts = [x for x, _ in keep]
    out = []
    for i, w in enumerate(parts):
        if w.endswith("ʃ") and i + 1 < len(parts) and not keep[i][1]:       # an English loanword keeps its own ending
            nxt = parts[i + 1].lstrip("ˈˌ")
            nxt = unicodedata.normalize("NFD", nxt)[:1]
            if nxt in _SANDHI_VOWELS:
                w = w[:-1] + "z"
            elif nxt in _SANDHI_VOICED:
                w = w[:-1] + "ʒ"
        out.append(w)
    return " ".join(out)


def _raw_phonemize(text: str, lect: str) -> str:
    lw = _loanwords()
    words = text.split()
    if any(_in_prefix_word(w) or _veis_plural(w) for w in words):
        parts = [lw[_loan_key(w)] if _loan_key(w) in lw else _phon_word(w, lect) for w in words]
        return _join_with_sandhi(parts, frozenset(i for i, w in enumerate(words) if _loan_key(w) in lw))
    # Only drop to word-level when a loanword is actually present, so ordinary text
    # keeps TugaPhone's full-phrase quality.
    if lw and any(_loan_key(w) in lw for w in words):
        parts = []
        for w in words:
            k = _loan_key(w)
            parts.append(lw[k] if k in lw else _phon_one(w, lect))
        return _join_with_sandhi(parts, frozenset(i for i, w in enumerate(words) if _loan_key(w) in lw))
    return _phon_one(text, lect)


# Punctuation Kokoro can actually represent (verified against config.json vocab).
KEEP_PUNCT = {c for c in ';:,.!?—…"()“”' if c in VOCAB}


def phonemize(text: str, lect: str = LECT, keep_punct: bool = True) -> str:
    """Text -> European Portuguese IPA, ready for Kokoro's vocab.

    PUNCTUATION: phonemizers drop it, but Kokoro's vocab contains 13 punctuation tokens
    and the model uses them for prosody -- sentence-final pauses, comma breaths,
    intonation resets. Training without them produces flat, run-on delivery.

    So the text is split at punctuation, each span phonemized separately, and the marks
    re-inserted between the spans as real tokens.
    """
    # Normalise first (acronyms -> "i á,", D. -> Dom, Afonso I -> Afonso Primeiro). This
    # may inject punctuation (the "IA" comma), so the split below treats it as a pause.
    text = normalize_text(text)
    if not keep_punct:
        return _raw_phonemize(text, lect)

    out, buf = [], []
    for ch in text:
        if ch in KEEP_PUNCT:
            span = "".join(buf).strip()
            buf = []
            if span:
                ps = _raw_phonemize(span, lect)
                if ps:
                    out.append(ps)
            out.append(ch)          # the punctuation token itself
        else:
            buf.append(ch)
    span = "".join(buf).strip()
    if span:
        ps = _raw_phonemize(span, lect)
        if ps:
            out.append(ps)

    # join so punctuation hugs the preceding phonemes and a space follows, e.g. "dˈiɐ. ʃˈɐ̃mʊ"
    s = ""
    for tok in out:
        if tok in KEEP_PUNCT:
            s = s.rstrip() + tok
        else:
            s = (s + " " + tok) if s else tok
    return " ".join(s.split())


def phonemes_to_input_ids(ps: str) -> list[int]:
    """Reproduce kokoro/model.py tokenization exactly, but RAISE on unmapped symbols."""
    ids, dropped = [], []
    for s in ps:
        i = VOCAB.get(s)
        if i is None:
            dropped.append(s)
        else:
            ids.append(i)
    if dropped:
        detail = ", ".join(
            f"{d!r} (U+{ord(d):04X} {unicodedata.name(d, '?')})" for d in sorted(set(dropped)))
        raise UnmappedSymbol(f"symbols absent from Kokoro vocab: {detail}")
    return [BOUNDARY_ID, *ids, BOUNDARY_ID]


def text_to_input_ids(text: str) -> tuple[str, list[int]]:
    ps = phonemize(text)
    if len(ps) > MAX_PHONEME_LEN:
        raise ValueError(
            f"phoneme string is {len(ps)} chars, over the {MAX_PHONEME_LEN} cap; chunk upstream")
    return ps, phonemes_to_input_ids(ps)


if __name__ == "__main__":
    assert_lect_support()
    for t in ["Bom dia. Chamo-me Teodoro e vivo em Lisboa.", "Custa 1234 euros."]:
        ps, ids = text_to_input_ids(t)
        print(f"{t}\n  -> {ps}\n  -> {len(ids)} ids\n")
